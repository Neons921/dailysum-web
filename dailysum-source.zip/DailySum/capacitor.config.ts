import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.dailysum.ledger',
  appName: 'DailySum',
  webDir: 'dist',
  backgroundColor: '#ffffff',
  android: {
    minWebViewVersion: 116,
    zoomEnabled: true,
  },
  server: { errorPath: 'android-webview.html' },
};

export default config;
