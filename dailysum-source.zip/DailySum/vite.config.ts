import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: './',
  cacheDir: 'node_modules/.vite-dailysum',
  server: { port: 5173, strictPort: true, watch: { ignored: ['**/sites/**'] } },
  test: {
    include: ['src/tests/unit/**/*.test.ts'],
    setupFiles: ['src/tests/setup.ts'],
    environment: 'node',
  },
});
