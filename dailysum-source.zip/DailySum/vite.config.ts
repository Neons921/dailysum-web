import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => ({
  plugins: [react()],
  base: './',
  cacheDir: mode === 'android-preview' ? 'node_modules/.vite-dailysum-android' : 'node_modules/.vite-dailysum',
  server: { port: 5173, strictPort: true, watch: { ignored: ['**/sites/**', '**/.android-build/**', '**/android/**'] } },
  test: {
    include: ['src/tests/unit/**/*.test.ts'],
    setupFiles: ['src/tests/setup.ts'],
    environment: 'node',
  },
}));
