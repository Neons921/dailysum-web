import { cp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = process.cwd(), destination = resolve(root, 'sites/dailysum-web');
const roots = ['src', 'public', 'scripts', 'index.html', 'package.json', 'pnpm-lock.yaml', 'tsconfig.json', 'vite.config.ts', 'playwright.config.ts', 'LICENSE', 'NOTICE.md', '.gitignore'];
await mkdir(destination, { recursive: true });
for (const path of roots) await cp(resolve(root, path), resolve(destination, path), { recursive: true });
// Keep the hosted source generic as well as the built client. Existing saved
// connections are read from browser storage, never copied into this checkout.
async function sanitize(path) {
  for (const entry of await readdir(path, { withFileTypes: true })) {
    const file = resolve(path, entry.name);
    if (entry.isDirectory()) await sanitize(file);
    else if (/\.(?:[cm]?[jt]sx?|css|json)$/.test(entry.name)) {
      const content = await readFile(file, 'utf8');
      await writeFile(file, content.replaceAll('example-user', 'example-user').replaceAll('example-ledger', 'example-ledger'));
    }
  }
}
await sanitize(resolve(destination, 'src'));
await sanitize(resolve(destination, 'scripts'));
await writeFile(resolve(destination, 'README.md'), '# DailySum Web\n\nBrowser-local HKD/CNY ledger with optional private GitHub synchronization.\n\nBuild: `pnpm install --frozen-lockfile`, then `pnpm build`. Serve `dist/` at the Site root.\n\nGPL-3.0; see LICENSE and NOTICE.md. Corresponding program source is provided at `/dailysum-source.zip`. No personal ledger, token or environment file is included.\n');
console.log(JSON.stringify({ checkout: destination, roots: roots.length, personalDataIncluded: false }));
