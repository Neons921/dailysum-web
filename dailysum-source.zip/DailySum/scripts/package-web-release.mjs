import { mkdir, readFile, readdir, stat, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { unzipSync, zipSync } from 'fflate';

const date = process.argv[2];
if (!/^\d{8}$/.test(date ?? '')) throw new Error('Usage: node scripts/package-web-release.mjs YYYYMMDD');
const source = 'dist';
const files = {};
async function add(path) {
  const at = `${source}/${path}`;
  if ((await stat(at)).isDirectory()) {
    for (const name of await readdir(at)) await add(`${path}/${name}`);
  } else files[path] = new Uint8Array(await readFile(at));
}
for (const path of ['index.html', 'assets', 'favicon.svg', 'dime', 'LICENSE.txt', 'NOTICE.txt', 'dailysum-source.zip']) await add(path);
files['.nojekyll'] = new Uint8Array();
const zip = zipSync(files, { level: 6 });
const entries = Object.keys(unzipSync(zip));
if (!entries.includes('index.html') || entries.length !== Object.keys(files).length) throw new Error('Invalid web package');
await mkdir('releases', { recursive: true });
const file = `releases/DailySum-Web-${date}.zip`;
await writeFile(file, zip);
console.log(JSON.stringify({ file, entries: entries.length, bytes: zip.length, sha256: createHash('sha256').update(zip).digest('hex') }));
