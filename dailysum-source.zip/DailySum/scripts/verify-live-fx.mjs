/** Opt-in real-network QA in a fresh, disposable browser context. */
import { chromium, expect } from '@playwright/test';
import Decimal from 'decimal.js';
import { mkdir } from 'node:fs/promises';

const browser = await chromium.launch({ channel: 'msedge', headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
const date = '2025-11-03';
const errors = [];
page.on('pageerror', (error) => errors.push(error.message));
async function add(amount, currency) {
  await page.getByRole('button', { name: '记一笔', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: '记一笔', exact: true });
  await dialog.getByLabel('金额', { exact: true }).fill(amount);
  await dialog.getByRole('group', { name: '记账币种' }).getByRole('button', { name: currency === 'CNY' ? /人民币/ : /港币/ }).click();
  await dialog.locator('#occurredOn').fill(date);
  await dialog.getByRole('button', { name: /^保存/ }).click();
  await expect(dialog).not.toBeVisible();
}
try {
  await page.goto('http://127.0.0.1:5173/');
  const responsePromise = page.waitForResponse((response) => response.url().startsWith('https://api.frankfurter.dev/v2/providers/ecb/rates'), { timeout: 20000 });
  await add('100', 'CNY');
  const response = await responsePromise;
  if (response.status() !== 200) throw new Error(`Provider HTTP ${response.status()}`);
  const data = await response.json();
  const cny = data.find((quote) => quote.date === date && quote.quote === 'CNY');
  const hkd = data.find((quote) => quote.date === date && quote.quote === 'HKD');
  if (!cny || !hkd) throw new Error('Missing same-date source quotes');
  const ratio = new Decimal(hkd.rate).div(cny.rate);
  await expect(page.getByTestId('summary-expense')).toContainText(`HK$ ${new Decimal(100).mul(ratio).toFixed(2)}`, { timeout: 15000 });
  await add('1000', 'HKD');
  const expected = new Intl.NumberFormat('en-HK', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(new Decimal(100).mul(ratio).add(1000).toFixed(2)));
  await expect(page.getByTestId('summary-expense')).toContainText(`HK$ ${expected}`);
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText(`HK$ ${expected}`);
  await expect(page.getByTestId('trend-chart')).toBeVisible();
  await page.getByRole('button', { name: '汇率依据', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: '每日汇率' });
  await expect(dialog.getByRole('region', { name: '已保存汇率' })).toContainText('ECB · Frankfurter');
  await expect(dialog.getByRole('region', { name: '已保存汇率' })).toContainText(date);
  if (errors.length) throw new Error(errors.join('\n'));
  await mkdir('docs/previews', { recursive: true });
  await page.screenshot({ path: 'docs/previews/fx-live-source.png', animations: 'disabled' });
  console.log(JSON.stringify({ status: response.status(), date, EUR_CNY: cny.rate, EUR_HKD: hkd.rate, expectedExpenseHKD: expected, pageErrors: errors.length, isolatedContext: true }));
} finally { await context.close(); await browser.close(); }
