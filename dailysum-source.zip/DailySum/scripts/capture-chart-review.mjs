import { chromium, expect } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';

// Synthetic records in an isolated profile. Never opens the user's browser ledger.
const folder = 'docs/chart-review';
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce' });
const page = await context.newPage(), errors = [];
page.on('pageerror', (error) => errors.push(error.message));
const measurements = [];
try {
  await mkdir(folder, { recursive: true });
  await page.clock.setFixedTime(new Date('2026-11-03T04:00:00Z'));
  await page.route('https://api.github.com/**', (route) => route.abort());
  await page.route('https://api.frankfurter.dev/**', (route) => route.abort());
  await page.goto('http://127.0.0.1:5173/');
  await expect(page.getByRole('heading', { name: '收支明细' })).toBeVisible();
  await page.evaluate(async () => {
    const { ledgerService } = await import('/src/services/ledgerService.ts');
    const amounts = [48, 126, 89, 320, 60, 164, 420, 98, 230, 65, 182, 55, 280, 149, 68, 350, 112, 580, 86, 205, 136, 74, 305, 450, 102, 168, 230, 90, 340, 125, 190];
    const rows = amounts.map((amount, index) => ({
      id: crypto.randomUUID(), type: 'expense', amountMinor: amount * 100, currency: 'HKD',
      categoryId: ['food', 'transport', 'shopping', 'living', 'fun'][index % 5], note: '图表验收示例',
      occurredOn: `2026-10-${String(index + 1).padStart(2, '0')}`, createdAt: '2026-11-03T04:00:00.000Z', updatedAt: '2026-11-03T04:00:00.000Z', deletedAt: null, schemaVersion: 1,
    }));
    for (const [day, amount] of [[1, 380], [12, 520], [21, 340]]) rows.push({ ...rows[0], id: crypto.randomUUID(), type: 'income', categoryId: 'bonus', amountMinor: amount * 100, occurredOn: `2026-10-${String(day).padStart(2, '0')}` });
    await ledgerService.repository.db.transactions.bulkPut(rows);
  });
  await page.reload();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await page.getByRole('button', { name: '上月', exact: true }).click();
  await expect(page.getByTestId('trend-chart')).toBeVisible();
  for (const [width, height] of [[375, 812], [620, 900], [1280, 720], [1440, 1000], [1920, 1080]]) {
    await page.setViewportSize({ width, height });
    for (const mode of ['bar', 'line']) {
      await page.getByRole('button', { name: mode === 'bar' ? '切换柱状图' : '切换折线图' }).click();
      const chart = page.getByRole('application', { name: /收支趋势图/ });
      await chart.scrollIntoViewIfNeeded();
      await expect.poll(async () => chart.evaluate((svg) => Math.abs(svg.viewBox.baseVal.width - svg.getBoundingClientRect().width))).toBeLessThan(1);
      const box = await chart.boundingBox();
      await page.mouse.move(box.x + box.width - 8, box.y + 60);
      const tooltip = page.getByRole('tooltip');
      await expect(tooltip).toBeVisible();
      const tip = await tooltip.boundingBox();
      if (tip.x < 0 || tip.x + tip.width > width) throw new Error(`Tooltip overflow at ${width}`);
      const styles = await page.evaluate(() => {
        const all = [...document.querySelectorAll('.summary-amount')].map((element) => {
          const css = getComputedStyle(element); return { size: css.fontSize, weight: css.fontWeight, color: css.color };
        });
        const presets = [...document.querySelectorAll('.period-presets button')].map((element) => {
          const rect = element.getBoundingClientRect(); return { text: element.textContent, x: rect.x, right: rect.right };
        });
        return { summary: all, presets, scrollWidth: document.documentElement.scrollWidth };
      });
      if (styles.scrollWidth > width || styles.presets.some((item) => item.x < 0 || item.right > width)) throw new Error(`Page/shortcuts overflow at ${width}`);
      if (styles.summary.length !== 3 || styles.summary.some((item) => JSON.stringify(item) !== JSON.stringify(styles.summary[0]))) throw new Error(`Summary typography differs at ${width}`);
      measurements.push({ width, height, mode, tooltipBounds: tip, ...styles });
      if (width === 1440) {
        // Show a mid-month selection in the export, rather than just its last edge.
        await page.mouse.move(box.x + box.width * .57, box.y + 80);
        await page.locator('.trend-panel').screenshot({ path: `${folder}/trend-${mode}.png`, animations: 'disabled' });
        await page.mouse.move(220, 0);
        await page.evaluate(() => { document.activeElement?.blur(); window.scrollTo(0, 0); });
        await page.screenshot({ path: `${folder}/reports-${mode}-1440.png`, fullPage: true, animations: 'disabled' });
      }
    }
    if (width === 375) {
      await page.mouse.move(370, 0);
      await page.evaluate(() => { document.activeElement?.blur(); window.scrollTo(0, 0); });
      await page.screenshot({ path: `${folder}/reports-375.png`, fullPage: true, animations: 'disabled' });
    }
  }
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.locator('.chart-types').getByRole('button', { name: '收支', exact: true }).click();
  const chart = page.getByRole('application', { name: /收支趋势图/ });
  await chart.scrollIntoViewIfNeeded(); await chart.focus();
  await page.keyboard.press('ArrowRight');
  await expect(page.getByRole('tooltip')).toContainText('2026-10-01');
  await expect(page.getByRole('tooltip')).toContainText('HK$ 48.00');
  await expect(page.getByRole('tooltip')).toContainText('HK$ 380.00');
  await page.locator('.trend-panel').screenshot({ path: `${folder}/trend-both-series.png`, animations: 'disabled' });
  const contrast = await page.evaluate(() => {
    const luminance = (color) => {
      const rgb = color.match(/[\d.]+/g).slice(0, 3).map((part) => Number(part) / 255);
      return rgb.map((value) => value <= .04045 ? value / 12.92 : ((value + .055) / 1.055) ** 2.4).reduce((sum, value, index) => sum + value * [.2126, .7152, .0722][index], 0);
    };
    const rows = [];
    for (const selector of ['.report-metrics .money-unit', '.summary-amount', '.period-presets button[aria-pressed="true"]', '.chart-axis', '.chart-tooltip > strong', '.chart-tooltip b', '.chart-tooltip .money-unit', '.chart-tooltip > small']) {
      const element = document.querySelector(selector), css = getComputedStyle(element);
      let node = element, background;
      while (node) { const color = getComputedStyle(node).backgroundColor; if (color !== 'rgba(0, 0, 0, 0)') { background = color; break; } node = node.parentElement; }
      const a = luminance(selector === '.chart-axis' ? css.fill : css.color), b = luminance(background);
      rows.push({ selector, ratio: +((Math.max(a, b) + .05) / (Math.min(a, b) + .05)).toFixed(2) });
    }
    return rows;
  });
  if (contrast.some((row) => row.ratio < 4.5)) throw new Error(`Low contrast: ${JSON.stringify(contrast)}`);
  await page.keyboard.press('Enter');
  await expect(page.getByRole('region', { name: '统计明细' })).toContainText('2 笔');
  await page.clock.setFixedTime(new Date('2026-01-02T04:00:00Z'));
  await page.setViewportSize({ width: 375, height: 812 });
  await page.reload();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByRole('group', { name: '统计时间快捷选择' })).toContainText('2025年11月');
  await expect(page.locator('.period-presets [aria-pressed="true"]')).toHaveCount(1);
  const crossYearOverflow = await page.evaluate(() => [...document.querySelectorAll('.period-presets button')].some((element) => element.scrollWidth > element.clientWidth));
  if (crossYearOverflow) throw new Error('Previous-year shortcut labels are clipped');
  await page.screenshot({ path: `${folder}/cross-year-shortcuts-375.png`, animations: 'disabled' });
  if (errors.length) throw new Error(errors.join('\n'));
  await writeFile(`${folder}/verification.json`, JSON.stringify({ isolatedContext: true, syntheticRecordsOnly: true, networkBlocked: true, reducedMotion: true, viewports: measurements, contrast, keyboardAndDrilldown: true, crossYearShortcutsFit: true, pageErrors: errors }, null, 2));
  console.log(JSON.stringify({ viewports: measurements.length / 2, chartModes: 2, summaryParity: true, tooltipBounds: true, keyboardAndDrilldown: true, minimumTextContrast: Math.min(...contrast.map((item) => item.ratio)), pageErrors: errors.length }));
} finally { await context.close(); await browser.close(); }
