import { lstat, readFile, readdir, writeFile } from 'node:fs/promises';
import { zipSync } from 'fflate';

// Explicit program-only roots. Browser data, backups, environment files, Site
// credentials, Git metadata and generated build output are never traversed.
const roots = ['src', 'public', 'scripts', 'index.html', 'package.json', 'pnpm-lock.yaml', 'tsconfig.json', 'vite.config.ts', 'playwright.config.ts', 'LICENSE', 'NOTICE.md'];
const files = {};
await writeFile('public/LICENSE.txt', await readFile('LICENSE'));
await writeFile('public/NOTICE.txt', await readFile('NOTICE.md'));
async function collect(path) {
  if (path === 'public/dailysum-source.zip') return;
  const info = await lstat(path);
  if (info.isSymbolicLink()) throw new Error(`Unexpected symbolic link: ${path}`);
  if (info.isDirectory()) {
    for (const entry of await readdir(path)) if (!entry.startsWith('.')) await collect(`${path}/${entry}`);
    return;
  }
  let bytes = await readFile(path);
  if (/\.(?:[cm]?[jt]sx?|css|json|md|txt)$/.test(path)) {
    // Test fixtures use an illustrative account in the downloadable sources.
    bytes = Buffer.from(bytes.toString('utf8').replaceAll('example-user', 'example-user').replaceAll('example-ledger', 'example-ledger'));
  }
  files[`DailySum/${path}`] = new Uint8Array(bytes);
}
for (const root of roots) await collect(root);
await writeFile('public/dailysum-source.zip', zipSync(files, { level: 6 }));
console.log(`Prepared program source archive (${Object.keys(files).length} files).`);
