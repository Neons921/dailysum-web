import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, relative, isAbsolute, join } from 'node:path';
import { createHash } from 'node:crypto';
import { createServer } from 'vite';

// Explicit offline maintenance. Never reads browser credentials or writes GitHub.
const [input,output]=process.argv.slice(2);
if(!input||!output)throw new Error('Usage: node scripts/consolidate-ledger.mjs <ledger.json> <backups/output-folder>');
const root=resolve(process.cwd()),directory=resolve(output),allowed=resolve(root,'backups'),within=relative(allowed,directory);
if(isAbsolute(within)||within.startsWith('..'))throw new Error('个人账本输出目录必须位于项目 backups 内');
if(resolve(input)===join(directory,'ledger.categories-cleaned.v1.json'))throw new Error('输出不能覆盖输入账本');
const raw=await readFile(resolve(input),'utf8');
const server=await createServer({configFile:false,root,appType:'custom',logLevel:'error',server:{middlewareMode:true,watch:null,hmr:false}});
try {
  const {parseEnvelope,createEnvelope,same,canonical}=await server.ssrLoadModule('/src/domain/portable.ts');
  const {consolidateCategories,activeCategories}=await server.ssrLoadModule('/src/domain/categories.ts');
  const {DEFAULT_CATEGORIES}=await server.ssrLoadModule('/src/domain/models.ts');
  const {summarizeConverted}=await server.ssrLoadModule('/src/domain/reports.ts');
  const before=await parseEnvelope(JSON.parse(raw.replace(/^\uFEFF/,'')));
  const result=consolidateCategories(before.data),after=await createEnvelope(result.data,before.ledgerId);
  const oldRows=new Map(before.data.transactions.map((row)=>[row.id,row]));
  if(oldRows.size!==after.data.transactions.length)throw new Error('整理前后账目数量不一致');
  let changed=0;
  for(const row of after.data.transactions){
    const old=oldRows.get(row.id);if(!old)throw new Error('整理后出现未知账目');
    const protectedFields=(entry)=>{const {categoryId,categoryHistory,...rest}=entry;return rest;};
    if(!same(protectedFields(old),protectedFields(row)))throw new Error('整理改变了分类以外的账目字段，已停止输出');
    if(old.categoryId!==row.categoryId)changed++;
  }
  for(const field of ['archives','fxRates','filterPreferences'])if(!same(before.data[field],after.data[field]))throw new Error(`${field} 内容意外变化`);
  const totals=(data)=>{
    const result={};
    for(const currency of ['HKD','CNY'])for(const type of ['expense','income']){
      const rows=data.transactions.filter((row)=>!row.deletedAt&&row.currency===currency&&row.type===type);
      result[`${currency}_${type}`]={count:rows.length,minor:rows.reduce((sum,row)=>sum+BigInt(row.amountMinor),0n).toString()};
    }
    return result;
  };
  if(!same(totals(before.data),totals(after.data)))throw new Error('原币笔数或金额不一致');
  const converted=(data)=>{
    const summary=summarizeConverted(data.transactions.filter((row)=>!row.deletedAt),data.settings.reportCurrency,data.fxRates);
    return {currency:data.settings.reportCurrency,incomeMinor:String(summary.income.amount),expenseMinor:String(summary.expense.amount),netMinor:summary.net===null?null:String(summary.net),missing:summary.missing};
  };
  if(!same(converted(before.data),converted(after.data)))throw new Error('折算汇总发生变化');
  const report={format:'dailysum-category-cleanup-report',createdAt:new Date().toISOString(),input:resolve(input),sourceSha256:createHash('sha256').update(raw).digest('hex'),
    sourceIntegrity:before.integrity,resultIntegrity:after.integrity,ledgerIdentityPreserved:before.ledgerId===after.ledgerId,
    transactionCount:after.data.transactions.length,activeRecords:after.data.transactions.filter((row)=>!row.deletedAt).length,deletedRecords:after.data.transactions.filter((row)=>row.deletedAt).length,
    changedRecords:changed,visibleCategoriesBefore:activeCategories(before.data.categories).length,visibleCategoriesAfter:activeCategories(after.data.categories).length,archivedMergedCategories:result.mapping.length,
    categoryCounts:DEFAULT_CATEGORIES.map((category)=>({id:category.id,name:category.name,type:category.type,count:after.data.transactions.filter((row)=>!row.deletedAt&&row.categoryId===category.id).length})),
    mapping:result.mapping,originalCurrencyTotals:totals(after.data),convertedTotal:converted(after.data),
    checks:{recordIdsAndAllNonCategoryFieldsUnchanged:true,originalArchivesUnchanged:true,fxHistoryUnchanged:true,filtersUnchanged:true,preferencesUnchanged:same(before.data.settings,after.data.settings),
      checksumVerified:!!(await parseEnvelope(after)),idempotent:same(consolidateCategories(after.data).data,after.data)},
  };
  if(!report.checks.idempotent)throw new Error('重复执行分类合并会再次改变数据');
  await mkdir(directory,{recursive:true});
  const outputPath=join(directory,'ledger.categories-cleaned.v1.json');
  await writeFile(outputPath,JSON.stringify(after,null,2),{encoding:'utf8',flag:'wx'});
  await writeFile(join(directory,'category-cleanup-report.json'),JSON.stringify(report,null,2),{encoding:'utf8',flag:'wx'});
  await writeFile(join(directory,'分类整理说明.txt'),[
    'DailySum 分类整理',`有效账目 ${report.activeRecords} 笔；已删除 ${report.deletedRecords} 笔；分类调整 ${changed} 笔。`,
    `可选分类 ${report.visibleCategoriesBefore} → ${report.visibleCategoriesAfter}；${result.mapping.length} 个旧分类作为合并记录保留，不再出现在分类选择中。`,
    '金额、币种、日期、备注、ID、删除状态及 Cent 原始归档均保持不变。旧分类名称保存在记录历史与来源归档中。',
    `过滤器 ${after.data.filterPreferences.views.length} 个，内容未改动；原币与折算汇总核对一致。`,
    '', '操作：保持应用运行，在 设置 → 导入账目 → 备份文件 中选择 ledger.categories-cleaned.v1.json，核对预览后确认导入。',
    '导入后分类选项为 7 个支出、6 个收入。已启用 GitHub 自动同步时会自动同步；也可在设置里检查并确认同步。',
    '如果导出原文件后又改过账目，预览会保留新增记录，并对真正不同的金额、日期或备注提示选择；请核对这些差异。',
    '请使用本次更新后的 DailySum 导入，不直接手工替换 GitHub 文件。原始 ledger.v1.json 未改动，ledger.original.json 为独立备份。',
    '',...report.categoryCounts.map((category)=>`${category.type==='expense'?'支出':'收入'} / ${category.name}：${category.count} 笔`),
  ].join('\n'),'utf8');
  console.log(JSON.stringify({output:outputPath,records:report.transactionCount,active:report.activeRecords,deleted:report.deletedRecords,changed,visibleCategories:report.visibleCategoriesAfter,archivedCategories:result.mapping.length,checks:report.checks}));
} finally {await server.close();}
