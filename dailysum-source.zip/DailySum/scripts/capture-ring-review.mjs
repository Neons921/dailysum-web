import { chromium, expect } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';

// Render-only verification in an isolated ledger with synthetic HKD records.
const folder = 'docs/ring-review';
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, reducedMotion: 'reduce' });
const page = await context.newPage(), errors = [], checks = [];
page.on('pageerror', (error) => errors.push(error.message));
page.on('console', (message) => { if (message.type() === 'error' && message.text().includes('attribute d')) errors.push(message.text()); });
async function seed(amounts) {
  await page.evaluate(async (values) => {
    const { ledgerService } = await import('/src/services/ledgerService.ts');
    const categories = ['food', 'fun', 'transport', 'other-expense', 'shopping', 'living'];
    await ledgerService.repository.db.transaction('rw', ledgerService.repository.db.transactions, async () => {
      await ledgerService.repository.db.transactions.clear();
      await ledgerService.repository.db.transactions.bulkPut(values.map((amount, i) => ({
        id: crypto.randomUUID(), type: 'expense', amountMinor: amount, currency: 'HKD', categoryId: categories[i % 6], note: '环图验收示例',
        occurredOn: '2026-11-04', createdAt: '2026-11-04T02:00:00.000Z', updatedAt: '2026-11-04T02:00:00.000Z', deletedAt: null, schemaVersion: 1,
      })));
    });
  }, amounts);
  await page.reload();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.locator('.category-ring')).toBeVisible();
}
async function inspect(name, width) {
  await expect.poll(async () => page.locator('.ring-label-amount').evaluate((element) => {
    const text = element.querySelector('.money-value').getBoundingClientRect();
    return text.width - element.clientWidth;
  })).toBeLessThan(.5);
  const metrics = await page.evaluate(() => {
    const ring = document.querySelector('.category-ring'), svg = ring.querySelector('svg');
    const box = svg.getBoundingClientRect(), innerRadius = box.width * 91 / 252;
    const center = { x: box.x + box.width / 2, y: box.y + box.height / 2 };
    // Check all four corners of the actual visible text, not just its containing box.
    const labels = ['.ring-label > span', '.ring-label-amount .money-value', '.ring-label > small'].map((selector) => {
      const element = document.querySelector(selector), rect = element.getBoundingClientRect();
      const distance = Math.max(...[rect.left, rect.right].flatMap((x) => [rect.top, rect.bottom].map((y) => Math.hypot(x - center.x, y - center.y))));
      return { text: element.textContent, size: getComputedStyle(element).fontSize, distanceToCenter: distance, clearance: innerRadius - distance };
    });
    const ringBounds = { x: box.x, right: box.right, width: box.width };
    const panel = document.querySelector('.category-panel');
    const paths = [...ring.querySelectorAll('.category-arc')].map((path) => {
      const bounds = path.getBBox(); return { x: bounds.x, y: bounds.y, right: bounds.x + bounds.width, bottom: bounds.y + bounds.height };
    });
    return { labels, ringBounds, paths, panelScrollWidth: panel.scrollWidth, panelClientWidth: panel.clientWidth, scrollWidth: document.documentElement.scrollWidth };
  });
  if (metrics.labels.some((label) => label.clearance < 5)) throw new Error(`Text too close to ring (${name}, ${width}): ${JSON.stringify(metrics.labels)}`);
  if (metrics.panelScrollWidth > metrics.panelClientWidth || metrics.ringBounds.x < 0 || metrics.ringBounds.right > width) throw new Error(`Ring panel overflow at ${width}: ${JSON.stringify(metrics)}`);
  if (metrics.paths.some((path) => path.x < 15.9 || path.y < 15.9 || path.right > 236.1 || path.bottom > 236.1)) throw new Error('Invalid ring sector geometry');
  // The billion-dollar fixture tests this component; unrelated metric cards are outside its scope.
  if (!name.startsWith('large-total') && metrics.scrollWidth > width) throw new Error(`Page overflow at ${width}`);
  checks.push({ name, width, ...metrics });
}
try {
  await mkdir(folder, { recursive: true });
  await page.clock.setFixedTime(new Date('2026-11-04T02:00:00Z'));
  await page.route('https://api.github.com/**', (route) => route.abort());
  await page.route('https://api.frankfurter.dev/**', (route) => route.abort());
  await page.goto('http://127.0.0.1:5173/');
  await expect(page.getByRole('heading', { name: '收支明细' })).toBeVisible();
  for (const [name, amounts] of [
    ['six-categories', [876540, 243821, 107320, 31250, 1420, 24]],
    ['large-total', Array.from({ length: 12 }, () => 9999999999)],
    ['single-category', [846729]],
  ]) {
    await seed(amounts);
    if (name === 'large-total') await page.getByRole('button', { name: '今年', exact: true }).click();
    for (const width of [375, 620, 800, 1280, 1440, 1920]) {
      await page.setViewportSize({ width, height: 900 });
      await page.locator('.category-panel').scrollIntoViewIfNeeded();
      await page.mouse.move(0, 0);
      await page.evaluate(() => document.activeElement?.blur());
      await inspect(name, width);
      if (width === 1440 || width === 375) await page.locator('.category-panel').screenshot({ path: `${folder}/${name}-${width}.png`, animations: 'disabled' });
      const first = page.locator('.category-arc').first();
      await first.focus();
      await expect(page.locator('.ring-label')).toContainText('餐饮');
      await expect(page.locator('.category-arc-halo')).toHaveCount(1);
      await inspect(`${name}-focused`, width);
      if (width === 1440 && name === 'six-categories') await page.locator('.category-panel').screenshot({ path: `${folder}/category-selected-1440.png`, animations: 'disabled' });
    }
    await page.keyboard.press('Enter');
    await expect(page.getByRole('button', { name: '统计分类筛选', exact: true })).toContainText('餐饮');
    await expect(page.locator('.category-arc')).toHaveCount(1);
    await expect(page.locator('.category-rank')).toHaveCount(1);
    await expect(page.locator('.ring-label')).toContainText('100.0%');
  }
  await seed([876540, 243821, 107320, 31250, 1420, 24]);
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.getByRole('button', { name: '筛选交通分类', exact: true }).focus();
  await expect(page.locator('.ring-label')).toContainText('交通');
  await expect(page.locator('.ring-label-amount')).toHaveText('HK$ 1,073.20');
  await page.keyboard.press('Space');
  await expect(page.getByRole('button', { name: '统计分类筛选', exact: true })).toContainText('交通');
  if (errors.length) throw new Error(errors.join('\n'));
  await writeFile(`${folder}/verification.json`, JSON.stringify({ date: '2026-11-04', syntheticRecordsOnly: true, isolatedContext: true, networkBlocked: true, reducedMotion: true, checks, keyboardDrilldown: true, pageErrors: errors }, null, 2));
  console.log(JSON.stringify({ cases: 3, widths: 6, textSafetyChecks: checks.length, minimumClearance: Math.min(...checks.flatMap((check) => check.labels.map((label) => label.clearance))), keyboardDrilldown: true, pageErrors: errors.length }));
} finally { await context.close(); await browser.close(); }
