/** Imports unmodified assets and light-mode colors from the pinned Dime checkout. */
import { readFileSync, writeFileSync, mkdirSync, copyFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { execFileSync } from 'node:child_process';

const root = resolve(import.meta.dirname, '..');
const upstream = join(root, 'upstream', 'dimeApp');
const pinnedCommit = '0463cb8caba237de781ae02e70a2ec82ae900c67';
const actualCommit = execFileSync('git', ['-C', upstream, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
if (actualCommit !== pinnedCommit) throw new Error(`Expected Dime ${pinnedCommit}; found ${actualCommit}`);
const assetsRoot = join(upstream, 'app', 'dime', 'Assets.xcassets');
const output = join(root, 'public', 'dime');
const codeOutput = join(root, 'src', 'dime');
mkdirSync(output, { recursive: true });
mkdirSync(codeOutput, { recursive: true });

const assets = {
  'log.svg': 'TabBarIcons/Log.imageset/receipt-2-1.svg',
  'insights.svg': 'TabBarIcons/Insights.imageset/chart-21.svg',
  'settings.svg': 'TabBarIcons/Settings.imageset/setting.svg',
  'empty.svg': 'Icons/dropbox.imageset/direct-normal.svg',
  'backspace.svg': 'Icons/tag-cross.imageset/tag-cross.svg',
};
for (const [target, source] of Object.entries(assets)) copyFileSync(join(assetsRoot, source), join(output, target));
copyFileSync(join(upstream, 'LICENSE'), join(output, 'LICENSE.txt'));
copyFileSync(join(upstream, 'LICENSE'), join(root, 'LICENSE'));

const colors = ['PrimaryBackground', 'SecondaryBackground', 'PrimaryText', 'SubtitleText', 'Outline', 'DarkBackground', 'IncomeGreen', 'AlertRed'];
const channel = (value) => value.startsWith('0x') ? Number.parseInt(value.slice(2), 16) : Math.round(Number(value) * 255);
const asHex = (components) => `#${['red', 'green', 'blue'].map((key) => channel(components[key]).toString(16).padStart(2, '0')).join('')}`;
const values = {};
for (const name of colors) {
  const source = JSON.parse(readFileSync(join(assetsRoot, 'Colors', `${name}.colorset`, 'Contents.json'), 'utf8'));
  const light = source.colors.find((item) => item.appearances?.some((appearance) => appearance.value === 'light'));
  values[name] = asHex((light?.color ?? source.colors.find((item) => item.color).color).components);
}
const css = `/* Generated from rafsoh/dimeApp ${pinnedCommit}; GPL-3.0. Run node scripts/import-dime.mjs. */\n:root {\n${Object.entries(values).map(([name, value]) => `  --dime-${name}: ${value};`).join('\n')}\n}\n`;
writeFileSync(join(codeOutput, 'theme.generated.css'), css);
writeFileSync(join(codeOutput, 'upstream.generated.json'), `${JSON.stringify({
  repository: 'https://github.com/rafsoh/dimeApp', commit: pinnedCommit, license: 'GPL-3.0',
  assets, colors: values,
  components: {
    log: 'app/dime/Views/LogView.swift',
    transaction: 'app/dime/Views/TransactionView.swift',
    categories: 'app/dime/Components/Transactions/TransactionCategoryPicker.swift',
    numberPad: 'app/dime/Components/Transactions/NumberPad.swift',
    summary: 'app/dime/Components/Buttons/InsightsSummaryBlock.swift',
    settings: 'app/dime/Views/Settings/SettingsView.swift',
    navigation: 'app/dime/Views/CustomTabBar.swift',
    insights: 'app/dime/Views/InsightsView.swift',
    lineGraph: 'app/dime/Views/LineGraph.swift',
  },
}, null, 2)}\n`);
process.stdout.write(`Imported ${Object.keys(assets).length} Dime SVGs and ${colors.length} original colors from ${pinnedCommit}.\n`);
