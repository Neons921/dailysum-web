import { chromium, expect } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';

// Isolated visual QA; provider fixtures only, no access to the user's profile.
const browser = await chromium.launch({ channel: 'msedge', headless: true });
const context = await browser.newContext({ viewport: { width: 375, height: 812 }, reducedMotion: 'reduce' });
const page = await context.newPage();
const folder = 'docs/ui-review';
const errors = [];
page.on('pageerror', (error) => errors.push(error.message));
try {
  await page.route('https://api.frankfurter.dev/**', async (route) => {
    const url = new URL(route.request().url()), body = [];
    for (let day = url.searchParams.get('from'); day <= url.searchParams.get('to');) {
      body.push({ date: day, base: 'EUR', quote: 'CNY', rate: 10 }, { date: day, base: 'EUR', quote: 'HKD', rate: 11.8 });
      const date = new Date(`${day}T12:00:00Z`); date.setUTCDate(date.getUTCDate() + 1); day = date.toISOString().slice(0, 10);
    }
    await route.fulfill({ contentType: 'application/json', body: JSON.stringify(body) });
  });
  await page.goto('http://127.0.0.1:5173/');
  await page.getByRole('button', { name: '查看示例', exact: true }).click();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByTestId('trend-chart')).toBeVisible();
  await mkdir(folder, { recursive: true });
  const viewportResults = [];
  for (const [width, height] of [[375,812],[1280,720],[1440,900],[1920,1080]]) {
    await page.setViewportSize({ width, height });
    const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    if (scrollWidth > width) throw new Error(`Horizontal overflow at ${width}: ${scrollWidth}`);
    await page.screenshot({ path: `${folder}/reports-${width}x${height}.png`, fullPage: true, animations: 'disabled' });
    viewportResults.push({ width, height, scrollWidth });
  }
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.getByRole('button', { name: '统计日期范围', exact: true }).click();
  await page.screenshot({ path: `${folder}/calendar-1440.png`, animations: 'disabled' });
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: '统计原币筛选', exact: true }).click();
  await page.screenshot({ path: `${folder}/menu-1440.png`, animations: 'disabled' });
  const contrast = await page.evaluate(() => {
    const rgb = (color) => (color.match(/[\d.]+/g) || []).map(Number).slice(0,3).map((n) => n / 255);
    const light = (color) => rgb(color).map((v) => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4).reduce((sum,v,i) => sum + v * [.2126,.7152,.0722][i],0);
    const result = [];
    for (const selector of ['h1','.dime-summary-label','.dime-summary-block strong','.money-unit','.stat-net > strong','.stat-foot','.select-option','.report-table th','.report-table td','.report-metrics > div > span','.ring-label > span','.chart-axis']) {
      const element = [...document.querySelectorAll(selector)].find((item) => item.getBoundingClientRect().width > 0);
      if (!element) continue;
      let node = element, background = 'rgb(255, 255, 255)';
      while (node) { const bg = getComputedStyle(node).backgroundColor; if (bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') { background = bg; break; } node = node.parentElement; }
      const styles = getComputedStyle(element), foreground = element instanceof SVGElement ? styles.fill : styles.color;
      const a = light(foreground), b = light(background), ratio = (Math.max(a,b)+.05)/(Math.min(a,b)+.05);
      result.push({ selector, foreground, background, ratio: Number(ratio.toFixed(2)), pass: ratio >= 4.5 });
    }
    return result;
  });
  if (contrast.some((item) => !item.pass)) throw new Error(`Contrast failures: ${JSON.stringify(contrast.filter((item) => !item.pass))}`);
  await page.keyboard.press('Escape');
  await page.getByRole('link',{name:'设置',exact:true}).click();
  await page.getByRole('button',{name:/^GitHub 同步/}).click();
  const connection=page.getByRole('dialog',{name:'GitHub 同步'}),connectionViewports=[];
  await expect(connection.getByLabel('记住 GitHub 连接')).toBeChecked();
  await mkdir('docs/sync-review',{recursive:true});
  for(const [width,height] of [[375,812],[1280,720],[1440,900],[1920,1080]]) {
    await page.setViewportSize({width,height});
    const box=await connection.boundingBox(),scrollWidth=await page.evaluate(()=>document.documentElement.scrollWidth);
    if(!box||box.x<0||box.y<0||box.x+box.width>width||box.y+box.height>height||scrollWidth>width)throw new Error(`Connection dialog overflow at ${width}`);
    const checkboxLayout=await connection.getByLabel('记住 GitHub 连接').evaluate((element)=>getComputedStyle(element.parentElement).display);
    if(checkboxLayout!=='flex')throw new Error('Remember connection row lost its inline checkbox layout');
    await page.screenshot({path:`docs/sync-review/connection-${width}.png`,animations:'disabled'});
    connectionViewports.push({viewport:{width,height},bounds:box,scrollWidth,rememberChecked:true,checkboxLayout});
  }
  if (errors.length) throw new Error(errors.join('\n'));
  const report = { viewportResults,connectionViewports, contrast, pageErrors: errors, isolatedContext: true, provider: 'test fixture only' };
  await writeFile(`${folder}/measurements.json`, JSON.stringify(report,null,2));
  console.log(JSON.stringify({ viewports: viewportResults.length,connectionViewports:connectionViewports.length, contrastChecks: contrast.length, minimumTextContrast: Math.min(...contrast.map((item) => item.ratio)), pageErrors: errors.length }));
} finally { await context.close(); await browser.close(); }
