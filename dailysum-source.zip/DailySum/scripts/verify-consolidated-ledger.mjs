import { chromium, expect } from '@playwright/test';
import { readFile,writeFile } from 'node:fs/promises';
import { dirname,join } from 'node:path';
const [originalPath,cleanedPath]=process.argv.slice(2);
if(!originalPath||!cleanedPath)throw new Error('Provide original and cleaned ledger paths');
const original=JSON.parse(await readFile(originalPath,'utf8'));
const browser=await chromium.launch({channel:'msedge',headless:true});
const context=await browser.newContext({viewport:{width:1440,height:900}});
const page=await context.newPage(),errors=[];
page.on('pageerror',(error)=>errors.push(error.message));
// Real user records remain in this isolated local browser. No remote sync or FX requests.
await context.route('https://api.github.com/**',(route)=>route.abort());
await context.route('https://api.frankfurter.dev/**',(route)=>route.fulfill({status:503,contentType:'application/json',body:'{}'}));
async function importFile(pathOrPayload){
  await page.getByRole('link',{name:'设置',exact:true}).click();
  await page.getByRole('button',{name:/^导入账目/}).click();
  await page.getByLabel('选择备份文件',{exact:true}).setInputFiles(pathOrPayload);
  const dialog=page.getByRole('dialog',{name:'核对账目'});
  await expect(dialog).toBeVisible();
  await expect(dialog.getByRole('radio')).toHaveCount(0);
  await dialog.getByRole('button',{name:'确认导入',exact:true}).click();await expect(dialog).not.toBeVisible();
}
async function readRows(){return page.evaluate(()=>new Promise((resolve,reject)=>{
  const request=indexedDB.open('dailysum');request.onerror=()=>reject(new Error('Cannot open isolated ledger'));
  request.onsuccess=()=>{const db=request.result,read=db.transaction('transactions').objectStore('transactions').getAll();read.onerror=()=>reject(new Error('Cannot read isolated ledger'));read.onsuccess=()=>{resolve(read.result);db.close();};};
}));}
function assertPreserved(rows){
  const previous=new Map(original.data.transactions.map((row)=>[row.id,row]));
  if(rows.length!==previous.size)throw new Error('Browser record count changed');
  const canonical=(value)=>value===undefined?'null':value===null||typeof value!=='object'?JSON.stringify(value):Array.isArray(value)?`[${value.map(canonical).join(',')}]`:`{${Object.keys(value).sort().filter((key)=>value[key]!==undefined).map((key)=>`${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`;
  const fields=({categoryId,categoryHistory,...other})=>other;
  for(const row of rows){const old=previous.get(row.id);if(!old||canonical(fields(old))!==canonical(fields(row)))throw new Error('Non-category browser record changed');}
}
try {
  await page.goto('http://127.0.0.1:5173/#/settings');
  await expect(page.getByRole('heading',{name:'偏好设置'})).toBeVisible();
  await importFile(originalPath);await expect(page.locator('.settings-category')).toHaveCount(original.data.categories.length);
  await importFile(cleanedPath);await expect(page.locator('.settings-category')).toHaveCount(13);assertPreserved(await readRows());
  const source=original.data.archives.find((archive)=>archive.format==='cent');
  if(source){await importFile({name:'cent-original.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(source.data))});await expect(page.locator('.settings-category')).toHaveCount(13);assertPreserved(await readRows());}
  await page.screenshot({path:join(dirname(cleanedPath),'分类整理后-设置.png'),fullPage:true});
  await page.getByRole('button',{name:'记一笔',exact:true}).click();
  const editor=page.getByRole('dialog',{name:'记一笔'}),picker=editor.getByRole('group',{name:'交易分类'});
  await editor.getByRole('button',{name:'支出',exact:true}).click();await expect(picker.getByRole('button')).toHaveCount(7);
  await editor.getByRole('button',{name:'收入',exact:true}).click();await expect(picker.getByRole('button')).toHaveCount(6);
  if(errors.length)throw new Error(`Page errors: ${errors.length}`);
  const result={isolatedContext:true,remoteRequestsBlocked:true,nativeOriginalImport:true,cleanedImportWithoutConflicts:true,centReimportWithoutCategoryResurrection:!!source,
    allNonCategoryFieldsPreserved:true,records:original.data.transactions.length,active:original.data.transactions.filter((row)=>!row.deletedAt).length,visibleCategories:13,expenseChoices:7,incomeChoices:6,pageErrors:0};
  await writeFile(join(dirname(cleanedPath),'browser-verification.json'),JSON.stringify(result,null,2),'utf8');
  console.log(JSON.stringify(result));
} finally {await context.close();await browser.close();}
