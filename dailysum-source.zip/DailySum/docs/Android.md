# DailySum Android

Android 版使用 Capacitor 打包现有界面和本地账本。应用界面随 APK 安装，断网时可启动、记账、编辑和查看已有数据。同步和获取未缓存汇率需要联网。

手机界面由 Dime 的原版 SwiftUI 组件移植。点击底部「＋」打开记账页，选日期和分类后，用数字键盘右下角的「✓」保存。点明细可编辑或删除记录；在统计中可点分类查看相应账目。

底部「分析」可切换月份。本月截至今天，与上月同一段日期比较。历史月份按整月与前一个月比较。可查看金额最高的五笔支出及其合计变化，也可查看餐饮和交通各自的变化。分析使用设置中的报表币种和交易日汇率，统计页的筛选条件不影响这里。

Android 返回键会先关闭当前弹窗；主页面中，按返回直接回到「收支明细」，在「收支明细」再按返回退出应用。

## 在电脑上预览界面

从项目根目录运行 `pnpm dev:android`，打开 [Android 界面预览](http://127.0.0.1:5174/)。可切换 320、393 或 430 px 宽度，查看和操作当前源码里的 Android 界面。开发服务器运行期间，保存代码后浏览器会更新。

首次打开会提供独立的示例账本，可以测试记账、编辑和删除。测试记录只保存在预览地址下，GitHub 同步在此停用。系统返回键、触觉反馈和原生文件选择器需要用 Android 模拟器或手机验证。

## 构建测试 APK

准备 Node.js、pnpm、JDK 21 和 Android SDK Platform 36。可通过 Android Studio 的 SDK Manager 安装 SDK，并将 `ANDROID_HOME` 指向 SDK 目录。

从项目根目录在 PowerShell 运行：

```powershell
pnpm install --frozen-lockfile
pnpm android:sync
Set-Location android
.\gradlew.bat :app:assembleDebug
```

生成的 APK 位于 `android/app/build/outputs/apk/debug/app-debug.apk`。应用 ID 为 `app.dailysum.ledger`，可在 Android 7.0 或更新版本安装，所用 Android System WebView 或 Chrome 需支持 Chromium 116 及以上。

## 连接已有账本

手机和浏览器各自保存本地账本。在手机打开「设置 → GitHub 同步」，连接网页端使用的同一个私有仓库，核对并确认首次同步，然后开启自动同步。选择「记住 GitHub 连接」后，应用可在重新打开时恢复连接。

首次使用建议先完成同步再记账，以便沿用已有分类和账目。使用「设置 → 导出备份」可将完整 JSON 保存到 Android 文件选择器中的指定位置。
