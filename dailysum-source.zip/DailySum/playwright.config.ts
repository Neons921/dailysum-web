import { defineConfig, devices } from '@playwright/test';

const deployedUrl = process.env.DAILYSUM_TEST_URL;
const baseURL = deployedUrl ?? 'http://127.0.0.1:5173';

export default defineConfig({
  testDir: './src/tests/e2e',
  fullyParallel: false,
  reporter: 'list',
  use: { baseURL, trace: 'retain-on-failure' },
  projects: [
    { name: 'edge', use: { ...devices['Desktop Edge'], channel: 'msedge' } },
    { name: 'chrome', grep: /@smoke/, use: { ...devices['Desktop Chrome'], channel: 'chrome' } },
  ],
  webServer: deployedUrl ? undefined : {
    command: 'pnpm dev',
    url: 'http://127.0.0.1:5173',
    reuseExistingServer: !process.env.CI,
    timeout: 30_000,
  },
});
