package app.dailysum.ledger;

import android.os.Build;
import android.view.HapticFeedbackConstants;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "TouchFeedback")
public class TouchFeedbackPlugin extends Plugin {
    @PluginMethod
    public void play(PluginCall call) {
        boolean confirm = "confirm".equals(call.getString("kind"));
        int feedback = confirm && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
            ? HapticFeedbackConstants.CONFIRM
            : HapticFeedbackConstants.KEYBOARD_TAP;
        getActivity().runOnUiThread(() -> {
            // Use Android's touch feedback setting and the device's supported effect.
            getBridge().getWebView().performHapticFeedback(feedback);
            call.resolve();
        });
    }
}
