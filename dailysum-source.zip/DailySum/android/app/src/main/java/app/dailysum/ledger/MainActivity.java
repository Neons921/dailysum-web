package app.dailysum.ledger;

import android.os.Bundle;
import androidx.core.splashscreen.SplashScreen;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        SplashScreen.installSplashScreen(this);
        registerPlugin(SaveFilePlugin.class);
        registerPlugin(TouchFeedbackPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
