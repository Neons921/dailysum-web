package app.dailysum.ledger;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "SaveFile")
public class SaveFilePlugin extends Plugin {
    private final AtomicBoolean saving = new AtomicBoolean();
    private volatile byte[] pendingData;

    @PluginMethod
    public void save(PluginCall call) {
        String name = call.getString("name");
        String mime = call.getString("mime");
        String base64 = call.getString("base64");
        if (name == null || mime == null || base64 == null) {
            call.reject("缺少文件内容或文件名。");
            return;
        }
        if (!saving.compareAndSet(false, true)) {
            call.reject("请先完成上一次文件保存。");
            return;
        }

        try {
            pendingData = Base64.decode(base64, Base64.DEFAULT);
            // Capacitor saves the activity call in Android's instance-state bundle.
            call.getData().remove("base64");
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mime);
            intent.putExtra(Intent.EXTRA_TITLE, name);
            startActivityForResult(call, intent, "fileSelected");
        } catch (RuntimeException error) {
            pendingData = null;
            saving.set(false);
            call.reject("无法打开文件保存窗口。", error);
        }
    }

    @ActivityCallback
    private void fileSelected(PluginCall call, ActivityResult result) {
        byte[] data = pendingData;
        pendingData = null;
        Intent selection = result.getData();
        Uri uri = selection == null ? null : selection.getData();
        if (call == null || result.getResultCode() != Activity.RESULT_OK || uri == null) {
            saving.set(false);
            if (call != null) call.resolve();
            return;
        }

        if (data == null) {
            saving.set(false);
            call.reject("保存已中断，请重新导出文件。");
            return;
        }

        getBridge().execute(() -> {
            try (OutputStream output = getContext().getContentResolver().openOutputStream(uri, "wt")) {
                if (output == null) throw new IOException("The document provider returned no stream");
                output.write(data);
            } catch (IOException | RuntimeException error) {
                call.reject("保存文件失败，请选择其他位置后重试。", error);
                return;
            } finally {
                saving.set(false);
            }
            call.resolve();
        });
    }
}
