import type { FxRate } from '../domain/models';
import { fxRateSchema, latestRates } from '../domain/fx';
import type { LedgerDatabase } from './db';

export class FxRepository {
  constructor(readonly db: LedgerDatabase) {}
  list() { return this.db.fxRates.toArray(); }
  async addAutomatic(records: FxRate[]): Promise<FxRate[]> {
    const valid = records.map((record) => fxRateSchema.parse(record));
    return this.db.transaction('rw', this.db.fxRates, async () => {
      const current = latestRates(await this.list());
      // A first confirmed quote is immutable. Never silently reprice old reports.
      for (const record of valid) if (!current.has(record.rateDate)) {
        await this.db.fxRates.add(record);
        current.set(record.rateDate, record);
      }
      return this.list();
    });
  }
  async revise(record: FxRate, expectedRevision: number): Promise<FxRate[]> {
    const valid = fxRateSchema.parse(record);
    return this.db.transaction('rw', this.db.fxRates, async () => {
      const old = latestRates(await this.list()).get(record.rateDate);
      if ((old?.revision ?? 0) !== expectedRevision) throw new Error('汇率已在其他窗口更新，请重新打开后重试');
      if (valid.revision !== expectedRevision + 1) throw new Error('汇率版本不正确');
      await this.db.fxRates.add(valid);
      return this.list();
    });
  }
}
