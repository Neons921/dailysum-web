import { EMPTY_FILTER_PREFERENCES, filterPreferencesSchema, reportRulesSchema, savedReportFilterSchema, type FilterPreferences, type ReportRules, type SavedReportFilter } from '../domain/reportFilters';
import type { LedgerDatabase } from './db';

export class ReportFilterRepository {
  constructor(readonly db: LedgerDatabase) {}
  private get table() { return this.db.table<FilterPreferences, string>('settings'); }
  async read(): Promise<FilterPreferences> { return filterPreferencesSchema.parse(await this.table.get('report-views') ?? structuredClone(EMPTY_FILTER_PREFERENCES)); }
  async save(name: string, rules: ReportRules, previous?: SavedReportFilter): Promise<FilterPreferences> {
    const clean = reportRulesSchema.parse(rules);
    return this.db.transaction('rw', this.table, async () => {
      const preferences = await this.read();
      const old = previous && preferences.views.find((view) => view.id === previous.id);
      if (previous && (!old || old.updatedAt !== previous.updatedAt)) throw new Error('过滤器已在其他窗口变更，请重新打开后重试');
      const time = new Date(Math.max(Date.now(), old ? Date.parse(old.updatedAt) + 1 : 0)).toISOString();
      const record = savedReportFilterSchema.parse({ id: old?.id ?? crypto.randomUUID(), name, rules: clean, createdAt: old?.createdAt ?? time, updatedAt: time });
      if (preferences.views.some((view) => view.id !== record.id && view.name.toLocaleLowerCase() === record.name.toLocaleLowerCase())) throw new Error('已有同名过滤器，请使用其他名称');
      const next = filterPreferencesSchema.parse({ ...preferences, activeId: record.id, views: [...preferences.views.filter((view) => view.id !== record.id), record] });
      await this.table.put(next);
      return next;
    });
  }
  async activate(id: string | null): Promise<FilterPreferences> {
    return this.db.transaction('rw', this.table, async () => {
      const preferences = await this.read();
      if (id && !preferences.views.some((view) => view.id === id)) throw new Error('该过滤器已不存在，请刷新列表');
      const next = { ...preferences, activeId: id };
      await this.table.put(next); return next;
    });
  }
  async remove(record: SavedReportFilter): Promise<FilterPreferences> {
    return this.db.transaction('rw', this.table, async () => {
      const preferences = await this.read();
      const current = preferences.views.find((view) => view.id === record.id);
      if (!current || current.updatedAt !== record.updatedAt) throw new Error('过滤器已在其他窗口变更，请刷新后重试');
      const next = { ...preferences, activeId: preferences.activeId === record.id ? null : preferences.activeId, views: preferences.views.filter((view) => view.id !== record.id) };
      await this.table.put(next); return next;
    });
  }
}
