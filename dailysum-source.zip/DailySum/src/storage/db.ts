import Dexie, { type Table } from 'dexie';
import type { Category, FxRate, Transaction, UserSettings } from '../domain/models';

export type SettingsRecord = UserSettings & { id: 'user' };

export class LedgerDatabase extends Dexie {
  transactions!: Table<Transaction, string>;
  categories!: Table<Category, string>;
  settings!: Table<SettingsRecord, string>;
  fxRates!: Table<FxRate, string>;
  migrations!: Table<{ id: string; appliedAt: string }, string>;

  constructor(name = 'dailysum') {
    super(name);
    this.version(1).stores({
      transactions: '&id, occurredOn, type, currency, categoryId, updatedAt',
      categories: '&id, type, sortOrder',
      settings: '&id',
      fxRates: '&id, rateDate, [baseCurrency+quoteCurrency]',
      migrations: '&id',
    });
  }
}
