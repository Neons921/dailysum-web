import { z } from 'zod';
import { emptySyncProfile, profileKey, syncProfileSchema, type SyncProfile } from '../domain/sync';
import type { LedgerDatabase } from './db';

// Device-only record. LedgerData, checkpoints and portable backups deliberately omit it.
export const GITHUB_CONNECTION_KEY = 'github-connection';
const connectionSchema = z.object({
  id: z.literal(GITHUB_CONNECTION_KEY), version: z.literal(1), revision: z.uuid(),
  target: z.string().min(1), token: z.string().trim().min(1).max(8192).regex(/^\S+$/), savedAt: z.iso.datetime(),
});
export type SavedGitHubConnection = z.infer<typeof connectionSchema>;

export class GitHubConnectionRepository {
  constructor(readonly db: LedgerDatabase) {}
  private get table() { return this.db.table<{id:string;[key:string]:unknown},string>('settings'); }

  async read(): Promise<{profile:SyncProfile;connection:SavedGitHubConnection|null}> {
    return this.db.transaction('r',this.table,async()=>{
      const profile=syncProfileSchema.parse(await this.table.get('github-sync')??emptySyncProfile());
      const raw=await this.table.get(GITHUB_CONNECTION_KEY);
      if(!raw)return {profile,connection:null};
      const connection=connectionSchema.safeParse(raw);
      if(!connection.success)throw new Error('已保存的 GitHub 连接不完整，请重新连接');
      if(connection.data.target!==profileKey(profile))throw new Error('已保存的 GitHub 连接与仓库不匹配，请重新连接');
      return {profile,connection:connection.data};
    });
  }

  async configure(profile:SyncProfile,token:string|null): Promise<SavedGitHubConnection|null> {
    const checked=syncProfileSchema.parse(profile);
    const connection=token===null?null:connectionSchema.parse({id:GITHUB_CONNECTION_KEY,version:1,revision:crypto.randomUUID(),
      target:profileKey(checked),token,savedAt:new Date().toISOString()});
    await this.db.transaction('rw',this.table,async()=>{
      await this.table.put(checked);
      if(connection)await this.table.put(connection);else await this.table.delete(GITHUB_CONNECTION_KEY);
    });
    return connection;
  }

  async forget(revision:string):Promise<boolean> {
    return this.db.transaction('rw',this.table,async()=>{
      // A rejected old request must not remove a replacement token saved in another window.
      const current=await this.table.get(GITHUB_CONNECTION_KEY);
      if(current?.revision!==revision)return false;
      await this.table.delete(GITHUB_CONNECTION_KEY);return true;
    });
  }
}
