import type { Table } from 'dexie';
import { latestRates } from '../domain/fx';
import { dataSignature, fromSnapshot, same, validateData, type LedgerData, type LedgerEnvelope, type SourceArchive } from '../domain/portable';
import { emptySyncProfile, profileKey, syncProfileSchema, type SyncProfile } from '../domain/sync';
import type { LedgerDatabase } from './db';
import { LedgerRepository } from './ledgerRepository';
import { fallbackCategoryId, normalizeCategorySettings, normalizeCategoryTransactions } from '../domain/categories';
import type { Category } from '../domain/models';

export type Checkpoint = {id:string;label:string;createdAt:string;data:LedgerData};
type SettingValue = {id:string;[key:string]:unknown};
export class StaleLedgerError extends Error { constructor(){super('账本在预览后已有新变更，请重新检查；原数据已保留');this.name='StaleLedgerError';} }
export class DataRepository {
  private get settings():Table<SettingValue,string> { return this.db.table('settings'); }
  constructor(readonly db:LedgerDatabase) {}
  async identity():Promise<string> {
    return this.db.transaction('rw',this.db.settings,async()=>{
      const stored=await this.settings.get('data-identity'); if (typeof stored?.ledgerId==='string') return stored.ledgerId;
      const ledgerId=crypto.randomUUID(); await this.settings.put({id:'data-identity',ledgerId}); return ledgerId;
    });
  }
  async profile():Promise<SyncProfile> { return syncProfileSchema.parse(await this.settings.get('github-sync') ?? emptySyncProfile()); }
  async setProfile(profile:SyncProfile):Promise<void> { await this.settings.put(syncProfileSchema.parse(profile)); }
  async archives():Promise<SourceArchive[]> {
    const records=await this.settings.where('id').startsWith('archive:').toArray(); return records.map((row)=>row.archive as SourceArchive);
  }
  async read():Promise<LedgerData> {
    return this.db.transaction('r',this.db.transactions,this.db.categories,this.db.settings,this.db.fxRates,async()=>fromSnapshot(await new LedgerRepository(this.db).snapshot(),await this.archives()));
  }
  async checkpoints():Promise<Checkpoint[]> {
    return (await this.settings.where('id').startsWith('checkpoint:').toArray()).map((row)=>row as unknown as Checkpoint).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  }
  async assertCurrent(signature:string):Promise<void> { if(dataSignature(await this.read())!==signature) throw new StaleLedgerError(); }
  async deleteCategory(category: Category): Promise<void> {
    const before = await this.read();
    const current = before.categories.find((row) => row.id === category.id);
    if (!current || current.mergedIntoId || !same(current, category)) {
      throw new Error('这个分类已在其他窗口或设备变更，请重新打开后再试');
    }
    const fallbackId = fallbackCategoryId(current.type);
    if (current.id === fallbackId) throw new Error('请保留用于接收旧账目的默认分类');
    const categories = before.categories.map((row) => row.id === current.id ? { ...row, mergedIntoId: fallbackId } : row);
    const transactions = normalizeCategoryTransactions(before.transactions, categories);
    await this.commit({ ...before, categories, transactions }, dataSignature(before), `删除分类 ${current.name}`);
  }
  async commit(data:LedgerData,expectedSignature:string,label:string,options?:{sync?:{profile:SyncProfile;envelope:LedgerEnvelope;sha:string;connectionRevision?:string|null}}):Promise<void> {
    const checked=validateData(data);
    await this.db.transaction('rw',this.db.transactions,this.db.categories,this.db.settings,this.db.fxRates,async()=>{
      const before=await this.read(); if(dataSignature(before)!==expectedSignature) throw new StaleLedgerError();
      if(options?.sync && profileKey(await this.profile())!==profileKey(options.sync.profile)) throw new Error('同步仓库配置已变更，请重新检查连接');
      if(options?.sync)await this.assertConnection(options.sync.connectionRevision);
      const now=new Date().toISOString();
      const checkpoint:Checkpoint={id:`checkpoint:${now}:${crypto.randomUUID()}`,label,createdAt:now,data:before};
      await this.settings.put(checkpoint as unknown as SettingValue);
      let settings=checked.settings, filters=checked.filterPreferences;
      if(options?.sync) {
        settings={...before.settings,reportCurrency:checked.settings.reportCurrency};
        filters={...checked.filterPreferences,activeId:checked.filterPreferences.views.some((view)=>view.id===before.filterPreferences.activeId)?before.filterPreferences.activeId:null};
      }
      await this.db.transactions.clear(); await this.db.transactions.bulkPut(checked.transactions);
      await this.db.categories.clear(); await this.db.categories.bulkPut(checked.categories);
      await this.db.fxRates.clear(); await this.db.fxRates.bulkPut(checked.fxRates);
      await this.db.settings.put({id:'user',...normalizeCategorySettings(settings,checked.categories)});
      await this.settings.put(filters);
      const archiveIds=await this.settings.where('id').startsWith('archive:').primaryKeys();
      await this.settings.bulkDelete(archiveIds);
      await this.settings.bulkPut(checked.archives.map((archive)=>({id:`archive:${archive.id}`,archive})));
      if(options?.sync) await this.settings.put({...await this.profile(),baseline:options.sync.envelope,lastRemoteSha:options.sync.sha,lastSyncAt:now});
      const points=await this.checkpoints(); await this.settings.bulkDelete(points.slice(3).map((point)=>point.id));
    });
  }
  private async assertConnection(revision:string|null|undefined):Promise<void> {
    if(revision!==undefined&&((await this.settings.get('github-connection'))?.revision??null)!==revision)throw new Error('GitHub 连接已变化，请重新检查同步');
  }
  async markSynchronized(profile:SyncProfile,envelope:LedgerEnvelope,sha:string,expectedSignature:string,connectionRevision?:string|null):Promise<void> {
    await this.db.transaction('rw',this.db.transactions,this.db.categories,this.db.settings,this.db.fxRates,async()=>{
      if(dataSignature(await this.read())!==expectedSignature) throw new StaleLedgerError();
      if(profileKey(await this.profile())!==profileKey(profile)) throw new Error('同步配置已变更');
      await this.assertConnection(connectionRevision);
      await this.settings.put({...await this.profile(),baseline:envelope,lastRemoteSha:sha,lastSyncAt:new Date().toISOString()});
    });
  }
  async restore(point:Checkpoint):Promise<void> {
    const current=await this.read(), old=validateData(point.data), now=new Date().toISOString();
    const selected=new Map(old.transactions.map((row)=>[row.id,row]));
    const transactions=current.transactions.map((row)=>{
      const previous=selected.get(row.id); selected.delete(row.id);
      if(!previous) return row.deletedAt?row:{...row,deletedAt:now,updatedAt:now};
      return same(previous,row)?row:{...previous,updatedAt:now};
    });
    transactions.push(...selected.values());
    const union=<T extends {id:string}>(a:T[],b:T[])=>[...new Map([...a,...b].map((row)=>[row.id,row])).values()];
    const fxRates=union(current.fxRates,old.fxRates), currentRates=latestRates(current.fxRates);
    for(const [date,rate] of latestRates(old.fxRates)) if(currentRates.has(date) && !same(rate,currentRates.get(date))) {
      fxRates.push({...rate,id:crypto.randomUUID(),revision:Math.max(...fxRates.filter((row)=>row.rateDate===date).map((row)=>row.revision))+1});
    }
    await this.commit({...old,transactions,fxRates,categories:union(current.categories,old.categories),archives:union(current.archives,old.archives)},dataSignature(current),`恢复至 ${point.createdAt}`);
  }
  async rawCentRecord(archiveId:string,sourceId:string):Promise<{archive:SourceArchive;record:Record<string,unknown>}|null> {
    const saved=await this.settings.get(`archive:${archiveId}`); if(!saved) return null;
    const archive=saved.archive as SourceArchive;
    const raw=archive.data as {items?:Record<string,unknown>[]};
    const record=raw.items?.find((row)=>row.id===sourceId); return record?{archive,record}:null;
  }
}
