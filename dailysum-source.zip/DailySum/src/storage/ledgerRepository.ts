import {
  DEFAULT_CATEGORIES, DEFAULT_SETTINGS, settingsSchema, transactionToDraft,
  type LedgerChange, type LedgerSnapshot, type Transaction, type UserSettings,
} from '../domain/models';
import { LedgerDatabase } from './db';
import { ReportFilterRepository } from './reportFilterRepository';
import { normalizeCategoryTransactions } from '../domain/categories';

function nextTimestamp(previous?: string): string {
  return new Date(Math.max(Date.now(), previous ? Date.parse(previous) + 1 : 0)).toISOString();
}

export class LedgerRepository {
  constructor(readonly db: LedgerDatabase) {}

  category(id: string) { return this.db.categories.get(id); }

  async initialize(): Promise<LedgerSnapshot> {
    await this.db.transaction('rw', this.db.settings, this.db.categories, this.db.migrations, async () => {
      if (!(await this.db.settings.get('user'))) {
        await this.db.settings.add({ id: 'user', ...DEFAULT_SETTINGS });
      }
      const existing = new Set(await this.db.categories.toCollection().primaryKeys());
      await this.db.categories.bulkAdd(DEFAULT_CATEGORIES.filter((category) => !existing.has(category.id)));
      if (!(await this.db.migrations.get('v1'))) {
        await this.db.migrations.put({ id: 'v1', appliedAt: new Date().toISOString() });
      }
    });
    return this.snapshot();
  }

  async snapshot(): Promise<LedgerSnapshot> {
    return this.db.transaction('r', this.db.transactions, this.db.categories, this.db.settings, this.db.fxRates, async () => {
      const record = await this.db.settings.get('user');
      if (!record) throw new Error('账本尚未初始化，请重新打开应用');
      return {
        transactions: await this.db.transactions.toArray(),
        categories: (await this.db.categories.toArray()).sort((a, b) => Number(a.type === 'income') - Number(b.type === 'income') || a.sortOrder - b.sortOrder),
        settings: settingsSchema.parse(record),
        fxRates: await this.db.fxRates.toArray(),
        filterPreferences: await new ReportFilterRepository(this.db).read(),
      };
    });
  }

  async save(record: Transaction, expectedUpdatedAt: string | null): Promise<{ change: LedgerChange; settings: UserSettings }> {
    return this.db.transaction('rw', this.db.transactions, this.db.settings, async () => {
      const current = await this.db.transactions.get(record.id);
      const settingsRecord = await this.db.settings.get('user');
      if (!settingsRecord) throw new Error('账本尚未初始化');
      // A retried create uses the same UUID. It must never create a second row.
      if (expectedUpdatedAt === null && current) {
        if (!current.deletedAt && JSON.stringify(transactionToDraft(current)) === JSON.stringify(transactionToDraft(record))) {
          return { change: { kind: 'create' as const, before: null, after: current }, settings: settingsSchema.parse(settingsRecord) };
        }
        throw new Error('这次提交已被处理，请重新打开记账窗口');
      }
      if (expectedUpdatedAt !== null && (!current || current.deletedAt || current.updatedAt !== expectedUpdatedAt)) {
        throw new Error('这笔记录已在其他窗口中变更，请关闭弹窗并刷新后重试');
      }
      const saved = { ...record, createdAt: current?.createdAt ?? record.createdAt, updatedAt: nextTimestamp(current?.updatedAt) };
      const settings = settingsSchema.parse({
        ...settingsRecord,
        inputCurrency: saved.currency,
        lastTransactionType: saved.type,
        ...(saved.type === 'expense'
          ? { lastExpenseCategoryId: saved.categoryId }
          : { lastIncomeCategoryId: saved.categoryId }),
      });
      await this.db.transactions.put(saved);
      await this.db.settings.put({ id: 'user', ...settings });
      return { change: { kind: current ? 'update' : 'create', before: current ?? null, after: saved }, settings };
    });
  }

  async remove(record: Transaction): Promise<LedgerChange> {
    return this.db.transaction('rw', this.db.transactions, async () => {
      const current = await this.db.transactions.get(record.id);
      if (!current || current.deletedAt || current.updatedAt !== record.updatedAt) {
        throw new Error('这笔记录已变更，请刷新页面后重试');
      }
      const time = nextTimestamp(current.updatedAt);
      const after = { ...current, deletedAt: time, updatedAt: time };
      await this.db.transactions.put(after);
      return { kind: 'delete', before: current, after };
    });
  }

  async undo(change: LedgerChange): Promise<Transaction> {
    return this.db.transaction('rw', this.db.transactions,this.db.categories, async () => {
      const current = await this.db.transactions.get(change.after.id);
      if (!current || current.updatedAt !== change.after.updatedAt) {
        throw new Error('记录已被再次修改，无法撤销；请在明细中编辑');
      }
      const time = nextTimestamp(current.updatedAt);
      const restored: Transaction = change.kind === 'create'
        ? { ...current, deletedAt: time, updatedAt: time }
        : { ...change.before!, updatedAt: time };
      const normalized=normalizeCategoryTransactions([restored],await this.db.categories.toArray())[0];
      await this.db.transactions.put(normalized);
      return normalized;
    });
  }

  async updateSettings(patch: Partial<UserSettings>): Promise<UserSettings> {
    return this.db.transaction('rw', this.db.settings, async () => {
      const current = await this.db.settings.get('user');
      if (!current) throw new Error('账本尚未初始化');
      const settings = settingsSchema.parse({ ...current, ...patch });
      await this.db.settings.put({ id: 'user', ...settings });
      return settings;
    });
  }
}
