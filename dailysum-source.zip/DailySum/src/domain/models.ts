import { z } from 'zod';
import type { FilterPreferences } from './reportFilters';

export const currencySchema = z.enum(['HKD', 'CNY']);
export const transactionTypeSchema = z.enum(['expense', 'income']);
export type Currency = z.infer<typeof currencySchema>;
export type TransactionType = z.infer<typeof transactionTypeSchema>;

export const MAX_AMOUNT_MINOR = 9_999_999_999;
export const MAX_AMOUNT_LABEL = '99,999,999.99';
export const MAX_NOTE_LENGTH = 10_000;

export function isValidDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

export const dateSchema = z.string().refine(isValidDate, '请选择有效的日期');

export const draftSchema = z.object({
  type: transactionTypeSchema,
  amountMinor: z.number().int().positive().max(MAX_AMOUNT_MINOR),
  currency: currencySchema,
  categoryId: z.string().min(1),
  note: z.string().max(MAX_NOTE_LENGTH, '备注最多 10000 字'),
  occurredOn: dateSchema,
});
export type TransactionDraft = z.infer<typeof draftSchema>;

export const transactionSchema = draftSchema.extend({
  id: z.uuid(),
  createdAt: z.iso.datetime(),
  updatedAt: z.iso.datetime(),
  deletedAt: z.iso.datetime().nullable(),
  schemaVersion: z.literal(1),
  categoryHistory: z.array(z.string().min(1)).max(100).optional(),
  origin: z.object({ format: z.literal('cent'), sourceId: z.string().min(1).max(200), archiveId: z.string(),
    fingerprint: z.string(), importedDraft: z.string(), amount10000: z.string(), currency: z.string(), originalTime: z.number().finite(),
  }).optional(),
});
export type Transaction = z.infer<typeof transactionSchema>;

export const categorySchema = z.object({ id: z.string().min(1).max(250), name: z.string().min(1).max(200), type: transactionTypeSchema,
  icon: z.string().max(100), color: z.string().max(50), sortOrder: z.number().int().nonnegative(),
  parentId: z.string().optional(), sourceCategoryId: z.string().optional(), mergedIntoId: z.string().min(1).optional(),
});
export type Category = z.infer<typeof categorySchema>;

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'food', name: '餐饮', type: 'expense', icon: 'food', color: 'orange', sortOrder: 0 },
  { id: 'transport', name: '交通', type: 'expense', icon: 'transport', color: 'blue', sortOrder: 1 },
  { id: 'shopping', name: '购物', type: 'expense', icon: 'shopping', color: 'purple', sortOrder: 2 },
  { id: 'living', name: '生活', type: 'expense', icon: 'living', color: 'green', sortOrder: 3 },
  { id: 'fun', name: '娱乐', type: 'expense', icon: 'fun', color: 'pink', sortOrder: 4 },
  { id: 'health', name: '医疗', type: 'expense', icon: 'health', color: 'red', sortOrder: 5 },
  { id: 'other-expense', name: '其他', type: 'expense', icon: 'other', color: 'gray', sortOrder: 6 },
  { id: 'salary', name: '工资', type: 'income', icon: 'work', color: 'green', sortOrder: 0 },
  { id: 'bonus', name: '奖金', type: 'income', icon: 'bonus', color: 'orange', sortOrder: 1 },
  { id: 'parttime', name: '兼职', type: 'income', icon: 'work', color: 'blue', sortOrder: 2 },
  { id: 'gift', name: '红包', type: 'income', icon: 'gift', color: 'pink', sortOrder: 3 },
  { id: 'refund', name: '退款', type: 'income', icon: 'refund', color: 'purple', sortOrder: 4 },
  { id: 'other-income', name: '其他', type: 'income', icon: 'other', color: 'gray', sortOrder: 5 },
];

export const settingsSchema = z.object({
  inputCurrency: currencySchema,
  reportCurrency: currencySchema,
  lastTransactionType: transactionTypeSchema,
  lastExpenseCategoryId: z.string(),
  lastIncomeCategoryId: z.string(),
  timezone: z.literal('Asia/Hong_Kong'),
  dataVersion: z.literal(1),
});
export type UserSettings = z.infer<typeof settingsSchema>;
export const DEFAULT_SETTINGS: UserSettings = {
  inputCurrency: 'HKD',
  reportCurrency: 'HKD',
  lastTransactionType: 'expense',
  lastExpenseCategoryId: 'food',
  lastIncomeCategoryId: 'salary',
  timezone: 'Asia/Hong_Kong',
  dataVersion: 1,
};

export type FxRate = {
  id: string;
  rateDate: string;
  sourceDate: string;
  baseCurrency: 'CNY';
  quoteCurrency: 'HKD';
  rate: string;
  source: string;
  fetchedAt: string;
  isManual: boolean;
  revision: number;
  sourceRates?: { EUR_CNY: string; EUR_HKD: string };
};

export type LedgerSnapshot = {
  transactions: Transaction[];
  categories: Category[];
  settings: UserSettings;
  fxRates: FxRate[];
  filterPreferences: FilterPreferences;
};

export type LedgerChange = {
  kind: 'create' | 'update' | 'delete';
  before: Transaction | null;
  after: Transaction;
};

export function transactionToDraft(transaction: Transaction): TransactionDraft {
  const { type, amountMinor, currency, categoryId, note, occurredOn } = transaction;
  return { type, amountMinor, currency, categoryId, note, occurredOn };
}
