import { DEFAULT_CATEGORIES, type Category, type Transaction, type UserSettings } from './models';
import type { LedgerData } from './portable';

export const activeCategories=(categories:Category[])=>categories.filter((category)=>!category.mergedIntoId);
const defaults=new Set(DEFAULT_CATEGORIES.map((category)=>category.id));
export const hasCompactCategories=(categories:Category[])=>categories.some((category)=>category.sourceCategoryId&&category.mergedIntoId)&&activeCategories(categories).every((category)=>!category.sourceCategoryId||defaults.has(category.id));
export const fallbackCategoryId=(type:Category['type'])=>type==='income'?'other-income':'other-expense';

export function resolveCategory(id:string,categories:ReadonlyMap<string,Category>):{category:Category;history:string[]} {
  const history:string[]=[];let category=categories.get(id);
  if(!category)throw new Error('找不到账目分类');
  while(category.mergedIntoId){
    if(history.includes(category.id)||history.length>=100)throw new Error('分类合并存在循环或层级过深');
    history.push(category.id);const target=categories.get(category.mergedIntoId);
    if(!target||target.type!==category.type)throw new Error('分类合并目标缺失或收支类型不符');
    category=target;
  }
  return {category,history};
}

export function normalizeCategoryTransactions(rows:Transaction[],categories:Category[]):Transaction[] {
  const dictionary=new Map(categories.map((category)=>[category.id,category]));
  return rows.map((row)=>{
    const resolved=resolveCategory(row.categoryId,dictionary);
    if(!resolved.history.length)return row;
    const categoryHistory=[...new Set([...(row.categoryHistory??[]),...resolved.history])].sort();
    return {...row,categoryId:resolved.category.id,categoryHistory};
  });
}
export function normalizeCategorySettings(settings:UserSettings,categories:Category[]):UserSettings {
  const dictionary=new Map(categories.map((category)=>[category.id,category]));
  const expense=dictionary.has(settings.lastExpenseCategoryId)?resolveCategory(settings.lastExpenseCategoryId,dictionary).category.id:'food';
  const income=dictionary.has(settings.lastIncomeCategoryId)?resolveCategory(settings.lastIncomeCategoryId,dictionary).category.id:'salary';
  return expense===settings.lastExpenseCategoryId&&income===settings.lastIncomeCategoryId?settings:{...settings,lastExpenseCategoryId:expense,lastIncomeCategoryId:income};
}

const expenseRoots:Record<string,string>={food:'food',transport:'transport',shopping:'shopping',housing:'living',entertainment:'fun',medical:'health',education:'other-expense',relationship:'other-expense','other-expenses':'other-expense'};
const incomeLeaves:Record<string,string>={wage:'salary','part-time':'parttime','hongbao-income':'gift','gifts-income':'gift',refund:'refund',drawback:'other-income',lean:'other-income','relationship-income':'other-income','other-income':'other-income','balance-account-income':'other-income'};

/** Uses category ancestry and explicit labels; it never guesses from the monetary amount or note. */
export function compactCategoryTarget(category:Category,categories:Category[]):string {
  const dictionary=new Map(categories.map((row)=>[row.id,row]));
  if(category.mergedIntoId){const target=resolveCategory(category.id,dictionary).category;if(defaults.has(target.id))return target.id;}
  if(defaults.has(category.id))return category.id;
  let root=category;const seen=new Set<string>();
  while(root.parentId){
    if(seen.has(root.id))throw new Error('分类父子关系存在循环');seen.add(root.id);
    const parent=dictionary.get(root.parentId);if(!parent)throw new Error('分类的父类缺失');root=parent;
  }
  const name=category.name,rootName=root.name.split(' / ')[0];
  if(category.type==='income'){
    if(/奖金|奖励|奖学金|年终奖/.test(name))return 'bonus';
    if(/兼职|副业/.test(name))return 'parttime';
    if(/退款|退货/.test(name))return 'refund';
    if(/红包|礼金|礼物/.test(name))return 'gift';
    if(incomeLeaves[category.sourceCategoryId??''])return incomeLeaves[category.sourceCategoryId!];
    if(incomeLeaves[root.sourceCategoryId??''])return incomeLeaves[root.sourceCategoryId!];
    return /工资|薪资|薪水/.test(rootName)?'salary':'other-income';
  }
  if(expenseRoots[root.sourceCategoryId??''])return expenseRoots[root.sourceCategoryId!];
  if(/餐饮|吃饭|食品|饮食/.test(rootName))return 'food';
  if(/交通|出行/.test(rootName))return 'transport';
  if(/购物/.test(rootName))return 'shopping';
  if(/居住|生活|房租|水电|通讯/.test(rootName))return 'living';
  if(/娱乐|旅行|运动/.test(rootName))return 'fun';
  if(/医疗|健康/.test(rootName))return 'health';
  return 'other-expense';
}

export function consolidateCategories(data:LedgerData):{data:LedgerData;mapping:{id:string;name:string;targetId:string;targetName:string;activeRecords:number;allRecords:number}[]} {
  const categories=[...data.categories];
  for(const preset of DEFAULT_CATEGORIES)if(!categories.some((category)=>category.id===preset.id))categories.push({...preset});
  const mapping=categories.filter((category)=>!defaults.has(category.id)).map((category)=>{
    const targetId=compactCategoryTarget(category,categories),target=categories.find((row)=>row.id===targetId);
    if(!target||target.type!==category.type)throw new Error('分类整理的收支类型不符');
    return {id:category.id,name:category.name,targetId,targetName:target.name,activeRecords:data.transactions.filter((row)=>row.categoryId===category.id&&!row.deletedAt).length,allRecords:data.transactions.filter((row)=>row.categoryId===category.id).length};
  });
  const targets=new Map(mapping.map((entry)=>[entry.id,entry.targetId]));
  const merged=categories.map((category)=>targets.has(category.id)?{...category,mergedIntoId:targets.get(category.id)!}:category);
  return {data:{...data,categories:merged,transactions:normalizeCategoryTransactions(data.transactions,merged),settings:normalizeCategorySettings(data.settings,merged)},mapping};
}
