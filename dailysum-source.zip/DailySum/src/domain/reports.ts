import type Decimal from 'decimal.js';
import type { Category, Currency, FxRate, Transaction, TransactionType } from './models';
import { amountToInput } from './money';
import { offsetDay, rangeDays, type DateRange } from './dates';
import { convertedMinor, latestRates, MoneyDecimal, roundMinor } from './fx';
import { evaluateReportRule, type ReportRules } from './reportFilters';

export type ReportFilters = DateRange & { type: TransactionType | ''; currency: Currency | ''; categoryId: string; query: string; rules?: ReportRules };
export type ReportTotal = { raw: Decimal; amount: bigint; count: number; missing: number };
export type Report = { income: ReportTotal; expense: ReportTotal; net: bigint | null; count: number; missing: number; activeDays: number; maxExpense: { transaction: Transaction; amount: bigint } | null };
export type Grain = 'day' | 'week' | 'month';
export type TrendPoint = { from: string; to: string; label: string; report: Report };
export type CategoryTotal = { category: Category; total: ReportTotal; share: number };

export type ReportSelection = { matched: Transaction[]; pending: Transaction[]; excluded: { transaction: Transaction; reason: string }[] };
export function selectReportTransactions(transactions: Transaction[], filters: ReportFilters, categories: Category[], rates: FxRate[] = [], skipAmount = false): ReportSelection {
  const names = new Map(categories.map((category) => [category.id, category.name]));
  const query = filters.query.trim().toLocaleLowerCase();
  const candidates = transactions.filter((row) => !row.deletedAt && row.occurredOn >= filters.from && row.occurredOn <= filters.to
    && (!filters.type || row.type === filters.type) && (!filters.currency || row.currency === filters.currency)
    && (!filters.categoryId || row.categoryId === filters.categoryId)
    && (!query || [row.note,names.get(row.categoryId),row.currency,row.occurredOn,amountToInput(row.amountMinor),...(row.categoryHistory??[]).map((id)=>names.get(id))].join(' ').toLocaleLowerCase().includes(query)));
  const result: ReportSelection = { matched: [], excluded: [], pending: [] };
  const map = latestRates(rates);
  for (const row of candidates) {
    const outcome = filters.rules ? evaluateReportRule(row, filters.rules, map, skipAmount) : { state: 'match', reason: '' };
    if (outcome.state === 'match') result.matched.push(row);
    else if (outcome.state === 'pending') result.pending.push(row);
    else result.excluded.push({ transaction: row, reason: outcome.reason });
  }
  return result;
}
export function filterTransactions(transactions: Transaction[], filters: ReportFilters, categories: Category[], rates: FxRate[] = []): Transaction[] {
  return selectReportTransactions(transactions, filters, categories, rates).matched;
}
export function summarizeSelection(selection: ReportSelection, currency: Currency, rates: FxRate[]): Report {
  const report = summarizeConverted(selection.matched, currency, rates);
  for (const row of selection.pending) { report[row.type].missing++; report.missing++; }
  if (report.missing) report.net = null;
  if (report.expense.missing) report.maxExpense = null;
  return report;
}

export function summarizeConverted(transactions: Transaction[], currency: Currency, records: FxRate[]): Report {
  const rates = latestRates(records);
  const total = (): ReportTotal => ({ raw: new MoneyDecimal(0), amount: 0n, count: 0, missing: 0 });
  const income = total(), expense = total();
  const days = new Set<string>();
  let max: { transaction: Transaction; raw: Decimal } | null = null;
  for (const row of transactions) {
    if (row.deletedAt) continue;
    const group = row.type === 'income' ? income : expense;
    group.count++;
    days.add(row.occurredOn);
    const amount = convertedMinor(row, currency, rates);
    if (amount === null) { group.missing++; continue; }
    group.raw = group.raw.add(amount);
    if (row.type === 'expense' && (!max || amount.gt(max.raw))) max = { transaction: row, raw: amount };
  }
  income.amount = roundMinor(income.raw);
  expense.amount = roundMinor(expense.raw);
  const missing = income.missing + expense.missing;
  return { income, expense, net: missing ? null : income.amount - expense.amount,
    count: income.count + expense.count, missing, activeDays: days.size,
    maxExpense: expense.missing || !max ? null : { transaction: max.transaction, amount: roundMinor(max.raw) } };
}

export function categoryTotals(transactions: Transaction[], categories: Category[], type: TransactionType, currency: Currency, rates: FxRate[]): CategoryTotal[] {
  const total = summarizeConverted(transactions.filter((row) => row.type === type), currency, rates)[type];
  return categories.filter((category) => category.type === type).map((category) => {
    const group = summarizeConverted(transactions.filter((row) => row.categoryId === category.id), currency, rates)[type];
    return { category, total: group, share: total.raw.gt(0) ? group.raw.div(total.raw).toNumber() : 0 };
  }).filter((row) => row.total.count).sort((a, b) => b.total.raw.comparedTo(a.total.raw));
}

export function defaultGrain(range: DateRange): Grain {
  const days = rangeDays(range);
  return days > 180 ? 'month' : days > 62 ? 'week' : 'day';
}

export function trendPoints(transactions: Transaction[], range: DateRange, grain: Grain, currency: Currency, rates: FxRate[]): TrendPoint[] {
  const result: TrendPoint[] = [];
  // Reject unbounded custom ranges before producing SVG / doing expensive grouping.
  if (!rangeDays(range) || rangeDays(range) > 3660) return result;
  let day = range.from;
  while (day <= range.to) {
    let end = day;
    if (grain === 'week') {
      const weekday = new Date(`${day}T12:00:00Z`).getUTCDay();
      end = offsetDay(day, 6 - (weekday + 6) % 7);
    } else if (grain === 'month') {
      const date = new Date(`${day}T12:00:00Z`);
      date.setUTCMonth(date.getUTCMonth() + 1, 0);
      end = date.toISOString().slice(0, 10);
    }
    if (end > range.to) end = range.to;
    result.push({ from: day, to: end, label: grain === 'month' ? (range.from.slice(0, 4) !== range.to.slice(0, 4) ? `${day.slice(2, 4)}/${Number(day.slice(5, 7))}` : `${Number(day.slice(5, 7))} 月`) : `${Number(day.slice(5, 7))}/${Number(day.slice(8))}`,
      report: summarizeConverted(transactions.filter((row) => row.occurredOn >= day && row.occurredOn <= end), currency, rates) });
    day = offsetDay(end, 1);
  }
  return result;
}

export function changePercent(current: ReportTotal, previous: ReportTotal): string | null {
  if (current.missing || previous.missing || previous.raw.isZero()) return null;
  const percent = current.raw.sub(previous.raw).div(previous.raw).mul(100);
  return `${percent.gte(0) ? '+' : '−'}${percent.abs().toFixed(1)}%`;
}
