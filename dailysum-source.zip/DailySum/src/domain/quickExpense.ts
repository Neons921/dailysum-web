import { z } from 'zod';
import { resolveCategory } from './categories';
import { draftSchema, type Category } from './models';

export const quickExpenseSchema = draftSchema.pick({
  amountMinor: true, currency: true, categoryId: true, note: true,
}).extend({ enabled: z.boolean() });

export type QuickExpense = z.infer<typeof quickExpenseSchema>;

export const DEFAULT_QUICK_EXPENSE: QuickExpense = {
  enabled: true,
  amountMinor: 1180,
  currency: 'HKD',
  categoryId: 'transport',
  note: '',
};

export function quickExpenseCategory(categories: Category[], id: string): Category | undefined {
  const byId = new Map(categories.map((category) => [category.id, category]));
  if (byId.get(id)?.type === 'expense') return resolveCategory(id, byId).category;
}
