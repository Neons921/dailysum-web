import Decimal from 'decimal.js';
import { z } from 'zod';
import { dateSchema, type Currency, type FxRate, type Transaction } from './models';

// Financial values remain decimal strings / integer minor units until chart coordinates.
export const MoneyDecimal = Decimal.clone({ precision: 64, rounding: Decimal.ROUND_HALF_UP });
export const rateInputSchema = z.string().regex(/^\d{1,4}(\.\d{1,40})?$/, '请输入有效汇率，最多 40 位小数')
  .pipe(z.string().refine((value) => new MoneyDecimal(value).gt(0) && new MoneyDecimal(value).lte(1000), '汇率须大于 0 且不超过 1000'));
export const fxRateSchema = z.object({
  id: z.string().min(1), rateDate: dateSchema, sourceDate: dateSchema,
  baseCurrency: z.literal('CNY'), quoteCurrency: z.literal('HKD'), rate: rateInputSchema,
  source: z.string().min(1), fetchedAt: z.iso.datetime(), isManual: z.boolean(), revision: z.number().int().positive(),
  sourceRates: z.object({ EUR_CNY: rateInputSchema, EUR_HKD: rateInputSchema }).optional(),
}).refine((value) => value.sourceDate <= value.rateDate, '报价日不得晚于适用日');

export function latestRates(rates: FxRate[]): Map<string, FxRate> {
  const result = new Map<string, FxRate>();
  for (const record of rates) {
    const parsed = fxRateSchema.safeParse(record);
    if (!parsed.success) continue;
    const old = result.get(record.rateDate);
    if (!old || old.revision < record.revision) result.set(record.rateDate, parsed.data);
  }
  return result;
}

export function convertedMinor(transaction: Transaction, currency: Currency, rates: Map<string, FxRate>): Decimal | null {
  const amount = new MoneyDecimal(transaction.amountMinor);
  if (transaction.currency === currency) return amount;
  const rate = rates.get(transaction.occurredOn);
  if (!rate) return null;
  return currency === 'HKD' ? amount.mul(rate.rate) : amount.div(rate.rate);
}
export function roundMinor(value: Decimal): bigint {
  return BigInt(value.toDecimalPlaces(0, Decimal.ROUND_HALF_UP).toFixed(0));
}
export function missingRateDates(transactions: Transaction[], currency: Currency, rates: FxRate[]): string[] {
  const known = latestRates(rates);
  return [...new Set(transactions.filter((row) => !row.deletedAt && row.currency !== currency && !known.has(row.occurredOn)).map((row) => row.occurredOn))].sort();
}
