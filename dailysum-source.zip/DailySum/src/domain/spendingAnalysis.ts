import { monthRange, shiftMonth, type DateRange } from './dates';
import { convertedMinor, latestRates, MoneyDecimal, roundMinor } from './fx';
import type { Currency, FxRate, Transaction } from './models';
import { summarizeConverted, type ReportTotal } from './reports';

export const ROUTINE_CATEGORY_IDS = ['food', 'transport'] as const;
export const TOP_EXPENSE_COUNT = 5;

export function spendingPeriods(month: string, today: string) {
  const current = monthRange(month, today);
  const previous = monthRange(shiftMonth(month, -1), today);
  const monthToDate = month === today.slice(0, 7);
  if (!monthToDate) return { current, previous, monthToDate };
  const cutoff = `${previous.from.slice(0, 7)}${today.slice(7)}`;
  return { current, previous: { ...previous, to: cutoff < previous.to ? cutoff : previous.to }, monthToDate };
}

export function spendingRows(rows: Transaction[], range: DateRange) {
  return rows.filter((row) => row.type === 'expense' && !row.deletedAt && row.occurredOn >= range.from && row.occurredOn <= range.to);
}

export function spendingAnalysis(current: Transaction[], previous: Transaction[], currency: Currency, rates: FxRate[]) {
  const compare = (currentRows: Transaction[], previousRows: Transaction[]) => ({
    current: summarizeConverted(currentRows, currency, rates).expense,
    previous: summarizeConverted(previousRows, currency, rates).expense,
  });
  const total = compare(current, previous);
  const rateMap = latestRates(rates);
  const rank = (rows: Transaction[], expense: ReportTotal) => {
    if (expense.missing) return { rows: [], total: expense };
    const ranked = rows.flatMap((transaction) => {
      const raw = convertedMinor(transaction, currency, rateMap);
      return raw === null ? [] : [{ transaction, raw }];
    }).sort((a, b) => b.raw.comparedTo(a.raw) || b.transaction.occurredOn.localeCompare(a.transaction.occurredOn))
      .slice(0, TOP_EXPENSE_COUNT);
    const raw = ranked.reduce((sum, row) => sum.add(row.raw), new MoneyDecimal(0));
    return { rows: ranked, total: { raw, amount: roundMinor(raw), count: ranked.length, missing: 0 } };
  };
  const top = rank(current, total.current);
  const previousTop = rank(previous, total.previous);
  const largest = top.rows.map(({ transaction, raw }) => ({ transaction, amount: roundMinor(raw) }));
  const large = { current: top.total, previous: previousTop.total };

  const routineRows = (rows: Transaction[]) => rows.filter(({ categoryId }) => ROUTINE_CATEGORY_IDS.some((id) => id === categoryId));
  const routine = compare(routineRows(current), routineRows(previous));
  const categories = ROUTINE_CATEGORY_IDS.map((id) => ({ id, ...compare(current.filter((row) => row.categoryId === id), previous.filter((row) => row.categoryId === id)) }));
  return { total, largest, large, routine, categories };
}
