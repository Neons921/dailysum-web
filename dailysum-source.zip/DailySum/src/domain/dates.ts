export function hongKongToday(now = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Hong_Kong', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(now);
  const part = (type: string) => parts.find((value) => value.type === type)!.value;
  return `${part('year')}-${part('month')}-${part('day')}`;
}

export function shiftMonth(month: string, offset: number): string {
  const [year, value] = month.split('-').map(Number);
  const date = new Date(Date.UTC(year, value - 1 + offset, 1));
  return date.toISOString().slice(0, 7);
}

export function formatMonth(month: string): string {
  const [year, value] = month.split('-');
  return `${year} 年 ${Number(value)} 月`;
}

export function formatDay(date: string): { label: string; secondary: string } {
  const today = hongKongToday();
  const yesterday = new Date(`${today}T12:00:00Z`);
  yesterday.setUTCDate(yesterday.getUTCDate() - 1);
  const label = date === today ? '今天' : date === yesterday.toISOString().slice(0, 10) ? '昨天' : `${Number(date.slice(5, 7))} 月 ${Number(date.slice(8))} 日`;
  const weekday = new Intl.DateTimeFormat('zh-CN', { weekday: 'long', timeZone: 'UTC' }).format(new Date(`${date}T12:00:00Z`));
  return { label, secondary: `${date.slice(5).replace('-', ' / ')} · ${weekday}` };
}

export type DateRange = { from: string; to: string };
export function offsetDay(day: string, offset: number): string {
  const date = new Date(`${day}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + offset);
  return date.toISOString().slice(0, 10);
}
export function rangeDays({ from, to }: DateRange): number {
  return Math.max(0, Math.round((Date.parse(`${to}T12:00:00Z`) - Date.parse(`${from}T12:00:00Z`)) / 86_400_000) + 1);
}
export function monthRange(month: string, today = hongKongToday()): DateRange {
  const end = offsetDay(`${shiftMonth(month, 1)}-01`, -1);
  return { from: `${month}-01`, to: month === today.slice(0, 7) ? today : end };
}
export function reportPeriodPresets(today = hongKongToday()): { id: string; label: string; range: DateRange }[] {
  const currentMonth = today.slice(0, 7);
  const months = [0, 1, 2, 3].map((offset) => {
    const month = shiftMonth(currentMonth, -offset);
    const label = offset === 0 ? '本月' : offset === 1 ? '上月'
      : `${month.slice(0, 4) === today.slice(0, 4) ? '' : `${month.slice(0, 4)}年`}${Number(month.slice(5))}月`;
    return { id: month, label, range: monthRange(month, today) };
  });
  return [...months,
    { id: 'last-30-days', label: '近 30 天', range: { from: offsetDay(today, -29), to: today } },
    { id: 'this-year', label: '今年', range: { from: `${today.slice(0, 4)}-01-01`, to: today } },
  ];
}
export function previousRange(range: DateRange): DateRange {
  const days = rangeDays(range);
  return { from: offsetDay(range.from, -days), to: offsetDay(range.from, -1) };
}
