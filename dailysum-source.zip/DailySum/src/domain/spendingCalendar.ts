import { offsetDay, rangeDays, shiftMonth } from './dates';
import type { Currency, FxRate, Transaction } from './models';
import { summarizeConverted } from './reports';

export function calendarWeeks(month: string) {
  const first = `${month}-01`;
  const last = offsetDay(`${shiftMonth(month, 1)}-01`, -1);
  const leading = (new Date(`${first}T12:00:00Z`).getUTCDay() + 6) % 7;
  const days = rangeDays({ from: first, to: last });
  return Array.from({ length: Math.ceil((leading + days) / 7) }, (_, week) =>
    Array.from({ length: 7 }, (_, weekday) => {
      const index = week * 7 + weekday - leading;
      return index >= 0 && index < days ? offsetDay(first, index) : null;
    }),
  );
}

export function spendingCalendar(month: string, transactions: Transaction[], currency: Currency, rates: FxRate[]) {
  const rows = transactions.filter((row) => !row.deletedAt && row.occurredOn.startsWith(month));
  const monthlyRates = rates.filter((rate) => rate.rateDate.startsWith(month));
  const byDate = new Map<string, Transaction[]>();
  for (const row of rows) {
    const group = byDate.get(row.occurredOn);
    if (group) group.push(row);
    else byDate.set(row.occurredOn, [row]);
  }

  const summaries = [...byDate].map(([date, records]) => ({ date, records, report: summarizeConverted(records, currency, monthlyRates) }));
  const peak = Math.max(0, ...summaries.filter(({ report }) => !report.expense.missing).map(({ report }) => report.expense.raw.toNumber()));
  const days = new Map(summaries.map((day) => {
    const { expense } = day.report;
    const heat = !expense.missing && peak > 0 ? Math.ceil(Math.sqrt(expense.raw.toNumber() / peak) * 4) : 0;
    return [day.date, { ...day, heat }];
  }));
  return {
    days,
    spendingDays: summaries.filter(({ report }) => report.expense.count > 0).length,
    expense: summarizeConverted(rows, currency, monthlyRates).expense,
    monthlyRates,
  };
}
