import { offsetDay, rangeDays, shiftMonth, type DateRange } from './dates';
import { latestRates, MoneyDecimal, roundMinor } from './fx';
import type { Currency, FxRate, Transaction } from './models';
import { summarizeConverted, type ReportTotal } from './reports';

export type HeatmapMode = 'day' | 'week' | 'cumulative';
export type HeatmapBucket = DateRange & { total: ReportTotal; heat: number };
const emptyTotal: ReportTotal = { raw: new MoneyDecimal(0), amount: 0n, count: 0, missing: 0 };

export function spendingCalendarRange(through: string): DateRange {
  return { from: `${shiftMonth(through.slice(0, 7), -11)}-01`, to: through };
}

export function calendarWeeks(range: DateRange) {
  const leading = (new Date(`${range.from}T12:00:00Z`).getUTCDay() + 6) % 7;
  const days = rangeDays(range);
  return Array.from({ length: Math.ceil((leading + days) / 7) }, (_, week) =>
    Array.from({ length: 7 }, (_, weekday) => {
      const index = week * 7 + weekday - leading;
      return index >= 0 && index < days ? offsetDay(range.from, index) : null;
    }),
  );
}

export function spendingCalendar(range: DateRange, transactions: Transaction[], currency: Currency, rates: FxRate[]) {
  const rateMap = latestRates(rates);
  const byDate = new Map<string, Transaction[]>();
  for (const row of transactions) {
    if (row.deletedAt || row.occurredOn < range.from || row.occurredOn > range.to) continue;
    const group = byDate.get(row.occurredOn);
    if (group) group.push(row);
    else byDate.set(row.occurredOn, [row]);
  }

  const days = new Map([...byDate].map(([date, records]) => [date, { records, report: summarizeConverted(records, currency, rateMap) }]));
  return { days, rateMap };
}

export function heatmapBuckets(weeks: ReturnType<typeof calendarWeeks>, days: ReturnType<typeof spendingCalendar>['days'], mode: HeatmapMode) {
  const datesByWeek = weeks.map((week) => week.filter((date) => date !== null)).filter((week) => week.length);
  const groups = mode === 'week' ? datesByWeek : datesByWeek.flat().map((date) => [date]);
  let running = emptyTotal;
  const points = groups.map((dates) => {
    let { raw, count, missing } = mode === 'cumulative' ? running : emptyTotal;
    for (const date of dates) {
      const expense = days.get(date)?.report.expense;
      if (!expense) continue;
      raw = raw.add(expense.raw);
      count += expense.count;
      missing += expense.missing;
    }
    const total = { raw, count, missing, amount: roundMinor(raw) };
    if (mode === 'cumulative') running = total;
    return { from: mode === 'cumulative' ? datesByWeek[0][0] : dates[0], to: dates.at(-1)!, total };
  });
  const amounts = points.map(({ total }) => total)
    .filter(({ count, missing }) => count && !missing).map(({ raw }) => raw.toNumber()).sort((a, b) => a - b);
  // Daily and weekly scales keep ordinary amounts visible alongside occasional large purchases.
  const peak = (mode === 'cumulative' ? amounts.at(-1) : amounts[Math.ceil((amounts.length - 1) * .9)]) ?? 0;
  return new Map<string, HeatmapBucket>(points.map((point) => {
    const ratio = !point.total.missing && peak > 0 ? Math.min(1, point.total.raw.toNumber() / peak) : 0;
    const heat = Math.ceil((mode === 'cumulative' ? ratio : Math.sqrt(ratio)) * 4);
    return [point.to, { ...point, heat }];
  }));
}
