import { offsetDay, rangeDays, shiftMonth, type DateRange } from './dates';
import { latestRates } from './fx';
import type { Currency, FxRate, Transaction } from './models';
import { summarizeConverted } from './reports';

export function spendingCalendarRange(through: string): DateRange {
  return { from: `${shiftMonth(through.slice(0, 7), -11)}-01`, to: through };
}

export function calendarWeeks(range: DateRange) {
  const leading = (new Date(`${range.from}T12:00:00Z`).getUTCDay() + 6) % 7;
  const days = rangeDays(range);
  return Array.from({ length: Math.ceil((leading + days) / 7) }, (_, week) =>
    Array.from({ length: 7 }, (_, weekday) => {
      const index = week * 7 + weekday - leading;
      return index >= 0 && index < days ? offsetDay(range.from, index) : null;
    }),
  );
}

export function spendingCalendar(range: DateRange, transactions: Transaction[], currency: Currency, rates: FxRate[]) {
  const rateMap = latestRates(rates);
  const byDate = new Map<string, Transaction[]>();
  for (const row of transactions) {
    if (row.deletedAt || row.occurredOn < range.from || row.occurredOn > range.to) continue;
    const group = byDate.get(row.occurredOn);
    if (group) group.push(row);
    else byDate.set(row.occurredOn, [row]);
  }

  const summaries = [...byDate].map(([date, records]) => ({ date, records, report: summarizeConverted(records, currency, rateMap) }));
  const expenses = summaries.map(({ report }) => report.expense)
    .filter(({ count, missing }) => count && !missing).map(({ raw }) => raw.toNumber()).sort((a, b) => a - b);
  // Cap the scale near the top so an exceptional purchase doesn't wash out a whole year of ordinary spending.
  const peak = expenses[Math.ceil((expenses.length - 1) * .9)] ?? 0;
  const days = new Map(summaries.map((day) => {
    const { expense } = day.report;
    const heat = !expense.missing && peak > 0 ? Math.ceil(Math.sqrt(Math.min(1, expense.raw.toNumber() / peak)) * 4) : 0;
    return [day.date, { ...day, heat }];
  }));
  return { days, rateMap };
}
