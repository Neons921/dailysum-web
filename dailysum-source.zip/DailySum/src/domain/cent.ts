import { Unzip, UnzipInflate } from 'fflate';
import { hongKongToday } from './dates';
import { MAX_AMOUNT_MINOR, MAX_NOTE_LENGTH, transactionSchema, type Category, type Currency, type Transaction, type TransactionType } from './models';
import { assertSafeJson, bytesToBase64, draftSignature, MAX_BACKUP_BYTES, sha256, stableId, type LedgerData, type SourceArchive } from './portable';
import { compactCategoryTarget, hasCompactCategories } from './categories';

type ObjectValue = Record<string, unknown>;
const object = (value:unknown):value is ObjectValue => !!value && typeof value==='object' && !Array.isArray(value);
export type CentPayload = { data:ObjectValue; attachments:SourceArchive['attachments']; source:string };
export type CentIssue = {id:string;reason:string};
export type CentResult = {incoming:LedgerData;base:LedgerData;issues:CentIssue[];warnings:string[];rounded:number;duplicates:number;total:number;source:string};
const MAX_EXPANDED_BYTES=28*1024*1024;
const mimeFor=(path:string)=>({png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp',gif:'image/gif',pdf:'application/pdf'}[path.split('.').at(-1)?.toLowerCase()??'']??'application/octet-stream');
export function safeAssetPath(path:string):boolean { return path.length<=500 && !path.includes('\\') && !path.startsWith('/') && !/^[a-z]:/i.test(path) && !path.split('/').some((part)=>part==='..'||part==='.'); }

/** No filesystem extraction; expanded bytes are counted while streaming, including unknown ZIP sizes. */
export function readCentZip(bytes:Uint8Array,source:string):CentPayload {
  if(bytes.byteLength>MAX_BACKUP_BYTES) throw new Error('文件超过 40 MB，请在 Cent 中分批导出');
  let expanded=0,entries=0; const files=new Map<string,Uint8Array>();
  const unzip=new Unzip((file)=>{
    if(++entries>2001 || !safeAssetPath(file.name)) throw new Error('压缩包条目过多或包含无效路径');
    if(file.name.endsWith('/')) return;
    if(files.has(file.name)) throw new Error('压缩包包含重复文件');
    if(file.name!=='backup.json' && !file.name.startsWith('assets/')) throw new Error(`Cent 压缩包包含无法保留的文件：${file.name}`);
    if((file.originalSize??0)>MAX_EXPANDED_BYTES) throw new Error('压缩包解压后超过 28 MB');
    const chunks:Uint8Array[]=[];let length=0;
    file.ondata=(error,chunk,final)=>{
      if(error) throw new Error('Cent 压缩包损坏，无法解压');
      expanded+=chunk.length;length+=chunk.length;
      if(expanded>MAX_EXPANDED_BYTES) {file.terminate();throw new Error('压缩包解压后超过 28 MB');}
      chunks.push(chunk);
      if(final) {const content=new Uint8Array(length);let offset=0;for(const part of chunks){content.set(part,offset);offset+=part.length;}files.set(file.name,content);}
    };
    file.start();
  });
  unzip.register(UnzipInflate);
  for(let offset=0;offset<bytes.length;offset+=4096)unzip.push(bytes.subarray(offset,offset+4096),offset+4096>=bytes.length);
  const backup=files.get('backup.json');if(!backup) throw new Error('未找到 Cent 的 backup.json');
  const parsed=parseJson(new TextDecoder('utf-8',{fatal:true}).decode(backup));
  return {data:parsed,source,attachments:[...files].filter(([path])=>path!=='backup.json').map(([path,content])=>({path,content:bytesToBase64(content),mime:mimeFor(path),size:content.length}))};
}
export function parseJson(text:string):ObjectValue {
  if(new TextEncoder().encode(text).length>MAX_BACKUP_BYTES) throw new Error('文件超过 40 MB');
  let parsed:unknown;try{parsed=JSON.parse(text);}catch{throw new Error('JSON 文件不完整或格式错误');}
  assertSafeJson(parsed);if(!object(parsed)) throw new Error('备份内容必须为对象');return parsed;
}
export async function readImportFile(file:File):Promise<CentPayload> {
  if(file.size>MAX_BACKUP_BYTES) throw new Error('文件超过 40 MB');
  const bytes=new Uint8Array(await file.arrayBuffer());
  return bytes[0]===0x50&&bytes[1]===0x4b ? readCentZip(bytes,file.name) : {data:parseJson(new TextDecoder('utf-8',{fatal:true}).decode(bytes)),source:file.name,attachments:[]};
}

function patchObject(target:ObjectValue,patch:ObjectValue):ObjectValue {
  const result={...target};for(const [key,value] of Object.entries(patch)) if(key!=='$$patch') result[key]=object(value)&&value.$$patch===true?patchObject(object(result[key])?result[key]:{},value):value;
  return result;
}
/** Cent chunks are an action journal, sorted by numeric chunk index, then stable timestamp. */
export function replayCent(meta:unknown,chunks:{path:string;actions:unknown}[]):ObjectValue {
  assertSafeJson(meta);const operations:unknown[]=[];
  for(const chunk of [...chunks].sort((a,b)=>Number(a.path.match(/ledger-(\d+)\.json$/)?.[1])-Number(b.path.match(/ledger-(\d+)\.json$/)?.[1]))) {
    if(!Array.isArray(chunk.actions)) throw new Error(`${chunk.path} 不是 Cent 操作列表`);
    operations.push(...chunk.actions);if(operations.length>500000) throw new Error('Cent 操作日志过大');
  }
  assertSafeJson(operations);
  const actions=operations.map((value,index)=>{
    if(!object(value)||!['update','delete','meta'].includes(String(value.type))||typeof value.timestamp!=='number'||!Number.isFinite(value.timestamp)) throw new Error('Cent 操作日志存在无法识别的记录，已停止读取');
    return {value,index};
  }).sort((a,b)=>(a.value.timestamp as number)-(b.value.timestamp as number)||a.index-b.index);
  const items=new Map<string,ObjectValue>(),deleted=new Map<string,number>();let journalMeta:ObjectValue={};
  for(const {value:action} of actions) {
    if(action.type==='meta') {if(!object(action.metaValue))throw new Error('Cent 元数据操作无效');journalMeta=action.metaValue.$$patch?patchObject(journalMeta,action.metaValue):action.metaValue;continue;}
    if(action.type==='delete') {if(typeof action.value!=='string')throw new Error('Cent 删除操作无效');deleted.set(action.value,action.timestamp as number);const old=items.get(action.value);if(old)items.set(action.value,{...old,__delete_at:action.timestamp,__update_at:action.timestamp});continue;}
    const bill=action.value;if(!object(bill)||typeof bill.id!=='string')throw new Error('Cent 更新操作无效');
    const previous=items.get(bill.id);deleted.delete(bill.id);items.set(bill.id,{...bill,__create_at:bill.__create_at??previous?.__create_at??action.timestamp,__update_at:bill.__update_at??action.timestamp});
  }
  const currentMeta=object(meta)?(meta.$$patch?patchObject(journalMeta,meta):meta):journalMeta;
  return {items:[...items.values()],meta:currentMeta,operationLog:operations,deletedIds:[...deleted].map(([id,timestamp])=>({id,timestamp}))};
}

// Category IDs and Chinese names describe the Cent interchange format; UI implementation is independent.
const groups:Record<string,{name:string;icon:string;children:Record<string,string>}>={
  food:{name:'餐饮',icon:'food',children:{breakfast:'早餐',launch:'午餐',dinner:'晚餐',snack:'零食',treat:'请客'}},
  transport:{name:'交通',icon:'transport',children:{taxi:'出租',subway:'地铁',bus:'公交',parking:'停车','gas-up':'加油',airplane:'飞机'}},
  shopping:{name:'购物',icon:'shopping',children:{household:'居家',electronics:'数码',credits:'充值','baby-mom':'母婴',accessories:'配饰',clothing:'着装',pets:'宠物',office:'办公',renovation:'装修'}},
  housing:{name:'居住',icon:'living',children:{phone:'话费',electricity:'电费',water:'水费','mgmt-fee':'物业费',rent:'房租',mortgage:'房贷',cleaning:'家政'}},
  entertainment:{name:'娱乐',icon:'fun',children:{travel:'旅行',movies:'电影',fitness:'健身',wellness:'放松',drinks:'酒吧',shows:'演出'}},
  medical:{name:'医疗',icon:'health',children:{clinic:'医院',pharmacy:'药品',supplements:'保健'}},
  education:{name:'教育',icon:'other',children:{tuition:'学费',books:'书籍',courses:'培训'}},
  relationship:{name:'人情',icon:'gift',children:{family:'长辈',gifts:'礼物',loan:'借出',hongbao:'红包'}},
  'other-expenses':{name:'其他支出',icon:'other',children:{'fees-charges':'罚款',charity:'慈善','balance-account':'平账'}},
  wage:{name:'工资',icon:'work',children:{'part-time':'兼职'}},
  'relationship-income':{name:'人情收入',icon:'gift',children:{lean:'借入','gifts-income':'礼物','hongbao-income':'红包'}},
  'other-income':{name:'其他收入',icon:'other',children:{refund:'退款',drawback:'退税','balance-account-income':'平账'}},
};
const builtins=new Map<string,{name:string;parent?:string;icon:string}>();
for(const [id,group] of Object.entries(groups)){builtins.set(id,{name:group.name,icon:group.icon});for(const [key,name] of Object.entries(group.children))builtins.set(key,{name,parent:id,icon:group.icon});}

export async function convertCent(payload:CentPayload,current:LedgerData,fallbackBase:Currency='CNY'):Promise<CentResult> {
  const {data,attachments,source}=payload;assertSafeJson(data);
  if(!Array.isArray(data.items)||!object(data.meta))throw new Error('未识别为 Cent 备份，需要包含 items 和 meta');
  if(data.items.length>200000)throw new Error('Cent 账单超过 20 万笔，请分批导入');
  const archiveId=`cent-${await sha256({data,attachments})}`;
  const archive:SourceArchive={id:archiveId,format:'cent',source,importedAt:new Date().toISOString(),data,attachments};
  const issues:CentIssue[]=[],warnings:string[]=[];let rounded=0,duplicates=0;
  const meta=data.meta,baseCurrency=typeof meta.baseCurrency==='string'?meta.baseCurrency.toUpperCase():fallbackBase;
  if(!meta.baseCurrency)warnings.push(`备份没有账本基础币种；未标记外币的账目按 ${fallbackBase} 读取。`);
  const custom=new Map<string,ObjectValue>();
  const compact=hasCompactCategories(current.categories);
  if(Array.isArray(meta.categories)) for(const category of meta.categories)if(object(category)&&typeof category.id==='string')custom.set(category.id,category);
  const categories=new Map<string,Category>();
  async function categoryFor(sourceId:string,type:TransactionType,ancestors:string[]=[]):Promise<Category> {
    if(ancestors.includes(sourceId)||ancestors.length>8)throw new Error('分类存在循环或过深的层级');
    const key=`${type}:${sourceId}`;const cached=categories.get(key);if(cached)return cached;
    const customValue=custom.get(sourceId),known=builtins.get(sourceId);
    const rawName=typeof customValue?.customName==='string'?customValue.customName:customValue?.customName===true||!known?customValue?.name:known.name;
    const ownName=typeof rawName==='string'&&rawName.trim()?rawName.trim():known?.name??sourceId;
    const parentSource=typeof customValue?.parent==='string'?customValue.parent:known?.parent;
    const parent=parentSource?await categoryFor(parentSource,type,[...ancestors,sourceId]):undefined;
    const stable=await stableId(`cent:category:${key}`),knownOrder=[...builtins.keys()].indexOf(sourceId);
    const category:Category={id:`cent-${stable}`,name:parent?`${parent.name} / ${ownName}`:ownName,type,
      icon:known?.icon??parent?.icon??'other',color:'gray',sortOrder:knownOrder>=0?100+knownOrder:1000+parseInt(stable.slice(0,6),16),parentId:parent?.id,sourceCategoryId:sourceId};
    const savedMerge=current.categories.find((row)=>row.id===category.id)?.mergedIntoId;
    if(savedMerge)category.mergedIntoId=savedMerge;
    else if(compact)category.mergedIntoId=parent?.mergedIntoId??compactCategoryTarget(category,[...current.categories,...categories.values(),category]);
    if(category.name.length>200)throw new Error('分类名称超过 200 字');categories.set(key,category);return category;
  }
  const existing=new Map(current.transactions.map((row)=>[row.id,row]));
  const baseRows=new Map(current.transactions.map((row)=>[row.id,row]));const transactions:Transaction[]=[];const seen=new Set<string>();
  for(let index=0;index<data.items.length;index++) {
    const bill=data.items[index];const sourceId=object(bill)&&typeof bill.id==='string'?bill.id:`第 ${index+1} 条`;
    try {
      if(!object(bill)||typeof bill.id!=='string'||!bill.id||bill.id.length>200)throw new Error('缺少有效账单 ID');
      if(seen.has(bill.id))throw new Error('存在重复 ID，请先在 Cent 重新导出');seen.add(bill.id);
      if(bill.type!=='expense'&&bill.type!=='income')throw new Error('未知的收支类型');
      if(typeof bill.categoryId!=='string'||!bill.categoryId)throw new Error('缺少分类');
      const foreign=object(bill.currency)?bill.currency:null;
      const unit=String(foreign?.target??baseCurrency).toUpperCase();
      if(unit!=='HKD'&&unit!=='CNY')throw new Error(`暂不支持 ${unit} 原币，保留原记录供后续处理`);
      const amount=foreign?foreign.amount:bill.amount;
      if(typeof amount!=='number'||!Number.isSafeInteger(amount)||amount<=0)throw new Error('原金额不是正数安全整数（Cent 万分之一单位）');
      const minor=Number((BigInt(amount)+50n)/100n);
      if(minor<=0||minor>MAX_AMOUNT_MINOR)throw new Error('金额舍入后为零或超过单笔上限');
      if(typeof bill.time!=='number'||!Number.isFinite(bill.time))throw new Error('缺少有效日期时间');
      const day=hongKongToday(new Date(bill.time));
      const note=bill.comment??'';if(typeof note!=='string'||note.length>MAX_NOTE_LENGTH)throw new Error(`备注超过 ${MAX_NOTE_LENGTH} 字或格式无效`);
      const category=await categoryFor(bill.categoryId,bill.type);
      const id=await stableId(`cent:bill:${bill.id}`),old=existing.get(id),fingerprint=await sha256(bill);
      if(old?.origin?.fingerprint===fingerprint) {transactions.push(old);duplicates++;continue;}
      const timestamp=(value:unknown,fallback:number)=>new Date(typeof value==='number'&&Number.isFinite(value)?value:fallback).toISOString();
      const draft={type:bill.type,amountMinor:minor,currency:unit,categoryId:category.id,note,occurredOn:day,
        id,createdAt:timestamp(bill.__create_at,bill.time),updatedAt:timestamp(bill.__update_at,bill.time),deletedAt:bill.__delete_at!==undefined&&bill.__delete_at!==null?timestamp(bill.__delete_at,bill.time):null,schemaVersion:1};
      const checked=transactionSchema.parse(draft);
      const origin={format:'cent' as const,sourceId:bill.id,archiveId,fingerprint,importedDraft:draftSignature(checked),amount10000:String(amount),currency:unit,originalTime:bill.time};
      transactions.push({...checked,origin});
      if(amount%100!==0)rounded++;
      if(old?.origin) {
        try {baseRows.set(id,{...old,...JSON.parse(old.origin.importedDraft),origin:old.origin});}
        catch{throw new Error('本地 Cent 来源基线损坏，无法比较修改');}
      }
    } catch(cause) {issues.push({id:sourceId,reason:cause instanceof Error?cause.message:'无法解析记录'});}
  }
  // Compacted Cent journals can retain a delete without the original update.
  // Apply it only to a known Cent-origin row, with the same conflict comparison as edits.
  if(Array.isArray(data.deletedIds))for(const deletion of data.deletedIds) {
    if(!object(deletion)||typeof deletion.id!=='string'||typeof deletion.timestamp!=='number'||!Number.isFinite(deletion.timestamp)||seen.has(deletion.id))continue;
    const old=existing.get(await stableId(`cent:bill:${deletion.id}`));if(!old?.origin)continue;
    try {
      baseRows.set(old.id,{...old,...JSON.parse(old.origin.importedDraft),origin:old.origin});
      transactions.push(old.deletedAt?old:{...old,deletedAt:new Date(deletion.timestamp).toISOString(),updatedAt:new Date(deletion.timestamp).toISOString()});
      seen.add(deletion.id);
    }catch{issues.push({id:deletion.id,reason:'无法处理来源删除记录，原始日志已归档'});}
  }
  if(rounded)warnings.push(`${rounded} 笔金额超过两位小数，将四舍五入；Cent 原始万分位金额完整归档。`);
  if(data.items.some((row)=>object(row)&&object(row.currency)))warnings.push('外币账单保留原币金额，汇总按 DailySum 的每日汇率重新折算；Cent 原折算金额保存在来源归档。');
  if((Array.isArray(meta.budgets)&&meta.budgets.length)||(Array.isArray(meta.customFilters)&&meta.customFilters.length))warnings.push('Cent 预算和自定义过滤器保存在来源归档，本项目暂不应用这些设置。');
  const withArchive=current.archives.some((row)=>row.id===archiveId)?current.archives:[...current.archives,archive];
  return {base:{...current,transactions:[...baseRows.values()]},incoming:{...current,transactions,categories:[...categories.values()],archives:withArchive},issues,warnings,rounded,duplicates,total:data.items.length,source};
}
