import { DEFAULT_SETTINGS, type Category, type FxRate, type Transaction } from './models';
import { latestRates, MoneyDecimal } from './fx';
import { canonical, dataSignature, draftSignature, normalizedData, same, type LedgerData } from './portable';
import { compactCategoryTarget, hasCompactCategories, normalizeCategorySettings, normalizeCategoryTransactions, resolveCategory } from './categories';

export type ConflictKind = 'transaction' | 'category' | 'category-routing' | 'filter' | 'fx';
export type DataConflict = { key: string; kind: ConflictKind; label: string; local: unknown; remote: unknown; base: unknown };
export type Choices = Record<string,'local'|'remote'>;
export type MergeResult = { data: LedgerData; conflicts: DataConflict[]; unresolved: DataConflict[] };
const sameTransaction = (a: Transaction | undefined,b: Transaction | undefined) => a && b ? draftSignature(a) === draftSignature(b) && same(a.origin,b.origin) : a === b;
const economicRate = (rate?: FxRate) => rate ? { rate: new MoneyDecimal(rate.rate).toString(), sourceDate: rate.sourceDate } : undefined;
type CategoryRoute = { id: string; name: string; destinationId?: string; destinationName?: string };
const categoryMap = (categories: Category[]) => new Map(categories.map((category) => [category.id, category]));

function reconcileCategoryRoutes(categories: Category[], local: Map<string, Category>, remote: Map<string, Category>, choices: Choices, conflicts: DataConflict[]): Category[] {
  const merged = categoryMap(categories);
  const affected = new Set<string>();
  for (const category of categories) {
    try { resolveCategory(category.id, merged); }
    catch { affected.add(category.id); }
  }
  if (!affected.size) return categories;

  // Include every downstream link so either device's routing remains intact within this group.
  for (const id of affected) {
    for (const source of [merged, local, remote]) {
      const destination = source.get(id)?.mergedIntoId;
      if (destination) affected.add(destination);
    }
  }
  const differingIds = [...affected].sort().filter((id) => local.get(id)?.mergedIntoId !== remote.get(id)?.mergedIntoId);
  const describe = (source: Map<string, Category>): CategoryRoute[] => differingIds.flatMap((id) => {
    const category = source.get(id);
    return category ? [{ id, name: category.name, destinationId: category.mergedIntoId, destinationName: source.get(category.mergedIntoId ?? '')?.name }] : [];
  });
  const key = 'category-routing';
  conflicts.push({ key, kind: 'category-routing', label: '分类转移去向', local: describe(local), remote: describe(remote), base: undefined });
  const selected = choices[key] === 'remote' ? remote : local;
  return categories.map((category) => affected.has(category.id) && selected.has(category.id)
    ? { ...category, mergedIntoId: selected.get(category.id)?.mergedIntoId }
    : category);
}

function undoAutomaticRoutes(rows: Transaction[], originals: Map<string, Transaction>, categories: Map<string, Category>): Transaction[] {
  return rows.map((row) => {
    const original = originals.get(row.id);
    if (!original || !row.categoryHistory?.length || !categories.get(original.categoryId)?.mergedIntoId) return row;
    const route = resolveCategory(original.categoryId, categories);
    if (route.category.id !== row.categoryId || !route.history.every((id) => row.categoryHistory?.includes(id))) return row;
    const history = row.categoryHistory.filter((id) => !route.history.includes(id) || original.categoryHistory?.includes(id));
    return { ...row, categoryId: original.categoryId, categoryHistory: history.length ? history : undefined };
  });
}

export function toSyncData(data: LedgerData): LedgerData {
  return normalizedData({ ...data, settings:{...DEFAULT_SETTINGS,reportCurrency:data.settings.reportCurrency}, filterPreferences:{...data.filterPreferences,activeId:null} });
}
export const syncSignature = (data: LedgerData) => dataSignature(toSyncData(data));

/** Three-way merge uses content relative to a baseline, never device clocks to choose money. */
export function mergeLedger(base: LedgerData | null, local: LedgerData, remote: LedgerData, choices: Choices = {}): MergeResult {
  const conflicts: DataConflict[] = [];
  function records<T extends {id:string}>(kind: 'transaction' | 'category' | 'filter', before: T[], left: T[], right: T[], deletedByAbsence = false): T[] {
    const b = new Map(before.map((row)=>[row.id,row])), l = new Map(left.map((row)=>[row.id,row])), r = new Map(right.map((row)=>[row.id,row]));
    const result: T[] = [];
    const equals = (a: T | undefined,c: T | undefined) => kind === 'transaction' ? sameTransaction(a as Transaction | undefined,c as Transaction | undefined) : same(a,c);
    for (const id of [...new Set([...b.keys(),...l.keys(),...r.keys()])].sort()) {
      const old=b.get(id), a=l.get(id), c=r.get(id);
      let value: T | undefined;
      if (equals(a,c)) value = c ?? a;
      else if(kind==='category'&&!old&&a&&c&&same({...a,mergedIntoId:undefined},{...c,mergedIntoId:undefined})&&(!(a as unknown as {mergedIntoId?:string}).mergedIntoId||!(c as unknown as {mergedIntoId?:string}).mergedIntoId)) {
        // A declared category merge can be applied to an old backup without a conflict per row.
        value=(a as unknown as {mergedIntoId?:string}).mergedIntoId?a:c;
      }
      else if (!a && !old || !a && !deletedByAbsence) value=c;
      else if (!c && !old || !c && !deletedByAbsence) value=a;
      else if (old && equals(a,old)) value=c;
      else if (old && equals(c,old)) value=a;
      else {
        const source=(a ?? c) as T & {note?:string;name?:string};
        const conflict: DataConflict={key:`${kind}:${id}`,kind,label:source?.note || source?.name || id,local:a,remote:c,base:old};
        conflicts.push(conflict); value=choices[conflict.key] === 'remote' ? c : a;
      }
      if (value) result.push(value);
    }
    return result;
  }
  let categories=records('category',base?.categories ?? [],local.categories,remote.categories);
  const baseAliases=base?.categories.filter((category)=>category.mergedIntoId)??[];
  const explicitlyRestored=new Set(baseAliases.filter((old)=>[local,remote].some((data)=>data.categories.some((category)=>category.id===old.id&&!category.mergedIntoId))).map((category)=>category.id));
  if(!explicitlyRestored.size&&(hasCompactCategories(local.categories)||hasCompactCategories(remote.categories))) {
    // A child created offline or imported on another device must follow the same compact taxonomy.
    categories=categories.map((category)=>category.sourceCategoryId&&!category.mergedIntoId?{...category,mergedIntoId:compactCategoryTarget(category,categories)}:category);
  }
  const localCategories = categoryMap(local.categories), remoteCategories = categoryMap(remote.categories);
  categories = reconcileCategoryRoutes(categories, localCategories, remoteCategories, choices, conflicts);
  const originals = new Map(base?.transactions.map((row) => [row.id, row]));
  // Reapply automatic moves against the chosen destination while keeping independent edits to each record.
  const transactions = records('transaction',
    normalizeCategoryTransactions(base?.transactions ?? [], categories),
    normalizeCategoryTransactions(undoAutomaticRoutes(local.transactions, originals, localCategories), categories),
    normalizeCategoryTransactions(undoAutomaticRoutes(remote.transactions, originals, remoteCategories), categories),
  );
  const views=records('filter',base?.filterPreferences.views ?? [],local.filterPreferences.views,remote.filterPreferences.views,true);
  const rateById=new Map<string,FxRate>();
  for (const rate of [...local.fxRates,...remote.fxRates]) {
    const old=rateById.get(rate.id); if (old && !same(old,rate)) throw new Error('汇率历史记录内容不一致，请检查备份来源');
    rateById.set(rate.id,rate);
  }
  const l=latestRates(local.fxRates), r=latestRates(remote.fxRates), b=latestRates(base?.fxRates ?? []);
  for (const date of [...new Set([...l.keys(),...r.keys()])]) {
    const a=l.get(date), c=r.get(date), old=b.get(date);
    if (!a || !c || same(economicRate(a),economicRate(c))) continue;
    let winner: FxRate | undefined;
    if (old && same(economicRate(a),economicRate(old))) winner=c;
    else if (old && same(economicRate(c),economicRate(old))) winner=a;
    else if (!a.isManual&&!c.isManual&&a.revision===1&&c.revision===1&&a.sourceRates&&c.sourceRates&&a.source===c.source&&a.sourceDate!==c.sourceDate) {
      // A device can cache the previous publication before the day's official quote is available.
      winner=a.sourceDate>c.sourceDate?a:c;
    }
    else {
      const conflict: DataConflict={key:`fx:${date}`,kind:'fx',label:date,local:a,remote:c,base:old}; conflicts.push(conflict);
      if (choices[conflict.key]) winner=choices[conflict.key]==='local'?a:c;
    }
    if (winner) {
      const max=Math.max(...[...rateById.values()].filter((rate)=>rate.rateDate===date).map((rate)=>rate.revision));
      // Preserve both histories and promote the chosen economic quote.
      if (winner.revision < max || a.revision === c.revision) rateById.set(`promotion:${date}`,{...winner,id:crypto.randomUUID(),revision:max+1});
    }
  }
  const archives=new Map(local.archives.map((archive)=>[archive.id,archive]));
  for (const archive of remote.archives) {
    const old=archives.get(archive.id);
    if (old && (!same(old.data,archive.data) || !same(old.attachments,archive.attachments))) throw new Error('原始数据归档存在同名分歧，已停止合并');
    if (!old) archives.set(archive.id,archive);
  }
  const reportCurrency=base && local.settings.reportCurrency===base.settings.reportCurrency ? remote.settings.reportCurrency : local.transactions.length===0 && !base ? remote.settings.reportCurrency : local.settings.reportCurrency;
  const data=normalizedData({transactions,categories,fxRates:[...rateById.values()],archives:[...archives.values()],settings:normalizeCategorySettings({...local.settings,reportCurrency},categories),
    filterPreferences:{...local.filterPreferences,views,activeId:views.some((view)=>view.id===local.filterPreferences.activeId)?local.filterPreferences.activeId:null},
  });
  return {data,conflicts,unresolved:conflicts.filter((conflict)=>!choices[conflict.key])};
}

export function changeSummary(before: LedgerData, after: LedgerData): {added:number;updated:number;deleted:number;categories:number;filters:number} {
  const previous=new Map(before.transactions.map((row)=>[row.id,row])); let added=0,updated=0,deleted=0;
  for (const row of after.transactions) {
    const old=previous.get(row.id);
    if (!old && !row.deletedAt) added++;
    else if (old && !sameTransaction(old,row)) { if (!old.deletedAt && row.deletedAt) deleted++; else updated++; }
  }
  return {added,updated,deleted,categories:after.categories.filter((row)=>!before.categories.some((old)=>old.id===row.id)).length,
    filters:after.filterPreferences.views.filter((row)=>!before.filterPreferences.views.some((old)=>old.id===row.id)).length};
}
export function conflictDescription(value: unknown, kind: ConflictKind): string {
  if (value === undefined) return '已删除';
  if (kind === 'category-routing') {
    return (value as CategoryRoute[]).map((route) => route.destinationName
      ? `${route.name} → ${route.destinationName}`
      : `保留「${route.name}」`).join('\n') || '保留现有分类';
  }
  if (kind === 'transaction') {
    const row=value as Transaction;
    return row.deletedAt ? `已删除 · ${row.occurredOn}` : `${row.currency} ${(BigInt(row.amountMinor)/100n).toString()}.${String(row.amountMinor%100).padStart(2,'0')} · ${row.type==='expense'?'支出':'收入'} · ${row.occurredOn}\n${row.note}`;
  }
  if (kind === 'fx') { const rate=value as FxRate; return `1 CNY = ${rate.rate} HKD\n${rate.source} · ${rate.sourceDate}`; }
  const named=value as {name:string}; return named.name || canonical(value);
}
