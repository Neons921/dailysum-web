import { MAX_AMOUNT_LABEL, MAX_AMOUNT_MINOR, type Currency } from './models';

export const CURRENCY_META = {
  HKD: { symbol: 'HK$', name: '港币', full: '港币 HKD' },
  CNY: { symbol: '¥', name: '人民币', full: '人民币 CNY' },
} as const;

type ParsedAmount = { ok: true; minor: number } | { ok: false; error: string };

/** Exact string parsing: never multiply a floating point amount by 100. */
export function parseAmount(raw: string): ParsedAmount {
  let input = raw.trim().replaceAll('，', ',');
  if (!input) return { ok: false, error: '请输入金额，最多两位小数' };
  if (input.includes(',')) {
    if (!/^\d{1,3}(,\d{3})+(\.\d{0,2})?$/.test(input)) {
      return { ok: false, error: '千分位格式不明确，请输入如 1,234.50 的金额' };
    }
    input = input.replaceAll(',', '');
  }
  if (!/^\d+(\.\d{0,2})?$/.test(input)) {
    return { ok: false, error: '请使用正数金额，最多保留两位小数' };
  }
  const [whole, fraction = ''] = input.split('.');
  // Bound the string before BigInt parsing to avoid unbounded pasted integers.
  if (whole.length > 12) return { ok: false, error: `单笔金额最多 ${MAX_AMOUNT_LABEL}` };
  const minor = BigInt(whole) * 100n + BigInt(fraction.padEnd(2, '0'));
  if (minor <= 0n) return { ok: false, error: '金额需要大于 0' };
  if (minor > BigInt(MAX_AMOUNT_MINOR)) {
    return { ok: false, error: `单笔金额最多 ${MAX_AMOUNT_LABEL}` };
  }
  return { ok: true, minor: Number(minor) };
}

export function amountToInput(minor: number): string {
  return `${Math.floor(minor / 100)}.${String(minor % 100).padStart(2, '0')}`;
}

export function formatMoney(minor: number | bigint, currency: Currency): string {
  const value = BigInt(minor);
  const absolute = value < 0n ? -value : value;
  const whole = new Intl.NumberFormat('en-HK', { maximumFractionDigits: 0 }).format(absolute / 100n);
  return `${value < 0n ? '−' : ''}${CURRENCY_META[currency].symbol} ${whole}.${String(absolute % 100n).padStart(2, '0')}`;
}
