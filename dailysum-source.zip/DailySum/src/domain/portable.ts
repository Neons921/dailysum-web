import { z } from 'zod';
import { categorySchema, settingsSchema, transactionSchema, type LedgerSnapshot, type Transaction } from './models';
import { fxRateSchema } from './fx';
import { filterPreferencesSchema } from './reportFilters';
import { resolveCategory } from './categories';

export const MAX_BACKUP_BYTES = 40 * 1024 * 1024;
export const archiveSchema = z.object({ id: z.string().min(1), format: z.literal('cent'), source: z.string().max(500), importedAt: z.iso.datetime(),
  data: z.unknown(), attachments: z.array(z.object({ path: z.string().max(500), content: z.string(), mime: z.string().max(100), size: z.number().int().nonnegative() })).max(2000),
});
export type SourceArchive = z.infer<typeof archiveSchema>;
export const ledgerDataSchema = z.object({ transactions: z.array(transactionSchema).max(200000), categories: z.array(categorySchema).max(5000),
  settings: settingsSchema, fxRates: z.array(fxRateSchema).max(100000), filterPreferences: filterPreferencesSchema,
  archives: z.array(archiveSchema).max(100),
});
export type LedgerData = z.infer<typeof ledgerDataSchema>;
export const envelopeSchema = z.object({ format: z.literal('dailysum'), schemaVersion: z.literal(1), ledgerId: z.uuid(),
  exportedAt: z.iso.datetime(), integrity: z.string().regex(/^[a-f0-9]{64}$/), data: ledgerDataSchema,
});
export type LedgerEnvelope = z.infer<typeof envelopeSchema>;

export function assertSafeJson(value: unknown, depth = 0): void {
  if (depth > 50) throw new Error('文件结构过深，无法安全读取');
  if (typeof value === 'number' && !Number.isFinite(value)) throw new Error('文件包含无效数字');
  if (value && typeof value === 'object') for (const [key, child] of Object.entries(value)) {
    if (['__proto__', 'prototype', 'constructor'].includes(key)) throw new Error('文件包含不支持的对象字段');
    assertSafeJson(child, depth + 1);
  }
}
export function canonical(value: unknown): string {
  if (value === undefined) return 'null';
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  return `{${Object.keys(value).sort().filter((key) => (value as Record<string,unknown>)[key] !== undefined).map((key) => `${JSON.stringify(key)}:${canonical((value as Record<string,unknown>)[key])}`).join(',')}}`;
}
export const same = (left: unknown, right: unknown) => canonical(left) === canonical(right);
export async function sha256(value: unknown): Promise<string> {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(typeof value === 'string' ? value : canonical(value)));
  return [...new Uint8Array(bytes)].map((byte) => byte.toString(16).padStart(2,'0')).join('');
}
export async function stableId(key: string): Promise<string> {
  const hash = await sha256(key); const values = hash.slice(0,32).split(''); values[12] = '8'; values[16] = ((parseInt(values[16],16) & 3) | 8).toString(16);
  const id = values.join(''); return `${id.slice(0,8)}-${id.slice(8,12)}-${id.slice(12,16)}-${id.slice(16,20)}-${id.slice(20)}`;
}
export function normalizedData(data: LedgerData): LedgerData {
  // Hash order must not depend on the browser's locale or collation settings.
  const sorted = <T extends {id:string}>(items: T[]) => [...items].sort((a,b) => a.id<b.id?-1:a.id>b.id?1:0);
  return { ...data, transactions: sorted(data.transactions), categories: sorted(data.categories), fxRates: sorted(data.fxRates),
    filterPreferences: { ...data.filterPreferences, views: sorted(data.filterPreferences.views) }, archives: sorted(data.archives) };
}
export const dataSignature = (data: LedgerData): string => canonical(normalizedData(data));
export function validateData(input: unknown): LedgerData {
  assertSafeJson(input);
  const parsed = ledgerDataSchema.safeParse(input);
  if (!parsed.success) throw new Error(`账目格式校验失败：${parsed.error.issues[0].path.join('.')}，${parsed.error.issues[0].message}`);
  const data = normalizedData(parsed.data);
  for (const [label, records] of [['交易',data.transactions],['分类',data.categories],['汇率',data.fxRates],['过滤器',data.filterPreferences.views],['来源',data.archives]] as const) {
    if (new Set(records.map((row) => row.id)).size !== records.length) throw new Error(`${label}包含重复 ID`);
  }
  const categories = new Map(data.categories.map((category) => [category.id,category]));
  if(!data.categories.some((row)=>row.type==='expense')||!data.categories.some((row)=>row.type==='income'))throw new Error('备份必须保留支出和收入分类');
  for(const category of data.categories)if(category.parentId&&(category.parentId===category.id||categories.get(category.parentId)?.type!==category.type))throw new Error('分类层级缺失或收支类型不符');
  for(const category of data.categories)resolveCategory(category.id,categories);
  for (const row of data.transactions) {
    if (categories.get(row.categoryId)?.type !== row.type) throw new Error(`交易 ${row.id} 的分类缺失或收支类型不符`);
    if(row.categoryHistory?.some((id)=>categories.get(id)?.type!==row.type))throw new Error('原始分类记录缺失或收支类型不符');
    if (row.origin && !data.archives.some((archive) => archive.id === row.origin!.archiveId)) throw new Error('Cent 原始归档缺失，无法保证完整恢复');
  }
  if (data.filterPreferences.activeId && !data.filterPreferences.views.some((view) => view.id === data.filterPreferences.activeId)) throw new Error('选中的过滤器不存在');
  return data;
}
export async function createEnvelope(data: LedgerData, ledgerId: string): Promise<LedgerEnvelope> {
  const checked = validateData(data);
  return envelopeSchema.parse({ format:'dailysum',schemaVersion:1,ledgerId,exportedAt:new Date().toISOString(),data:checked,integrity:await sha256({ledgerId,data:checked}) });
}
export async function parseEnvelope(input: unknown): Promise<LedgerEnvelope> {
  assertSafeJson(input);
  const parsed = envelopeSchema.safeParse(input);
  if (!parsed.success) throw new Error('无法识别的 DailySum 备份版本或无效字段');
  const data = validateData(parsed.data.data);
  if (await sha256({ ledgerId:parsed.data.ledgerId,data }) !== parsed.data.integrity) throw new Error('备份校验值不匹配，文件可能不完整或被修改');
  return { ...parsed.data,data };
}
export function fromSnapshot(snapshot: LedgerSnapshot, archives: SourceArchive[]): LedgerData { return { ...snapshot,archives }; }
export function draftSignature(row: Transaction): string {
  return canonical({type:row.type,amountMinor:row.amountMinor,currency:row.currency,categoryId:row.categoryId,note:row.note,occurredOn:row.occurredOn,deletedAt:row.deletedAt,categoryHistory:row.categoryHistory?.length?row.categoryHistory:undefined});
}
export function utf8ToBase64(text: string): string { return bytesToBase64(new TextEncoder().encode(text)); }
export function bytesToBase64(bytes: Uint8Array): string {
  let binary = ''; for (let offset=0;offset<bytes.length;offset+=8192) binary += String.fromCharCode(...bytes.subarray(offset,offset+8192));
  return btoa(binary);
}
export function base64ToBytes(content: string): Uint8Array {
  const binary = atob(content.replace(/\s/g,'')); return Uint8Array.from(binary,(char) => char.charCodeAt(0));
}
export function base64ToUtf8(content: string): string { return new TextDecoder('utf-8',{fatal:true}).decode(base64ToBytes(content)); }
