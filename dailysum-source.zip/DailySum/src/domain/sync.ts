import { z } from 'zod';
import { envelopeSchema } from './portable';

export const CENT_SOURCE_REPOSITORY = '';
export const DEFAULT_SYNC_REPOSITORY = '';
export const syncProfileSchema = z.object({ id:z.literal('github-sync'),repository:z.string(),branch:z.string(),path:z.literal('dailysum/ledger.v1.json'),auto:z.boolean(),
  baseline:envelopeSchema.nullable(),lastRemoteSha:z.string().nullable(),lastSyncAt:z.string().nullable(),
});
export type SyncProfile = z.infer<typeof syncProfileSchema>;
export const emptySyncProfile = (): SyncProfile => ({id:'github-sync',repository:DEFAULT_SYNC_REPOSITORY,branch:'',path:'dailysum/ledger.v1.json',auto:false,baseline:null,lastRemoteSha:null,lastSyncAt:null});
export function repositoryName(input: string): string {
  let name=input.trim();
  if (/^https?:/i.test(name)) {
    let url:URL; try { url=new URL(name); } catch { throw new Error('请输入有效的 GitHub 仓库地址'); }
    if (url.protocol!=='https:' || url.hostname!=='github.com' || url.username || url.password) throw new Error('仅支持 https://github.com 下的仓库');
    name=url.pathname.replace(/^\/|\/$/g,'');
  }
  name=name.replace(/\.git$/,'');
  if (!/^[A-Za-z0-9][A-Za-z0-9-]{0,38}\/[A-Za-z0-9_.-]{1,100}$/.test(name) || name.split('/')[1]==='.' || name.split('/')[1]==='..') throw new Error('仓库应为 用户名/仓库名');
  return name;
}
export function profileKey(profile: Pick<SyncProfile,'repository'|'branch'|'path'>): string { return `${profile.repository.toLowerCase()}@${profile.branch}:${profile.path}`; }
