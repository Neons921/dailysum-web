import { z } from 'zod';
import { currencySchema, transactionTypeSchema, type Category, type Currency, type FxRate, type Transaction } from './models';
import { convertedMinor } from './fx';
import { formatMoney, parseAmount } from './money';

export const reportRulesSchema = z.object({
  type: transactionTypeSchema.or(z.literal('')).default(''),
  includeCategoryIds: z.array(z.string().min(1)).max(100).default([]),
  excludeCategoryIds: z.array(z.string().min(1)).max(100).default([]),
  minAmountMinor: z.number().int().min(0).max(9_999_999_999).nullable().default(null),
  maxAmountMinor: z.number().int().min(0).max(9_999_999_999).nullable().default(null),
  amountCurrency: currencySchema.default('HKD'),
  includeKeywords: z.array(z.string().trim().min(1).max(60)).max(30).default([]),
  excludeKeywords: z.array(z.string().trim().min(1).max(60)).max(30).default([]),
  excludedTransactionIds: z.array(z.string().min(1)).max(10000).default([]),
}).refine((rules) => rules.minAmountMinor === null || rules.maxAmountMinor === null || rules.minAmountMinor <= rules.maxAmountMinor,
  { message: '最低金额不能高于最高金额', path: ['maxAmountMinor'] });
export type ReportRules = z.infer<typeof reportRulesSchema>;
export const emptyReportRules = (currency: Currency = 'HKD'): ReportRules => reportRulesSchema.parse({ amountCurrency: currency });
export const savedReportFilterSchema = z.object({ id: z.uuid(), name: z.string().trim().min(1, '请输入过滤器名称').max(32),
  rules: reportRulesSchema, createdAt: z.iso.datetime(), updatedAt: z.iso.datetime() });
export type SavedReportFilter = z.infer<typeof savedReportFilterSchema>;
export const filterPreferencesSchema = z.object({ id: z.literal('report-views'), version: z.literal(1),
  views: z.array(savedReportFilterSchema).max(100), activeId: z.uuid().nullable() });
export type FilterPreferences = z.infer<typeof filterPreferencesSchema>;
export const EMPTY_FILTER_PREFERENCES: FilterPreferences = { id: 'report-views', version: 1, views: [], activeId: null };

export function hasAmountRules(rules?: ReportRules): boolean { return Boolean(rules && (rules.minAmountMinor !== null || rules.maxAmountMinor !== null)); }
export function hasReportRules(rules?: ReportRules): boolean {
  return Boolean(rules && (rules.type || rules.includeCategoryIds.length || rules.excludeCategoryIds.length || hasAmountRules(rules)
    || rules.includeKeywords.length || rules.excludeKeywords.length || rules.excludedTransactionIds.length));
}
const normalize = (value: string) => value.normalize('NFKC').toLocaleLowerCase();
export function evaluateReportRule(row: Transaction, rules: ReportRules, rates: Map<string, FxRate>, skipAmount = false): { state: 'match' | 'excluded' | 'pending'; reason: string } {
  if (rules.excludedTransactionIds.includes(row.id)) return { state: 'excluded', reason: '手动排除此笔' };
  if (rules.type && rules.type !== row.type) return { state: 'excluded', reason: rules.type === 'expense' ? '仅统计支出' : '仅统计收入' };
  const categoryIds=[row.categoryId,...(row.categoryHistory??[])];
  if (rules.excludeCategoryIds.some((id)=>categoryIds.includes(id))) return { state: 'excluded', reason: '已排除此分类' };
  if (rules.includeCategoryIds.length && !rules.includeCategoryIds.some((id)=>categoryIds.includes(id))) return { state: 'excluded', reason: '不在所选分类中' };
  const note = normalize(row.note);
  const excluded = rules.excludeKeywords.find((word) => note.includes(normalize(word)));
  if (excluded) return { state: 'excluded', reason: `备注包含“${excluded}”` };
  if (rules.includeKeywords.length && !rules.includeKeywords.some((word) => note.includes(normalize(word)))) return { state: 'excluded', reason: '备注不含指定关键词' };
  if (!skipAmount && hasAmountRules(rules)) {
    const amount = convertedMinor(row, rules.amountCurrency, rates);
    if (amount === null) return { state: 'pending', reason: '金额条件待汇率校验' };
    if (rules.minAmountMinor !== null && amount.lt(rules.minAmountMinor)) return { state: 'excluded', reason: `低于 ${formatMoney(rules.minAmountMinor, rules.amountCurrency)}` };
    if (rules.maxAmountMinor !== null && amount.gt(rules.maxAmountMinor)) return { state: 'excluded', reason: `高于 ${formatMoney(rules.maxAmountMinor, rules.amountCurrency)}` };
  }
  return { state: 'match', reason: '' };
}
export function ruleDescriptions(rules: ReportRules | undefined, categories: Category[]): string[] {
  if (!rules) return [];
  const names = (ids: string[]) => ids.map((id) => categories.find((category) => category.id === id)?.name ?? id).join('、');
  return [rules.type && (rules.type === 'expense' ? '仅支出' : '仅收入'), rules.includeCategoryIds.length && `包含 ${names(rules.includeCategoryIds)}`,
    rules.excludeCategoryIds.length && `排除 ${names(rules.excludeCategoryIds)}`,
    rules.minAmountMinor !== null && `≥ ${formatMoney(rules.minAmountMinor, rules.amountCurrency)}`,
    rules.maxAmountMinor !== null && `≤ ${formatMoney(rules.maxAmountMinor, rules.amountCurrency)}`,
    rules.includeKeywords.length && `备注含 ${rules.includeKeywords.join('、')}`, rules.excludeKeywords.length && `备注排除 ${rules.excludeKeywords.join('、')}`,
    rules.excludedTransactionIds.length && `排除 ${rules.excludedTransactionIds.length} 笔记录`].filter(Boolean) as string[];
}
export function parseRuleAmount(value: string): number | null {
  const input = value.trim();
  if (!input) return null;
  if (/^0+(\.0{0,2})?$/.test(input)) return 0;
  const parsed = parseAmount(input);
  if (!parsed.ok) throw new Error(parsed.error);
  return parsed.minor;
}
export function splitKeywords(input: string): string[] {
  return [...new Set(input.split(/[,，;；\n]+/).map((word) => word.trim()).filter(Boolean))];
}
