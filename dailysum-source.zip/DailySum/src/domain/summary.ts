import type { Currency, Transaction } from './models';

export type CurrencyTotal = { expense: bigint; income: bigint; count: number };
export type OriginalTotals = Record<Currency, CurrencyTotal>;

/** Original-currency aggregation only. Cross-currency conversion belongs to M2. */
export function summarizeOriginal(transactions: Transaction[]): OriginalTotals {
  const totals: OriginalTotals = {
    HKD: { expense: 0n, income: 0n, count: 0 },
    CNY: { expense: 0n, income: 0n, count: 0 },
  };
  for (const transaction of transactions) {
    if (transaction.deletedAt) continue;
    totals[transaction.currency][transaction.type] += BigInt(transaction.amountMinor);
    totals[transaction.currency].count += 1;
  }
  return totals;
}
