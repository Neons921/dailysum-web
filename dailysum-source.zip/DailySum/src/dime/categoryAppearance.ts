/** GPL-3.0. Palette ported from Rafael Soh's Dime Utilities/Color.swift. */
import type { CSSProperties } from 'react';
import { DEFAULT_CATEGORIES, type Category } from '../domain/models';

const categories: Record<string, { emoji: string; color: string }> = {
  food: { emoji: '🍔', color: '#477F96' },
  transport: { emoji: '🚇', color: '#AE8957' },
  shopping: { emoji: '🛍️', color: '#9273B9' },
  living: { emoji: '🛒', color: '#6D9784' },
  fun: { emoji: '🎬', color: '#647DAC' },
  health: { emoji: '💊', color: '#B67983' },
  'other-expense': { emoji: '📦', color: '#7A8594' },
  salary: { emoji: '💼', color: '#39866F' },
  bonus: { emoji: '🎉', color: '#A88238' },
  parttime: { emoji: '💻', color: '#647DAC' },
  gift: { emoji: '🧧', color: '#E34D63' },
  refund: { emoji: '↩️', color: '#A0ACF9' },
  'other-income': { emoji: '🪙', color: '#88997A' },
};

const iconColors = new Map([
  ['drink', '#5E8998'],
  ['bubble-tea', '#A47762'],
  ['coffee', '#91745F'],
  ['bus', '#6B8996'],
  ['bike', '#658B78'],
  ['plane', '#6A83A4'],
  ['house', '#8B8961'],
  ['clothes', '#AA7488'],
  ['badminton', '#4F8A80'],
  ['mahjong', '#7A8E61'],
  ['fitness', '#72829F'],
  ['games', '#8274A3'],
  ['music', '#A77491'],
  ['ticket', '#A18352'],
  ['books', '#697C9E'],
  ['pet', '#9B826A'],
  ['phone', '#617E89'],
  ['briefcase', '#548A77'],
  ['laptop', '#657DA0'],
  ['work', '#548A77'],
]);
const neutral = { emoji: '📦', color: '#7A8594' };

export function categoryAppearance(category?: Category) {
  const original = category && DEFAULT_CATEGORIES.find((preset) => preset.id === category.id && preset.icon === category.icon);
  const icon = category?.icon ?? '';
  const fallback = Object.hasOwn(categories, icon) ? categories[icon] : neutral;
  const color = original ? categories[original.id].color : iconColors.get(icon) ?? fallback.color;
  const appearance = { emoji: original ? categories[original.id].emoji : fallback.emoji, color };
  return { ...appearance, style: { '--category-color': appearance.color } as CSSProperties };
}

