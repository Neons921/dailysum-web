/** GPL-3.0. Palette ported from Rafael Soh's Dime Utilities/Color.swift. */
import type { CSSProperties } from 'react';
import type { Category } from '../domain/models';

const categories: Record<string, { emoji: string; color: string }> = {
  food: { emoji: '🍔', color: '#477F96' },
  transport: { emoji: '🚇', color: '#AE8957' },
  shopping: { emoji: '🛍️', color: '#9273B9' },
  living: { emoji: '🛒', color: '#6D9784' },
  fun: { emoji: '🎬', color: '#647DAC' },
  health: { emoji: '💊', color: '#B67983' },
  'other-expense': { emoji: '📦', color: '#7A8594' },
  salary: { emoji: '💼', color: '#39866F' },
  bonus: { emoji: '🎉', color: '#A88238' },
  parttime: { emoji: '💻', color: '#647DAC' },
  gift: { emoji: '🧧', color: '#E34D63' },
  refund: { emoji: '↩️', color: '#A0ACF9' },
  'other-income': { emoji: '🪙', color: '#88997A' },
};

export function categoryAppearance(category?: Category) {
  const appearance = categories[category?.id ?? ''] ?? categories[category?.icon ?? ''] ?? { emoji: '📦', color: '#7A8594' };
  return { ...appearance, style: { '--category-color': appearance.color } as CSSProperties };
}

