/**
 * GPL-3.0. Web port of NewCategoryPickerView by Rafael Soh (20 Nov 2023).
 * Upstream: app/dime/Components/Transactions/TransactionCategoryPicker.swift.
 * Adaptation: immediate selection, all categories visible for desktop keyboard use.
 */
import { Check } from 'lucide-react';
import type { Category } from '../domain/models';
import { categoryAppearance } from './categoryAppearance';
import { CategoryIcon } from '../components/CategoryIcon';

export function DimeCategoryPicker({ categories, value, onChange }: {
  categories: Category[];
  value: string;
  onChange: (id: string) => void;
}) {
  return <div className="dime-category-picker" role="group" aria-label="交易分类">
    {categories.map((category) => {
      const appearance = categoryAppearance(category);
      const selected = value === category.id;
      return <button type="button" key={category.id} style={appearance.style}
        aria-pressed={selected} className={`dime-category-pill ${selected ? 'selected' : ''}`}
        onClick={() => onChange(category.id)}>
        <CategoryIcon category={category} size={17} />
        <span>{category.name}</span>
        {selected && <Check size={13} aria-hidden="true" />}
      </button>;
    })}
  </div>;
}

