/** GPL-3.0. Port of Dime SettingsRowView's colored glyph + title/detail HStack. */
import type { CSSProperties, ReactNode } from 'react';

export function DimeSettingsLabel({ icon, color, title, detail }: {
  icon: ReactNode;
  color: string;
  title: string;
  detail?: string;
}) {
  return <div className="dime-setting-label">
    <span className="dime-setting-icon" style={{ '--settings-color': color } as CSSProperties} aria-hidden="true">{icon}</span>
    <div><h3>{title}</h3>{detail && <p>{detail}</p>}</div>
  </div>;
}
