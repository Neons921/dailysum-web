/** GPL-3.0. Port of Rafael Soh's SingleTransactionView / EmojiLogView in LogView.swift. */
import { Pencil, Trash2 } from 'lucide-react';
import type { Category, Currency, Transaction } from '../domain/models';
import { Money } from '../components/Money';
import { CategoryIcon } from '../components/CategoryIcon';

export function DimeTransactionRow({ transaction, category, readOnly, onEdit, onDelete, converted, reportCurrency }: {
  transaction: Transaction;
  category?: Category;
  readOnly: boolean;
  onEdit: (transaction: Transaction) => void;
  onDelete: (transaction: Transaction) => void;
  converted?: bigint | null;
  reportCurrency?: Currency;
}) {
  const contents = <><CategoryIcon category={category} />
    <div className="dime-row-description">
      <span className="dime-row-title">{transaction.note || category?.name || '其他'}</span>
      <span className="dime-row-subtitle">{category?.name ?? '其他'}<span>·</span>{transaction.currency}</span>
    </div>
    <span className="dime-row-money"><strong className={`dime-row-amount money ${transaction.type}`}>
      <Money minor={transaction.amountMinor} currency={transaction.currency} sign={transaction.type === 'income' ? '+' : '−'} />
    </strong>{reportCurrency && reportCurrency !== transaction.currency && <small className="money">{converted == null ? '待补汇率' : <>≈ <Money minor={converted} currency={reportCurrency} sign={transaction.type === 'income' ? '+' : '−'} /></>}</small>}</span></>;
  return <article className="dime-transaction-row" data-testid="transaction-row">
    {readOnly ? <div className="dime-row-main">{contents}</div>
      : <button type="button" className="dime-row-main" aria-label={`编辑${category?.name ?? '其他'}记录`} onClick={() => onEdit(transaction)}>{contents}</button>}
    {!readOnly && <div className="row-actions">
      <button type="button" className="icon-button" aria-label={`修改${category?.name ?? ''}记录`} onClick={() => onEdit(transaction)}><Pencil size={15} /></button>
      <button type="button" className="icon-button delete-action" aria-label={`删除${category?.name ?? ''}记录`} onClick={() => onDelete(transaction)}><Trash2 size={15} /></button>
    </div>}
  </article>;
}
