/** GPL-3.0. Port of InsightsSummaryBlockView by Rafael Soh (19 Nov 2023). */
import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import type { Currency } from '../domain/models';
import { Money } from '../components/Money';

export function DimeSummaryBlock({ income, amount, currency, onClick }: {
  income: boolean;
  amount: bigint | null;
  currency: Currency;
  onClick?: () => void;
}) {
  const Icon = income ? ArrowUpRight : ArrowDownRight;
  const contents = <><span className="dime-summary-icon"><Icon size={18} /></span>
    <span><span className="dime-summary-label">{income ? '收入' : '支出'}</span><strong className="money summary-amount">{amount === null ? '待折算' : <Money minor={amount} currency={currency} />}</strong></span></>;
  const className = `dime-summary-block ${income ? 'income' : 'expense'}`;
  return onClick
    ? <button className={className} type="button" onClick={onClick} aria-label={`筛选${currency}${income ? '收入' : '支出'}`}>{contents}</button>
    : <div className={className}>{contents}</div>;
}
