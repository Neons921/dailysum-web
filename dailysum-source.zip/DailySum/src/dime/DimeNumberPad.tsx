/**
 * GPL-3.0. Port of Dime NumberPad.swift, by Yumi (29 Oct 2023).
 * Retains the 1-9 / decimal / zero / submit arrangement and two-decimal limit.
 * Uses strings and the existing exact parser instead of the upstream Double model.
 */
import { Check } from 'lucide-react';
import { parseAmount } from '../domain/money';

export function DimeNumberPad({ value, onChange, onSubmit, disabled, canSubmit, onKeyAccepted }: {
  value: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  disabled: boolean;
  canSubmit: boolean;
  onKeyAccepted?: () => void;
}) {
  const enter = (next: string) => {
    onChange(next);
    onKeyAccepted?.();
  };
  const press = (key: string) => {
    if (disabled) return;
    let current = value.trim().replaceAll(',', '').replaceAll('，', '');
    if (current && !/^\d*(\.\d{0,2})?$/.test(current)) return;
    if (key === '.') {
      if (!current.includes('.')) enter(current ? `${current}.` : '0.');
      return;
    }
    if (current.includes('.') && current.split('.')[1].length >= 2) return;
    if (current === '0') current = '';
    const next = `${current}${key}`;
    const parsed = parseAmount(next);
    if (next === '0' || parsed.ok || /^0\.0{0,2}$/.test(next)) enter(next);
  };
  return <div className="dime-number-pad" role="group" aria-label="数字键盘">
    {['1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '0'].map((key) => <button
      key={key} type="button" disabled={disabled} aria-label={key === '.' ? '小数点' : `数字 ${key}`}
      onClick={() => press(key)}>{key}</button>)}
    <button className="dime-key-submit" type="button" aria-label="键盘保存" disabled={disabled || !canSubmit} onClick={onSubmit}><Check size={23} /></button>
  </div>;
}
