/**
 * GPL-3.0. Web port of Dime InsightsView's normalized rounded bars, category
 * selection, and LineGraph / AnimatedGraphPath's points + selection indicator.
 * SVG adapts the native GeometryReader coordinates; the donut is a desktop
 * extension of HorizontalPieChartView's proportional category segments.
 */
import { useEffect, useId, useLayoutEffect, useRef, useState, type KeyboardEvent } from 'react';
import type { Currency, TransactionType } from '../domain/models';
import type { CategoryTotal, TrendPoint } from '../domain/reports';
import { formatMoney } from '../domain/money';
import { Money } from '../components/Money';
import { categoryAppearance } from './categoryAppearance';
import { CategoryIcon } from '../components/CategoryIcon';
import { monotoneLinePath, ringSegmentPath, roundedColumnPath } from './chartGeometry';

const COLORS = { expense: 'var(--chart-expense)', income: 'var(--chart-income)' };
function shortAxis(minor: number) {
  const value = minor / 100;
  if (value >= 100000000) return `${+(value / 100000000).toFixed(1)}亿`;
  if (value >= 10000) return `${+(value / 10000).toFixed(1)}万`;
  if (value >= 1000) return `${+(value / 1000).toFixed(1)}k`;
  return value < 10 ? String(+value.toFixed(2)) : value < 100 ? String(+value.toFixed(1)) : String(Math.round(value));
}
function axisMaximum(maximum: number) {
  if (!maximum) return 300;
  const rawStep = maximum * 1.05 / 3;
  const scale = 10 ** Math.floor(Math.log10(rawStep));
  const normalized = rawStep / scale;
  const step = [1, 2, 2.5, 5, 10].find((value) => value >= normalized) ?? 10;
  return Math.max(1, step * scale) * 3;
}
export function TrendChart({ points, currency, mode, type, onSelect }: {
  points: TrendPoint[]; currency: Currency; mode: 'bar' | 'line'; type: TransactionType | '';
  onSelect: (point: TrendPoint) => void;
}) {
  const [selected, setSelected] = useState<number | null>(null);
  const container = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(900);
  useEffect(() => {
    const observer = new ResizeObserver(([entry]) => setContainerWidth(Math.max(1, entry.contentRect.width)));
    if (container.current) observer.observe(container.current);
    return () => observer.disconnect();
  }, []);
  useEffect(() => setSelected(null), [points, mode, type]);
  const gradient = useId().replaceAll(':', '');
  const width = containerWidth, height = width < 500 ? 240 : 280, left = width < 500 ? 40 : 48, right = 20, top = 18, bottom = 34;
  const chartWidth = width - left - right, chartHeight = height - top - bottom;
  const types: TransactionType[] = type ? [type] : ['expense', 'income'];
  const maximum = Math.max(0, ...points.flatMap((point) => types.map((unit) => point.report[unit].raw.toNumber())));
  const max = axisMaximum(maximum);
  const step = chartWidth / Math.max(1, points.length);
  const x = (index: number) => left + step * (index + .5);
  const y = (value: number) => top + chartHeight * (1 - value / max);
  const active = selected === null ? null : points[selected];
  const tooltipWidth = Math.min(238, width);
  const tooltipLeft = selected === null ? 0 : Math.max(0, Math.min(width - tooltipWidth,
    x(selected) + (x(selected) > width / 2 ? -tooltipWidth - 18 : 18)));
  const labelCount = Math.max(2, Math.floor(chartWidth / 75));
  const labelStep = Math.max(1, Math.ceil((points.length - 1) / (labelCount - 1)));
  const pointAt = (element: SVGSVGElement, clientX: number) => {
    const bounds = element.getBoundingClientRect();
    const position = (clientX - bounds.left) / bounds.width * width;
    return Math.min(points.length - 1, Math.max(0, Math.floor((position - left) / step)));
  };
  const onKey = (event: KeyboardEvent<SVGSVGElement>) => {
    if (!points.length) return;
    if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
      event.preventDefault();
      setSelected((old) => Math.max(0, Math.min(points.length - 1, (old ?? -1) + (event.key === 'ArrowRight' ? 1 : -1))));
    } else if ((event.key === 'Enter' || event.key === ' ') && active) { event.preventDefault(); onSelect(active); }
    else if (event.key === 'Escape') setSelected(null);
  };
  return <div className={`trend-chart trend-chart-${mode}`} data-testid="trend-chart" ref={container}>
    <svg viewBox={`0 0 ${width} ${height}`} role="application" aria-label="收支趋势图，左右方向键查看，回车查看该期明细" tabIndex={0} onKeyDown={onKey}
      aria-describedby={active ? `${gradient}-tooltip` : undefined}
      onBlur={() => setSelected(null)} onPointerLeave={() => setSelected(null)}
      onPointerMove={(event) => setSelected(pointAt(event.currentTarget, event.clientX))}
      onClick={(event) => { const point = points[pointAt(event.currentTarget, event.clientX)]; if (point) onSelect(point); }}>
      <title>每日汇率折算后的收支趋势（{currency}）</title>
      <defs>{types.map((unit) => <g key={unit}>
        <linearGradient id={`${gradient}-area-${unit}`} x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor={COLORS[unit]} stopOpacity=".2" /><stop offset="100%" stopColor={COLORS[unit]} stopOpacity=".015" /></linearGradient>
        <linearGradient id={`${gradient}-bar-${unit}`} x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor={`var(--chart-${unit}-top)`} /><stop offset="100%" stopColor={COLORS[unit]} /></linearGradient>
      </g>)}</defs>
      <rect x={left} y={top} width={chartWidth} height={chartHeight} rx="8" className="chart-plot-surface" />
      {[0, 1, 2, 3].map((tick) => {
        const amount = max * tick / 3, lineY = y(amount);
        return <g key={tick}><line x1={left} x2={width - right} y1={lineY} y2={lineY} className={`chart-grid-line ${tick ? '' : 'chart-baseline'}`} /><text x={left - 10} y={lineY + 4} textAnchor="end" className="chart-axis">{shortAxis(amount)}</text></g>;
      })}
      {selected !== null && active && <g className="chart-selection" aria-hidden="true">
        <rect x={left + selected * step} y={top} width={step} height={chartHeight} rx="5" className="chart-selection-band" />
        <line x1={x(selected)} x2={x(selected)} y1={top} y2={y(0)} className="chart-selection-line" />
      </g>}
      {types.map((unit, series) => {
        const coords: [number, number][] = points.map((point, index) => [x(index), y(point.report[unit].raw.toNumber())]);
        if (mode === 'line') {
          const path = monotoneLinePath(coords);
          return <g key={unit} data-series={unit}>
            <path className="chart-area" d={`${path} L ${x(points.length - 1)},${y(0)} L ${x(0)},${y(0)} Z`} fill={`url(#${gradient}-area-${unit})`} />
            <path className="chart-series-line" d={path} fill="none" stroke={COLORS[unit]} strokeWidth="3" strokeDasharray={unit === 'income' && !type ? '7 5' : undefined} strokeLinejoin="round" strokeLinecap="round" />
            {coords.map(([px, py], index) => (points.length <= 12 && points[index].report[unit].raw.gt(0) || points.length === 1)
              ? <circle key={index} cx={px} cy={py} r="3" fill="white" stroke={COLORS[unit]} strokeWidth="2" /> : null)}
            {active && <g aria-hidden="true"><circle cx={x(selected!)} cy={y(active.report[unit].raw.toNumber())} r="12" fill={COLORS[unit]} opacity=".13" />
              <circle cx={x(selected!)} cy={y(active.report[unit].raw.toNumber())} r="5" fill="white" stroke={COLORS[unit]} strokeWidth="3" /></g>}
          </g>;
        }
        const gap = Math.min(5, step * .09), barWidth = Math.min(32, (step * .7 - gap * (types.length - 1)) / types.length);
        return <g key={unit} data-series={unit}>{points.map((point, index) => {
          const amount = point.report[unit].raw.toNumber(), barHeight = chartHeight * amount / max;
          const barX = x(index) + (series - (types.length - 1) / 2) * (barWidth + gap) - barWidth / 2;
          return amount > 0 ? <path key={point.from} className={`chart-column ${selected === index ? 'is-selected' : ''}`} d={roundedColumnPath(barX, y(amount), barWidth, barHeight)}
            fill={`url(#${gradient}-bar-${unit})`} /> : null;
        })}</g>;
      })}
      {points.map((point, index) => index === 0 || index === points.length - 1 || index % labelStep === 0 && points.length - 1 - index >= labelStep * .65
        ? <text key={point.from} x={x(index)} y={height - 6} textAnchor={index === 0 ? 'start' : index === points.length - 1 ? 'end' : 'middle'} className="chart-axis chart-date-label">{point.label}</text> : null)}
    </svg>
    {active && <div id={`${gradient}-tooltip`} className="chart-tooltip" role="tooltip" style={{ left: tooltipLeft, width: tooltipWidth }}>
      <strong>{active.from === active.to ? active.from : `${active.from} — ${active.to}`}</strong>
      {types.map((unit) => <div key={unit}><span><i style={{ background: COLORS[unit] }} />{unit === 'expense' ? '支出' : '收入'}</span><b className="money"><Money minor={active.report[unit].amount} currency={currency} /></b></div>)}
      <small>{active.report.count} 笔 · 点击查看明细</small>
    </div>}
    <div className="chart-legend">{types.map((unit) => <span key={unit}><i className={`legend-${mode} ${unit === 'income' && !type ? 'legend-income' : ''}`} style={{ color: COLORS[unit], background: mode === 'bar' ? COLORS[unit] : undefined }} />{unit === 'expense' ? '支出' : '收入'}</span>)}<span className="chart-unit">{currency}</span></div>
  </div>;
}

function RingAmount({ amount, currency }: { amount: bigint; currency: Currency }) {
  const element = useRef<HTMLElement>(null);
  useLayoutEffect(() => {
    const label = element.current!;
    const fit = () => {
      label.style.removeProperty('font-size');
      const content = label.querySelector('.money-value')!;
      // Measure the rendered font; currency units have an independent minimum size.
      for (let pass = 0; pass < 4; pass++) {
        const needed = content.getBoundingClientRect().width, available = label.clientWidth;
        if (!available || needed <= available) break;
        label.style.fontSize = `${parseFloat(getComputedStyle(label).fontSize) * available / needed}px`;
      }
    };
    fit();
    const observer = new ResizeObserver(fit);
    observer.observe(label.parentElement!);
    return () => observer.disconnect();
  }, [amount, currency]);
  return <strong className="money ring-label-amount" ref={element}><Money minor={amount} currency={currency} /></strong>;
}

export function CategoryChart({ rows, currency, total, onSelect }: {
  rows: CategoryTotal[]; currency: Currency; total: bigint; onSelect: (id: string) => void;
}) {
  const [hovered, setHovered] = useState<string | null>(null);
  const [focused, setFocused] = useState<string | null>(null);
  const activeId = hovered ?? focused;
  const active = rows.find((row) => row.category.id === activeId);
  const gradient = useId().replaceAll(':', '');
  let offset = 0;
  return <div className="category-chart-layout">
    <div className="category-ring">
      <svg viewBox="0 0 252 252" aria-label="分类占比环图" role="group">
        <defs>{rows.map((row, index) => <linearGradient key={row.category.id} id={`${gradient}-category-${index}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={categoryAppearance(row.category).color} stopOpacity=".82" />
          <stop offset="100%" stopColor={categoryAppearance(row.category).color} />
        </linearGradient>)}</defs>
        <circle cx="126" cy="126" r="100.5" fill="none" stroke="var(--surface)" strokeWidth="19" />
        {rows.map((row, index) => {
          const start = offset; offset += row.share;
          return <g key={row.category.id}>
            {activeId === row.category.id && <path d={ringSegmentPath(start, row.share, 117, 115)} fill={categoryAppearance(row.category).color} className="category-arc-halo" aria-hidden="true" />}
            <path d={ringSegmentPath(start, row.share)} fill={`url(#${gradient}-category-${index})`}
              className="category-arc" opacity={!active || activeId === row.category.id ? 1 : .68}
              role="button" tabIndex={0} aria-label={`${row.category.name} ${formatMoney(row.total.amount, currency)}，${(row.share * 100).toFixed(1)}%，筛选该分类`}
              onPointerEnter={() => setHovered(row.category.id)} onPointerLeave={() => setHovered(null)} onFocus={() => setFocused(row.category.id)} onBlur={() => setFocused(null)}
              onClick={() => onSelect(row.category.id)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onSelect(row.category.id); } }} />
          </g>;
        })}
      </svg>
      <div className="ring-label"><span title={active?.category.name}>{active ? active.category.name : '合计'}</span><RingAmount amount={active?.total.amount ?? total} currency={currency} /><small>{active ? `${(active.share * 100).toFixed(1)}%` : `${rows.length} 个分类`}</small></div>
    </div>
    <div className="category-ranks">{rows.map((row) => <button key={row.category.id} className={`category-rank ${activeId === row.category.id ? 'highlighted' : ''}`} onClick={() => onSelect(row.category.id)}
      onPointerEnter={() => setHovered(row.category.id)} onPointerLeave={() => setHovered(null)} onFocus={() => setFocused(row.category.id)} onBlur={() => setFocused(null)} aria-label={`筛选${row.category.name}分类`}>
      <CategoryIcon category={row.category} size={17} />
      <span className="category-rank-name">{row.category.name}<small>{row.total.count} 笔</small></span>
      <span className="category-rank-money"><strong className="money"><Money minor={row.total.amount} currency={currency} /></strong><small>{(row.share * 100).toFixed(1)}%</small></span>
      <span className="category-rank-track"><span style={{ width: `${row.share * 100}%`, background: `linear-gradient(90deg, color-mix(in srgb, ${categoryAppearance(row.category).color} 72%, white), ${categoryAppearance(row.category).color})` }} /></span>
    </button>)}</div>
  </div>;
}

