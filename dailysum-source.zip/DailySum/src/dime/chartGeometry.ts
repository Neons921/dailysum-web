type Point = readonly [number, number];

/** Monotone cubic interpolation keeps every segment within its measured endpoints. */
export function monotoneLinePath(points: readonly Point[]): string {
  if (!points.length) return '';
  const start = `M ${points[0][0]},${points[0][1]}`;
  if (points.length === 1) return start;
  const slopes = points.slice(1).map(([x, y], i) => (y - points[i][1]) / (x - points[i][0]));
  const tangents = points.map((_, i) => i === 0 ? slopes[0] : i === points.length - 1 ? slopes[i - 1]
    : slopes[i - 1] * slopes[i] <= 0 ? 0 : (slopes[i - 1] + slopes[i]) / 2);
  slopes.forEach((slope, i) => {
    if (slope === 0) { tangents[i] = 0; tangents[i + 1] = 0; return; }
    const length = Math.hypot(tangents[i] / slope, tangents[i + 1] / slope);
    if (length > 3) {
      tangents[i] = 3 * tangents[i] / length;
      tangents[i + 1] = 3 * tangents[i + 1] / length;
    }
  });
  return start + points.slice(1).map(([x, y], i) => {
    const [previousX, previousY] = points[i], third = (x - previousX) / 3;
    return ` C ${previousX + third},${previousY + third * tangents[i]} ${x - third},${y - third * tangents[i + 1]} ${x},${y}`;
  }).join('');
}

/** Square baseline, rounded top; short bars keep their true height. */
export function roundedColumnPath(x: number, y: number, width: number, height: number): string {
  const radius = Math.min(5, width / 2, height / 2), end = x + width, bottom = y + height;
  return `M ${x},${bottom} L ${x},${y + radius} Q ${x},${y} ${x + radius},${y} L ${end - radius},${y} Q ${end},${y} ${end},${y + radius} L ${end},${bottom} Z`;
}

/** Rounded annular sectors retain tiny shares without oversized circular end caps. */
export function ringSegmentPath(start: number, share: number, outer = 110, inner = 91): string {
  const center = 126, turn = Math.PI * 2;
  const point = (radius: number, angle: number) => `${center + Math.cos(angle) * radius},${center + Math.sin(angle) * radius}`;
  if (share <= 0) return '';
  if (share >= 1 - 1e-10) return `M ${center},${center - outer} A ${outer},${outer} 0 1 1 ${center},${center + outer} A ${outer},${outer} 0 1 1 ${center},${center - outer} L ${center},${center - inner} A ${inner},${inner} 0 1 0 ${center},${center + inner} A ${inner},${inner} 0 1 0 ${center},${center - inner} Z`;
  const span = share * turn, gap = Math.min(.014, span * .2);
  const from = start * turn - Math.PI / 2 + gap / 2, to = from + span - gap;
  const corner = Math.min(2.5, (outer - inner) / 2, (to - from) * inner / 4);
  const outerInset = corner / outer, innerInset = corner / inner;
  return `M ${point(outer, from + outerInset)} A ${outer},${outer} 0 ${to - from - 2 * outerInset > Math.PI ? 1 : 0} 1 ${point(outer, to - outerInset)}
    Q ${point(outer, to)} ${point(outer - corner, to)} L ${point(inner + corner, to)} Q ${point(inner, to)} ${point(inner, to - innerInset)}
    A ${inner},${inner} 0 ${to - from - 2 * innerInset > Math.PI ? 1 : 0} 0 ${point(inner, from + innerInset)}
    Q ${point(inner, from)} ${point(inner + corner, from)} L ${point(outer - corner, from)} Q ${point(outer, from)} ${point(outer, from + outerInset)} Z`;
}
