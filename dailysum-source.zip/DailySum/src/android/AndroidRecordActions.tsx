import { Pencil, Trash2 } from 'lucide-react';
import { Modal } from '../components/Modal';
import { CategoryIcon } from '../components/CategoryIcon';
import { Money } from '../components/Money';
import type { Category, Transaction } from '../domain/models';

export function AndroidRecordActions({ transaction, category, onClose, onEdit, onDelete }: {
  transaction: Transaction;
  category?: Category;
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  return <Modal title="账目操作" className="mobile-sheet mobile-record-actions" onClose={onClose}>
    <div className="mobile-record-preview">
      <CategoryIcon category={category} size={20} />
      <div><strong>{transaction.note || category?.name || '其他'}</strong><time dateTime={transaction.occurredOn}>{transaction.occurredOn}</time></div>
      <strong className="money"><Money minor={transaction.amountMinor} currency={transaction.currency} sign={transaction.type === 'income' ? '+' : '−'} /></strong>
    </div>
    <div className="mobile-record-buttons">
      <button type="button" onClick={onEdit}><Pencil size={19} aria-hidden="true" />修改记录</button>
      <button type="button" onClick={onDelete}><Trash2 size={19} aria-hidden="true" />删除记录</button>
    </div>
  </Modal>;
}
