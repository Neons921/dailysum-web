/** GPL-3.0. Mobile port of Dime's TransactionView.swift and NewCategoryPickerView. */
import { useRef, useState, type ComponentProps, type Dispatch, type SetStateAction } from 'react';
import { CalendarDays, ChevronRight, MessageSquare, Trash2 } from 'lucide-react';
import { MAX_NOTE_LENGTH, type Category, type Currency, type Transaction, type TransactionType } from '../domain/models';
import { CURRENCY_META } from '../domain/money';
import { hongKongToday } from '../domain/dates';
import { CategoryIcon } from '../components/CategoryIcon';
import { CentSourceDetails } from '../components/CentSourceDetails';
import { DatePicker } from '../components/DatePicker';
import { Modal } from '../components/Modal';
import { DimeNumberPad } from '../dime/DimeNumberPad';
import { categoryAppearance } from '../dime/categoryAppearance';
import { playAndroidHaptic } from '../app/android';

export type EditorFields = {
  type: TransactionType;
  amount: string;
  currency: Currency;
  categoryId: string;
  note: string;
  occurredOn: string;
};

export function AndroidTransactionEditor({ form, setForm, formEvents, categories, transaction, setType, onClose, onDelete, saving, valid, amountError, dateValid, error }: {
  form: EditorFields;
  setForm: Dispatch<SetStateAction<EditorFields>>;
  formEvents: Pick<ComponentProps<'form'>, 'onSubmit' | 'onCompositionStart' | 'onCompositionEnd' | 'onKeyDown'>;
  categories: Category[];
  transaction: Transaction | null;
  setType: (type: TransactionType) => void;
  onClose: () => void;
  onDelete?: (transaction: Transaction) => void;
  saving: boolean;
  valid: boolean;
  amountError?: string;
  dateValid: boolean;
  error: string;
}) {
  const [sheet, setSheet] = useState<'category' | 'date' | 'note' | 'source' | null>(null);
  const [backspacePressed, setBackspacePressed] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);
  const category = categories.find((item) => item.id === form.categoryId);
  const patch = (changes: Partial<EditorFields>) => setForm((current) => ({ ...current, ...changes }));
  const closeSheet = () => setSheet(null);
  const closeFooter = <footer className="modal-footer"><button className="button primary" type="button" onClick={closeSheet}>完成</button></footer>;
  return <>
    <Modal className="mobile-compose" title={transaction ? '编辑记录' : '记一笔'} onClose={sheet === 'category' ? closeSheet : onClose} busy={saving}
      headerContent={<div className="mobile-compose-type" role="group" aria-label="收支类型">
        {(['expense', 'income'] as const).map((type) => <button key={type} type="button" disabled={saving} aria-pressed={form.type === type}
          onClick={() => { if (form.type !== type) setType(type); }}>{type === 'expense' ? '支出' : '收入'}</button>)}
      </div>}>
      <form ref={formRef} {...formEvents}>
        <div className="mobile-compose-scroll">
          <fieldset disabled={saving} className="mobile-compose-fields">
            <legend className="sr-only">交易信息</legend>
            <div className="mobile-amount-entry">
              <div>
                <span aria-hidden="true">{CURRENCY_META[form.currency].symbol}</span>
                <input type="text" aria-label="金额" inputMode="none" autoComplete="off" placeholder="0.00" maxLength={32}
                  style={{ width: `${Math.max(4.3, Math.min(form.amount.length + .5, 13))}ch` }}
                  value={form.amount} aria-invalid={Boolean(form.amount && amountError)} aria-describedby={form.amount && amountError ? 'mobile-amount-error' : undefined}
                  onChange={(event) => patch({ amount: event.target.value })} />
              </div>
              <button type="button" className="icon-button mobile-backspace" aria-label="删除最后一位" disabled={!form.amount} data-pressed={backspacePressed}
                onPointerDown={(event) => { if (event.isPrimary && event.button === 0) setBackspacePressed(true); }}
                onPointerUp={() => setBackspacePressed(false)}
                onPointerCancel={() => setBackspacePressed(false)}
                onPointerLeave={() => setBackspacePressed(false)}
                onClick={() => {
                  setForm((current) => ({ ...current, amount: current.amount.slice(0, -1) }));
                  playAndroidHaptic('key');
                }}><img src="./dime/backspace.svg" alt="" width="21" height="21" /></button>
            </div>
            {form.amount && amountError && <p id="mobile-amount-error" className="error-text">{amountError}</p>}
            <div className="mobile-compose-currencies" role="group" aria-label="记账币种">
              {(['HKD', 'CNY'] as const).map((currency) => <button key={currency} type="button" aria-pressed={form.currency === currency}
                onClick={() => patch({ currency })}><strong>{currency}</strong><span>{CURRENCY_META[currency].name}</span></button>)}
            </div>
            <button className="mobile-compose-note" type="button" onClick={() => setSheet('note')} aria-label="编辑备注"><MessageSquare size={15} aria-hidden="true" /><span>{form.note || '添加备注'}</span></button>
            {!dateValid && <p className="error-text">请选择有效的交易日期</p>}
            {transaction && <div className="mobile-compose-record-actions">
              {transaction.origin && <button type="button" className="text-button" onClick={() => setSheet('source')}>Cent 原始记录</button>}
              {onDelete && <button type="button" className="text-button" onClick={() => onDelete(transaction)}><Trash2 size={15} />删除记录</button>}
            </div>}
            {error && <p className="form-error" role="alert">{error}</p>}
          </fieldset>
        </div>
        <fieldset className="mobile-compose-footer" disabled={saving} aria-label="日期、分类与数字键盘">
          <div className="mobile-compose-meta">
            <button type="button" onClick={() => setSheet('date')} aria-label={`交易日期 ${form.occurredOn}`}><CalendarDays size={17} aria-hidden="true" />{form.occurredOn === hongKongToday() ? '今天' : form.occurredOn || '日期'}</button>
            <button type="button" className="mobile-compose-category" style={categoryAppearance(category).style}
              aria-expanded={sheet === 'category'} onClick={() => setSheet(sheet === 'category' ? null : 'category')} aria-label={`选择分类，当前${category?.name ?? '未选'}`}>
              <CategoryIcon category={category} size={17} /><span>{category?.name ?? '选择分类'}</span><ChevronRight size={15} aria-hidden="true" />
            </button>
          </div>
          {sheet === 'category' ? <div className="mobile-category-grid" role="group" aria-label="交易分类">
            {categories.filter((item) => item.type === form.type).map((item) => <button key={item.id} type="button" style={categoryAppearance(item).style}
              aria-pressed={form.categoryId === item.id} onClick={() => { patch({ categoryId: item.id }); closeSheet(); }}>
              <CategoryIcon category={item} size={19} /><span>{item.name}</span>
            </button>)}
          </div> : <DimeNumberPad value={form.amount} onChange={(amount) => patch({ amount })} disabled={saving} canSubmit={valid} onKeyAccepted={() => playAndroidHaptic('key')}
            onSubmit={() => formRef.current?.requestSubmit()} />}
          <span className="sr-only" role="status">{saving ? '正在保存…' : ''}</span>
        </fieldset>
      </form>
    </Modal>
    {sheet === 'date' && <Modal title="交易日期" className="mobile-sheet" onClose={closeSheet}>
      <div className="mobile-sheet-content"><DatePicker label="交易日期" value={form.occurredOn} onChange={(occurredOn) => patch({ occurredOn })} /></div>
      {closeFooter}
    </Modal>}
    {sheet === 'note' && <Modal title="备注" className="mobile-sheet" onClose={closeSheet}>
      <div className="mobile-sheet-content"><textarea className="mobile-note" aria-label="备注" rows={3} maxLength={MAX_NOTE_LENGTH} value={form.note}
        placeholder="填写备注" onChange={(event) => patch({ note: event.target.value })} /></div>
      {closeFooter}
    </Modal>}
    {sheet === 'source' && transaction && <Modal title="原始记录" className="mobile-sheet" onClose={closeSheet}>
      <div className="mobile-sheet-content"><CentSourceDetails transaction={transaction} /></div>
      {closeFooter}
    </Modal>}
  </>;
}
