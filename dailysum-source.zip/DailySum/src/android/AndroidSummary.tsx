/** GPL-3.0. Mobile port of Dime's LogView totals and InsightsSummaryBlockView. */
import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import type { Currency, TransactionType } from '../domain/models';
import type { Report } from '../domain/reports';
import { Money } from '../components/Money';

export function AndroidSummary({ report, preferred, onFilter, comparisons, selected }: {
  report: Report;
  preferred: Currency;
  onFilter: (type: TransactionType) => void;
  comparisons?: { expense: string | null; income: string | null };
  selected?: TransactionType | '';
}) {
  return <section className={`mobile-summary${comparisons ? ' mobile-insights-summary' : ''}`} aria-label="折算汇总">
    <div className="mobile-balance" data-testid="summary-net">
      <div><span>结余</span><small>{preferred}</small></div>
      <strong className={`money${report.net === null ? ' mobile-pending-balance' : ''}`}>{report.net === null ? '待折算' : <Money minor={report.net} currency={preferred} positive />}</strong>
    </div>
    <div className="mobile-summary-sides">
      {(['income', 'expense'] as const).map((type) => {
        const income = type === 'income', Icon = income ? ArrowUpRight : ArrowDownRight;
        const label = income ? '收入' : '支出';
        return <button key={type} className={type} type="button" data-testid={`summary-${type}`} aria-label={`筛选${preferred}${label}`}
          aria-pressed={selected === type} onClick={() => onFilter(type)}>
          <span className="mobile-summary-icon"><Icon size={17} aria-hidden="true" /></span>
          <span className="mobile-summary-value"><span>{label}</span>
            <strong className="money">{report[type].missing ? '待折算' : <Money minor={report[type].amount} currency={preferred} />}</strong>
            {comparisons?.[type] && <small>较上期 {comparisons[type]}</small>}
          </span>
        </button>;
      })}
    </div>
  </section>;
}
