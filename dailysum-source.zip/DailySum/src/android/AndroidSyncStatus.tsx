import { ChevronRight, Cloud, CloudCheck, CloudOff, RefreshCw } from 'lucide-react';
import { isAndroidPreview } from '../app/previewMode';
import { syncStatusLabel, type SyncState } from '../services/syncService';

export function AndroidSyncStatus({ sync, onOpen }: { sync: SyncState; onOpen: () => void }) {
  const label = isAndroidPreview ? '预览中停用' : syncStatusLabel(sync);
  const Icon = label === '已同步' ? CloudCheck : label === '同步中…' ? RefreshCw : sync.status === 'offline' ? CloudOff : Cloud;
  return <div className="mobile-sync-row">
    <button type="button" className="mobile-sync-status" data-status={sync.status} aria-label={`GitHub 同步：${label}`} disabled={isAndroidPreview} onClick={onOpen}>
      <Icon size={16} aria-hidden="true" className={Icon === RefreshCw ? 'spin' : undefined} />
      <span>同步<span className="mobile-sync-dot" aria-hidden="true">·</span>{label}</span>
      <ChevronRight size={14} aria-hidden="true" />
    </button>
    <span className="sr-only" role="status">GitHub 同步：{label}</span>
  </div>;
}
