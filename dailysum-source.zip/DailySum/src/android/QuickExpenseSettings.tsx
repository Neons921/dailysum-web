import { useRef, useState } from 'react';
import { ChevronRight, Zap } from 'lucide-react';
import { CurrencyToggle } from '../components/CurrencyToggle';
import { Modal } from '../components/Modal';
import { Select } from '../components/Select';
import { DimeSettingsLabel } from '../dime/DimeSettingsLabel';
import { activeCategories } from '../domain/categories';
import { MAX_NOTE_LENGTH, type Category } from '../domain/models';
import { amountToInput, formatMoney, parseAmount } from '../domain/money';
import { quickExpenseCategory, type QuickExpense } from '../domain/quickExpense';
import { describeError } from '../services/errors';

export function QuickExpenseSettings({ preset, categories, onSave }: {
  preset: QuickExpense;
  categories: Category[];
  onSave: (preset: QuickExpense) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const category = quickExpenseCategory(categories, preset.categoryId);
  const summary = category ? `${category.name} · ${formatMoney(preset.amountMinor, preset.currency)}` : '请选择支出分类';
  const expenses = activeCategories(categories).filter((item) => item.type === 'expense');

  return <section className="settings-section">
    <div className="section-title"><h2>快捷操作</h2></div>
    <button className="setting-row fx-setting-button" type="button" onClick={() => setOpen(true)}>
      <DimeSettingsLabel icon={<Zap size={16} />} color="#A88238" title="快捷记账" detail={preset.enabled ? summary : '已关闭'} />
      <ChevronRight size={15} aria-hidden="true" />
    </button>
    {open && <QuickExpenseEditor preset={{ ...preset, categoryId: category?.id ?? '' }} categories={expenses}
      onSave={onSave} onClose={() => setOpen(false)} />}
  </section>;
}

function QuickExpenseEditor({ preset, categories, onSave, onClose }: {
  preset: QuickExpense;
  categories: Category[];
  onSave: (preset: QuickExpense) => Promise<void>;
  onClose: () => void;
}) {
  const [draft, setDraft] = useState(preset);
  const [amount, setAmount] = useState(amountToInput(preset.amountMinor));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const submitting = useRef(false);
  const patch = (changes: Partial<QuickExpense>) => setDraft((current) => ({ ...current, ...changes }));
  const save = async () => {
    if (submitting.current) return;
    const parsed = parseAmount(amount);
    if (!parsed.ok) { setError(parsed.error); return; }
    if (!categories.some((category) => category.id === draft.categoryId)) {
      setError('请选择支出分类');
      return;
    }
    submitting.current = true;
    setBusy(true);
    setError('');
    try {
      await onSave({ ...draft, amountMinor: parsed.minor, note: draft.note.trim() });
      onClose();
    } catch (cause) {
      setError(describeError(cause));
    } finally {
      submitting.current = false;
      setBusy(false);
    }
  };

  return <Modal title="快捷记账" subtitle="长按底栏「＋」，直接记一笔今天的支出。" className="mobile-sheet" onClose={onClose} busy={busy}>
    <form onSubmit={(event) => { event.preventDefault(); void save(); }}>
      <fieldset className="mobile-sheet-content quick-expense-fields" disabled={busy}>
        <label className="quick-expense-enabled"><input type="checkbox" checked={draft.enabled}
          onChange={(event) => patch({ enabled: event.target.checked })} />启用长按快捷记账</label>
        <div className="quick-expense-field"><span>支出分类</span>
          <Select label="支出分类" value={draft.categoryId} onChange={(categoryId) => patch({ categoryId })}
            options={[{ value: '', label: '请选择支出分类' }, ...categories.map((category) => ({ value: category.id, label: category.name }))]} />
        </div>
        <label className="quick-expense-field">金额
          <input inputMode="decimal" type="text" autoComplete="off" maxLength={32}
            value={amount} onChange={(event) => setAmount(event.target.value)} />
        </label>
        <div className="quick-expense-field"><span>记账币种</span>
          <CurrencyToggle value={draft.currency} onChange={(currency) => patch({ currency })} />
        </div>
        <label className="quick-expense-field">备注
          <input type="text" placeholder="选填" maxLength={MAX_NOTE_LENGTH} value={draft.note}
            onChange={(event) => patch({ note: event.target.value })} />
        </label>
        {error && <p className="form-error" role="alert">{error}</p>}
      </fieldset>
      <footer className="modal-footer">
        <button type="button" className="button secondary" disabled={busy} onClick={onClose}>取消</button>
        <button className="button primary" type="submit" disabled={busy}>{busy ? '保存中…' : '保存设置'}</button>
      </footer>
    </form>
  </Modal>;
}
