/** GPL-3.0. Mobile port of Dime's segmented category breakdown in InsightsView.swift. */
import type { Currency } from '../domain/models';
import type { CategoryTotal } from '../domain/reports';
import { categoryAppearance } from '../dime/categoryAppearance';
import { Money } from '../components/Money';

export function AndroidCategoryBreakdown({ rows, currency, onSelect }: {
  rows: CategoryTotal[];
  currency: Currency;
  onSelect: (id: string) => void;
}) {
  return <div className="mobile-breakdown">
    <div className="mobile-breakdown-bar" aria-hidden="true">
      {rows.map(({ category, share }) => <span key={category.id}
        style={{ flexGrow: share, backgroundColor: categoryAppearance(category).color }} />)}
    </div>
    <div className="mobile-breakdown-legend" role="group" aria-label="按分类查看统计">
      {rows.map(({ category, total, share }) => <button key={category.id} type="button" onClick={() => onSelect(category.id)}>
        <i style={{ backgroundColor: categoryAppearance(category).color }} aria-hidden="true" />
        <span>{category.name}</span>
        <strong className="money"><Money minor={total.amount} currency={currency} /></strong>
        <small>{(share * 100).toFixed(1)}%</small>
      </button>)}
    </div>
  </div>;
}
