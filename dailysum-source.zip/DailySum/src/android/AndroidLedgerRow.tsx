/** GPL-3.0. Mobile port of Rafael Soh's SingleTransactionView in LogView.swift. */
import type { Category, Currency, Transaction } from '../domain/models';
import { CategoryIcon } from '../components/CategoryIcon';
import { Money } from '../components/Money';

export function AndroidLedgerRow({ transaction, category, converted, preferred, readOnly, onActions }: {
  transaction: Transaction;
  category?: Category;
  converted: bigint | null;
  preferred: Currency;
  readOnly: boolean;
  onActions: (transaction: Transaction) => void;
}) {
  const name = category?.name ?? '其他';
  const title = transaction.note || name;
  const sign = transaction.type === 'income' ? '+' : '−';
  const contents = <>
    <CategoryIcon category={category} size={19} />
    <span className="mobile-row-title"><strong>{title}</strong>{title !== name && <small>{name}</small>}</span>
    <span className="mobile-row-amount">
      <strong className={`money ${transaction.type}`}><Money minor={transaction.amountMinor} currency={transaction.currency} sign={sign} /></strong>
      {transaction.currency !== preferred && <small className="money">{converted === null ? '待补汇率' : <>≈ <Money minor={converted} currency={preferred} sign={sign} /></>}</small>}
    </span>
  </>;
  return readOnly
    ? <div className="mobile-ledger-row" data-testid="transaction-row">{contents}</div>
    : <button type="button" className="mobile-ledger-row" data-testid="transaction-row" aria-label={`${title}记录的操作`} aria-haspopup="dialog" onClick={() => onActions(transaction)}>{contents}</button>;
}
