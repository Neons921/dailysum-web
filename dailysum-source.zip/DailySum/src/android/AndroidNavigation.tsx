/** GPL-3.0. Mobile port of Rafael Soh's CustomTabBar.swift and TabButton. */
import type { Ref } from 'react';
import { Plus } from 'lucide-react';

const tabs = [
  { id: 'transactions', label: '明细', icon: './dime/log.svg' },
  { id: 'reports', label: '统计', icon: './dime/insights.svg' },
  { id: 'analysis', label: '消费分析', icon: './dailysum-analysis.svg' },
  { id: 'settings', label: '设置', icon: './dime/settings.svg' },
] as const;

export function AndroidNavigation({ page, onNew, addRef }: {
  page: (typeof tabs)[number]['id'];
  onNew: () => void;
  addRef: Ref<HTMLButtonElement>;
}) {
  const tab = ({ id, label, icon }: (typeof tabs)[number]) =>
    <a href={`#/${id}`} aria-label={label} aria-current={page === id ? 'page' : undefined}>
      <img src={icon} alt="" width="23" height="23" /><span aria-hidden="true">{id === 'analysis' ? '分析' : label}</span>
    </a>;
  return <nav className="mobile-nav" aria-label="主导航">
    <div className="mobile-tabs">
      <div className="mobile-tab-group">{tab(tabs[0])}{tab(tabs[1])}</div>
      <button ref={addRef} className="mobile-add" type="button" aria-label="记一笔" onClick={onNew}><Plus size={23} strokeWidth={2.5} aria-hidden="true" /></button>
      <div className="mobile-tab-group">{tab(tabs[2])}{tab(tabs[3])}</div>
    </div>
  </nav>;
}
