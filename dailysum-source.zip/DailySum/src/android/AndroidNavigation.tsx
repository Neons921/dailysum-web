/** GPL-3.0. Mobile port of Rafael Soh's CustomTabBar.swift and TabButton. */
import { useEffect, useRef, type Ref } from 'react';
import { Plus } from 'lucide-react';

const tabs = [
  { id: 'transactions', label: '明细', icon: './dime/log.svg' },
  { id: 'reports', label: '统计', icon: './dime/insights.svg' },
  { id: 'analysis', label: '消费分析', icon: './dailysum-analysis.svg' },
  { id: 'settings', label: '设置', icon: './dime/settings.svg' },
] as const;

const QUICK_PRESS_MS = 500;

export function AndroidNavigation({ page, onNew, onQuickExpense, addRef }: {
  page: (typeof tabs)[number]['id'] | 'calendar';
  onNew: () => void;
  onQuickExpense?: () => void;
  addRef: Ref<HTMLButtonElement>;
}) {
  const press = useRef<{ id: number; x: number; y: number; timer: number } | null>(null);
  const suppressClick = useRef(false);
  const clearPress = () => {
    if (press.current) window.clearTimeout(press.current.timer);
    press.current = null;
  };
  useEffect(() => {
    const cancel = () => {
      if (!press.current) return;
      suppressClick.current = true;
      clearPress();
    };
    window.addEventListener('blur', cancel);
    document.addEventListener('visibilitychange', cancel);
    return () => {
      cancel();
      window.removeEventListener('blur', cancel);
      document.removeEventListener('visibilitychange', cancel);
    };
  }, []);

  const tab = ({ id, label, icon }: (typeof tabs)[number]) =>
    <a href={`#/${id}`} aria-label={label} aria-current={page === id ? 'page' : page === 'calendar' && id === 'transactions' ? 'location' : undefined}>
      <img src={icon} alt="" width="23" height="23" /><span aria-hidden="true">{id === 'analysis' ? '分析' : label}</span>
    </a>;
  return <nav className="mobile-nav" aria-label="主导航">
    <div className="mobile-tabs">
      <div className="mobile-tab-group">{tab(tabs[0])}{tab(tabs[1])}</div>
      <button ref={addRef} className="mobile-add" type="button" aria-label="记一笔"
        aria-description={onQuickExpense ? '长按快捷记账' : undefined}
        aria-keyshortcuts={onQuickExpense ? 'Shift+Enter' : undefined}
        onPointerDown={(event) => {
          if (!event.isPrimary || event.button !== 0) return;
          clearPress();
          suppressClick.current = false;
          if (!onQuickExpense) return;
          const { pointerId: id, clientX: x, clientY: y } = event;
          event.currentTarget.setPointerCapture(id);
          const timer = window.setTimeout(() => {
            press.current = null;
            suppressClick.current = true;
            onQuickExpense();
          }, QUICK_PRESS_MS);
          press.current = { id, x, y, timer };
        }}
        onPointerMove={(event) => {
          const start = press.current;
          if (start?.id !== event.pointerId || Math.hypot(event.clientX - start.x, event.clientY - start.y) < 12) return;
          suppressClick.current = true;
          clearPress();
        }}
        onPointerUp={(event) => { if (press.current?.id === event.pointerId) clearPress(); }}
        onLostPointerCapture={(event) => {
          if (press.current?.id !== event.pointerId) return;
          suppressClick.current = true;
          clearPress();
        }}
        onContextMenu={(event) => event.preventDefault()}
        onKeyDown={(event) => {
          if (!onQuickExpense || event.key !== 'Enter' || !event.shiftKey) return;
          event.preventDefault();
          if (!event.repeat) onQuickExpense();
        }}
        onClick={(event) => { if (!event.detail || !suppressClick.current) onNew(); }}>
        <Plus size={23} strokeWidth={2.5} aria-hidden="true" />
      </button>
      <div className="mobile-tab-group">{tab(tabs[2])}{tab(tabs[3])}</div>
    </div>
  </nav>;
}
