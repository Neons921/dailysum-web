import { useState } from 'react';
import './preview.css';

const widths = [320, 393, 430];

export function PreviewShell() {
  const [width, setWidth] = useState(393);

  return <main className="preview-workspace">
    <header className="preview-toolbar">
      <div>
        <h1>DailySum · Android 界面预览</h1>
        <p>独立示例账本，可试记、修改和删除。</p>
      </div>
      <div className="preview-widths" role="group" aria-label="屏幕宽度">
        {widths.map((size) => <button key={size} type="button" aria-pressed={width === size} onClick={() => setWidth(size)}>{size} px</button>)}
      </div>
    </header>
    <iframe className="preview-screen" src="./?screen=1" title="DailySum Android 应用" style={{ width }} />
  </main>;
}
