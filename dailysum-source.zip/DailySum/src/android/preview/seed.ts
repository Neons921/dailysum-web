import { demoTransactions } from '../../demo';
import { hongKongToday, shiftMonth } from '../../domain/dates';
import type { FxRate } from '../../domain/models';
import type { LedgerDatabase } from '../../storage/db';

export async function seedPreviewLedger(db: LedgerDatabase) {
  const marker = 'android-preview-v1';
  await db.transaction('rw', db.transactions, db.fxRates, db.migrations, async () => {
    if (await db.migrations.get(marker)) return;

    const today = hongKongToday();
    const currentMonth = today.slice(0, 7);
    const sample = [1, 1.3, 0.8].flatMap((factor, offset) => {
      const month = shiftMonth(currentMonth, -offset);
      return demoTransactions(month).map((row) => {
        const date = row.occurredOn > today ? today : row.occurredOn;
        return {
          ...row,
          id: crypto.randomUUID(),
          occurredOn: date,
          amountMinor: Math.round(row.amountMinor * factor),
          createdAt: `${date}T04:00:00.000Z`,
          updatedAt: `${date}T04:00:00.000Z`,
        };
      });
    });
    const fetchedAt = new Date().toISOString();
    const rates: FxRate[] = [...new Set([today, ...sample.map((row) => row.occurredOn)])].map((date) => ({
      id: crypto.randomUUID(), rateDate: date, sourceDate: date, baseCurrency: 'CNY', quoteCurrency: 'HKD',
      rate: '1.18', source: '预览示例汇率', fetchedAt, isManual: false, revision: 1,
    }));
    await db.transactions.bulkAdd(sample);
    await db.fxRates.bulkAdd(rates);
    await db.migrations.add({ id: marker, appliedAt: fetchedAt });
  });
}
