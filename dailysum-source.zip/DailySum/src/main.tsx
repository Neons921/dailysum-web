import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './app/App';
import './dime/theme.generated.css';
import './ui/foundation.css';
import './ui/controls.css';
import './ui/surfaces.css';
import './ui/data.css';

createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
