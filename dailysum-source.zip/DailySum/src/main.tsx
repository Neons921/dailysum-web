import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './app/App';
import { isAndroid } from './app/android';
import { isAndroidPreview } from './app/previewMode';
import './dime/theme.generated.css';
import './ui/foundation.css';
import './ui/controls.css';
import './ui/surfaces.css';
import './ui/data.css';
import './ui/android.css';
import './ui/analysis.css';

const root = createRoot(document.getElementById('root')!);
if (isAndroidPreview && new URLSearchParams(window.location.search).get('screen') !== '1') {
  document.title = 'DailySum · Android 界面预览';
  void import('./android/preview/PreviewShell').then(({ PreviewShell }) => {
    root.render(<StrictMode><PreviewShell /></StrictMode>);
  });
} else {
  document.documentElement.classList.toggle('android-app', isAndroid);
  if (isAndroidPreview) document.documentElement.classList.add('android-preview-screen');
  root.render(<StrictMode><App /></StrictMode>);
}
