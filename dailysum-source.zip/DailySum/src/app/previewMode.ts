export const isAndroidPreview = import.meta.env.DEV && import.meta.env.MODE === 'android-preview';
