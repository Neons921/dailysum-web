import { Fragment, useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react';
import {
  ArrowRight, Check,
  CircleHelp, Info, Plus, Undo2, X,
  ChartNoAxesCombined, ChartPie, ReceiptText, Settings2,
} from 'lucide-react';
import { isValidDate, type FxRate, type LedgerChange, type LedgerSnapshot, type Transaction, type TransactionDraft, type UserSettings, transactionToDraft } from '../domain/models';
import { hongKongToday, monthRange, previousRange, rangeDays } from '../domain/dates';
import { selectReportTransactions, type ReportFilters } from '../domain/reports';
import { hasAmountRules, type ReportRules, type SavedReportFilter } from '../domain/reportFilters';
import { formatMoney } from '../domain/money';
import { ledgerService } from '../services/ledgerService';
import { describeError as errorMessage } from '../services/errors';
import { demoTransactions } from '../demo';
import { ConfirmDialog, Modal } from '../components/Modal';
import { TransactionDialog, type EditorSession } from '../components/TransactionDialog';
import { TransactionsPage } from '../pages/TransactionsPage';
import { ReportsPage } from '../pages/ReportsPage';
import { SettingsPage } from '../pages/SettingsPage';
import { useExchangeRates } from '../services/useExchangeRates';
import { FxManager } from '../components/FxManager';
import { MonthNavigator } from '../components/DatePicker';
import { ReportFilterRepository } from '../storage/reportFilterRepository';
import { DataManager, type DataMode } from '../components/DataManager';
import { dataService } from '../services/dataService';
import { syncService } from '../services/syncService';
import { Money } from '../components/Money';
import { same } from '../domain/portable';
import { activeCategories, resolveCategory } from '../domain/categories';
import { isAndroid, listenForAndroidEvents, playAndroidHaptic } from './android';
import { isAndroidPreview } from './previewMode';
import { AndroidNavigation } from '../android/AndroidNavigation';
import { SpendingPage } from '../pages/SpendingPage';
import { spendingPeriods, spendingRows } from '../domain/spendingAnalysis';
import { saveFile } from '../services/saveFile';
const reportFilterRepository = new ReportFilterRepository(ledgerService.repository.db);

type Page = 'transactions' | 'reports' | 'analysis' | 'settings';
type Toast = { id: string; message: string; change?: LedgerChange };
const pages = [
  { id: 'transactions', label: '明细', icon: ReceiptText },
  { id: 'reports', label: '统计', icon: ChartNoAxesCombined },
  { id: 'analysis', label: '分析', icon: ChartPie },
  { id: 'settings', label: '设置', icon: Settings2 },
] as const;
const currentPage = (): Page => {
  const hash = window.location.hash.replace('#/', '');
  return pages.some((page) => page.id === hash) ? hash as Page : 'transactions';
};
export function App() {
  const sync=useSyncExternalStore(syncService.subscribe,syncService.getState);
  const [dataModal,setDataModal]=useState<DataMode|null>(null);
  const [page, setPage] = useState<Page>(currentPage);
  const [snapshot, setSnapshot] = useState<LedgerSnapshot | null>(null);
  const snapshotRef=useRef<LedgerSnapshot|null>(snapshot);
  snapshotRef.current=snapshot;
  const [loadError, setLoadError] = useState('');
  const [retry, setRetry] = useState(0);
  const [month, setMonth] = useState(hongKongToday().slice(0, 7));
  const [analysisMonth, setAnalysisMonth] = useState<string | null>(null);
  const [reportFilters, setReportFilters] = useState<ReportFilters>(() => ({ ...monthRange(hongKongToday().slice(0, 7)), type: '', currency: '', categoryId: '', query: '' }));
  const [fxModal, setFxModal] = useState<{ date?: string; demo: boolean } | null>(null);
  const [editor, setEditor] = useState<EditorSession | null>(null);
  const editorWasOpen = useRef(false);
  const [deleteTarget, setDeleteTarget] = useState<Transaction | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState('');
  const [toast, setToast] = useState<Toast | null>(null);
  const [saveAnnouncement, setSaveAnnouncement] = useState('');
  const [undoing, setUndoing] = useState(false);
  const undoBusy = useRef(false);
  const deleteBusy = useRef(false);
  const settingsBusyRef = useRef(false);
  const [settingsBusy, setSettingsBusy] = useState(false);
  const [operationError, setOperationError] = useState('');
  const [demo, setDemo] = useState(false);
  const [help, setHelp] = useState(false);
  const [filterReset, setFilterReset] = useState(0);
  const addButton = useRef<HTMLButtonElement>(null);
  const channel = useRef<BroadcastChannel | null>(null);

  const receiveSnapshot=useCallback((next:LedgerSnapshot)=>{
    const previous=snapshotRef.current;snapshotRef.current=next;setSnapshot(next);
    const oldView=previous?.filterPreferences.views.find((view)=>view.id===previous.filterPreferences.activeId);
    const nextView=next.filterPreferences.views.find((view)=>view.id===next.filterPreferences.activeId);
    setReportFilters((current)=>{
      const category=next.categories.find((item)=>item.id===current.categoryId);
      const categoryId=category?.mergedIntoId?resolveCategory(category.id,new Map(next.categories.map((item)=>[item.id,item]))).category.id:current.categoryId;
      const rules=oldView&&!same(oldView.rules,nextView?.rules)&&same(current.rules,oldView.rules)?nextView?.rules:current.rules;
      return categoryId!==current.categoryId||rules!==current.rules?{...current,categoryId,rules}:current;
    });
  },[]);

  useEffect(()=>{syncService.setPaused(Boolean((dataModal&&dataModal!=='sync')||editor||fxModal||deleteTarget));},[dataModal,editor,fxModal,deleteTarget]);
  useEffect(()=>{if(snapshot)syncService.localChanged();},[snapshot]);
  useEffect(()=>{
    const retrySync=()=>{void syncService.autoSync();};
    const offline=()=>syncService.networkLost();
    const stopAndroidEvents = listenForAndroidEvents(retrySync);
    const visible=()=>{if(document.visibilityState==='visible')retrySync();};
    const changed=()=>{void ledgerService.snapshot().then((next)=>{receiveSnapshot(next);channel.current?.postMessage('changed');}).catch((cause)=>setOperationError(errorMessage(cause)));};
    const connectionChanged=()=>channel.current?.postMessage('github-connection');
    window.addEventListener('online',retrySync);window.addEventListener('offline',offline);window.addEventListener('focus',visible);document.addEventListener('visibilitychange',visible);window.addEventListener('dailysum-data-changed',changed);window.addEventListener('dailysum-connection-changed',connectionChanged);
    const interval=window.setInterval(visible,12000);
    return()=>{stopAndroidEvents?.();window.removeEventListener('online',retrySync);window.removeEventListener('offline',offline);window.removeEventListener('focus',visible);document.removeEventListener('visibilitychange',visible);window.removeEventListener('dailysum-data-changed',changed);window.removeEventListener('dailysum-connection-changed',connectionChanged);clearInterval(interval);};
  },[receiveSnapshot]);
  const dataChanged=async(latest=false)=>{
    const next=await ledgerService.snapshot();setSnapshot(next);setDemo(false);
    const view=next.filterPreferences.views.find((value)=>value.id===next.filterPreferences.activeId);
    setReportFilters((current)=>{const category=next.categories.find((item)=>item.id===current.categoryId);return {...current,categoryId:category?.mergedIntoId?resolveCategory(category.id,new Map(next.categories.map((item)=>[item.id,item]))).category.id:current.categoryId,rules:view?.rules};});
    if(latest){const day=next.transactions.filter((row)=>!row.deletedAt).map((row)=>row.occurredOn).sort().at(-1);if(day)setMonth(day.slice(0,7));}
    channel.current?.postMessage('changed');
  };
  const openData=(mode:DataMode|'export'|'source'|'license')=>{
    const showError = (cause: unknown) => setOperationError(errorMessage(cause));
    if (mode === 'export') {
      void dataService.backup().then((content) => saveFile(content, `DailySum-${hongKongToday()}.json`)).catch(showError);
    } else if (mode === 'source' || mode === 'license') {
      const path = mode === 'source' ? './dailysum-source.zip' : './dime/LICENSE.txt';
      void fetch(path).then(async (response) => {
        if (!response.ok) throw new Error('无法读取文件，请重试。');
        await saveFile(await response.blob(), path.split('/').at(-1)!, mode === 'source' ? 'application/zip' : 'text/plain');
      }).catch(showError);
    } else {
      setDataModal(mode);
    }
  };

  useEffect(() => {
    // Passive cleanup of the closed dialog restores its old focus first.
    // Restore the main action after that cleanup, rather than racing it in rAF.
    if (editorWasOpen.current && !editor) addButton.current?.focus({ preventScroll: true });
    editorWasOpen.current = Boolean(editor);
  }, [editor]);

  useEffect(() => { setReportFilters((current) => ({ ...current, ...monthRange(month) })); }, [month]);
  const updateRates = useCallback((rates: FxRate[]) => {
    setSnapshot((current) => current && ({ ...current, fxRates: [...new Map([...current.fxRates, ...rates].map((rate) => [rate.id, rate])).values()] }));
    channel.current?.postMessage('changed');
  }, []);
  const active = snapshot?.transactions.filter((transaction) => !transaction.deletedAt) ?? [];
  const allShown = demo ? demoTransactions(month) : active;
  const shown = allShown.filter((transaction) => transaction.occurredOn.startsWith(month));
  const today = hongKongToday();
  const latestAnalysisMonth = today.slice(0, 7);
  const selectedAnalysisMonth = analysisMonth ?? latestAnalysisMonth;
  const analysisPeriods = page === 'analysis' ? spendingPeriods(selectedAnalysisMonth, today) : null;
  const currentSpending = analysisPeriods ? spendingRows(demo ? demoTransactions(analysisPeriods.current.from.slice(0, 7)) : active, analysisPeriods.current) : [];
  const previousSpending = analysisPeriods ? spendingRows(demo ? demoTransactions(analysisPeriods.previous.from.slice(0, 7)) : active, analysisPeriods.previous) : [];
  const validReportRange = isValidDate(reportFilters.from) && isValidDate(reportFilters.to) && reportFilters.from <= reportFilters.to && rangeDays(reportFilters) <= 3660;
  const fxTransactions = page === 'transactions' ? shown : page === 'analysis' ? [...currentSpending, ...previousSpending] : page === 'reports' && snapshot && validReportRange
    ? [...selectReportTransactions(allShown, reportFilters, snapshot.categories, [], true).matched, ...selectReportTransactions(allShown, { ...reportFilters, ...previousRange(reportFilters) }, snapshot.categories, [], true).matched] : [];
  const fx = useExchangeRates(fxTransactions, snapshot?.settings.reportCurrency ?? 'HKD', snapshot?.fxRates ?? [], demo, updateRates,
    page === 'reports' && hasAmountRules(reportFilters.rules) ? reportFilters.rules?.amountCurrency : undefined);
  const openRates = (date?: string) => setFxModal({ date: date ?? (page==='settings'?snapshot?.transactions??[]:fxTransactions).filter((row) => !row.deletedAt&&row.currency !== snapshot?.settings.reportCurrency).map((row) => row.occurredOn).sort().at(-1), demo: demo && page !== 'settings' });

  useEffect(() => {
    let active = true;
    setLoadError('');
    ledgerService.initialize().then((data) => {
      if (!active) return;
      setSnapshot(data);
      // Restore credentials only after the local ledger is ready; startup sync can then apply a pull.
      if (!isAndroidPreview) void syncService.initialize().catch((cause)=>setOperationError(errorMessage(cause)));
      const view = data.filterPreferences.views.find((value) => value.id === data.filterPreferences.activeId);
      setReportFilters((current) => ({ ...current, rules: view?.rules }));
    }).catch((cause) => {
      if (active) setLoadError(errorMessage(cause));
    });
    return () => { active = false; };
  }, [retry]);

  useEffect(() => {
    const change = () => setPage(currentPage());
    window.addEventListener('hashchange', change);
    if (!window.location.hash) window.history.replaceState(null, '', '#/transactions');
    return () => window.removeEventListener('hashchange', change);
  }, []);

  useEffect(() => { window.scrollTo({ top: 0, behavior: 'instant' }); }, [page]);

  useEffect(() => {
    if (!('BroadcastChannel' in window)) return;
    const updates = new BroadcastChannel('dailysum-updates');
    channel.current = updates;
    updates.onmessage = (event) => {
      if(event.data==='github-connection'){void syncService.refreshConnection();return;}
      ledgerService.snapshot().then(receiveSnapshot).catch((cause) => setOperationError(`刷新本地账本失败：${errorMessage(cause)}`));
    };
    return () => { updates.close(); channel.current = null; };
  }, [receiveSnapshot]);

  useEffect(() => {
    if (!toast || undoing) return;
    const timer = window.setTimeout(() => setToast(null), toast.change ? 8000 : 4500);
    return () => window.clearTimeout(timer);
  }, [toast, undoing]);

  const notify = (message: string, change?: LedgerChange) => setToast({ id: crypto.randomUUID(), message, change });
  const openNew = useCallback(() => {
    if (!snapshot) return;
    if (isAndroid) setSaveAnnouncement('');
    setEditor({ id: crypto.randomUUID(), transaction: null });
  }, [snapshot]);
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      const target = event.target instanceof HTMLElement ? event.target : null;
      if (event.isComposing || event.ctrlKey || event.metaKey || event.altKey || event.repeat || target?.closest('input, textarea, select, [contenteditable="true"]') || document.querySelector('dialog[open]')) return;
      if (event.key.toLowerCase() === 'n') { event.preventDefault(); openNew(); }
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [openNew]);

  const applyTransaction = (transaction: Transaction) => setSnapshot((current) => current && ({
    ...current,
    transactions: [...current.transactions.filter((value) => value.id !== transaction.id), transaction],
  }));
  const closeEditor = () => {
    setEditor(null);
  };

  const save = async (id: string, draft: TransactionDraft, previous: Transaction | null) => {
    const result = await ledgerService.save(id, draft, previous);
    applyTransaction(result.change.after);
    setSnapshot((current) => current && ({ ...current, settings: result.settings }));
    setMonth(draft.occurredOn.slice(0, 7));
    setFilterReset((value) => value + 1);
    setDemo(false);
    closeEditor();
    const category = snapshot?.categories.find((value) => value.id === draft.categoryId)?.name ?? '';
    const message = `${previous ? '已更新' : '已记录'} ${formatMoney(draft.amountMinor, draft.currency)} · ${category}`;
    if (isAndroid) playAndroidHaptic('confirm');
    if (isAndroid && !previous) {
      setToast(null);
      setSaveAnnouncement(message);
    } else {
      notify(message, result.change);
    }
    channel.current?.postMessage('changed');
  };

  const remove = async () => {
    if (!deleteTarget || deleteBusy.current) return;
    deleteBusy.current = true;
    setDeleting(true);
    setDeleteError('');
    try {
      const change = await ledgerService.remove(deleteTarget);
      applyTransaction(change.after);
      setDeleteTarget(null);
      setEditor((current) => current?.transaction?.id === deleteTarget.id ? null : current);
      notify(`已删除 ${formatMoney(deleteTarget.amountMinor, deleteTarget.currency)}`, change);
      channel.current?.postMessage('changed');
      requestAnimationFrame(() => addButton.current?.focus());
    } catch (cause) {
      setDeleteError(`删除未完成：${errorMessage(cause)}`);
    } finally {
      deleteBusy.current = false;
      setDeleting(false);
    }
  };

  const undo = async () => {
    if (!toast?.change || undoBusy.current) return;
    const change = toast.change;
    undoBusy.current = true;
    setUndoing(true);
    try {
      const restored = await ledgerService.undo(change);
      applyTransaction(restored);
      if (change.kind === 'create') {
        setEditor({ id: crypto.randomUUID(), transaction: null, restored: transactionToDraft(change.after) });
        setToast(null);
      } else notify(change.kind === 'delete' ? '已恢复这笔记录' : '已撤销本次修改');
      channel.current?.postMessage('changed');
    } catch (cause) {
      setOperationError(`撤销未完成：${errorMessage(cause)}`);
    } finally {
      undoBusy.current = false;
      setUndoing(false);
    }
  };

  const updateSettings = async (patch: Partial<UserSettings>) => {
    if (settingsBusyRef.current) return;
    settingsBusyRef.current = true;
    setSettingsBusy(true);
    try {
      const settings = await ledgerService.updateSettings(patch);
      setSnapshot((current) => current && ({ ...current, settings }));
      notify('偏好已保存到本地');
      channel.current?.postMessage('changed');
    } catch (cause) {
      setOperationError(`设置未保存：${errorMessage(cause)}`);
    } finally {
      settingsBusyRef.current = false;
      setSettingsBusy(false);
    }
  };

  const applyReportRules = async (rules: ReportRules | undefined, viewId: string | null = null) => {
    const before = reportFilters;
    const next = { ...before, type: '' as const, currency: '' as const, categoryId: '', query: '', rules };
    // The visible filter changes synchronously; persisting its selection must
    // never replace a search typed immediately after clearing the old filter.
    setReportFilters(next);
    try {
      const preferences = await reportFilterRepository.activate(viewId);
      setSnapshot((current) => current && ({ ...current, filterPreferences: preferences }));
      channel.current?.postMessage('changed');
    } catch (cause) {
      setReportFilters((current) => current === next ? before : current);
      throw cause;
    }
  };
  const saveReportRules = async (name: string, rules: ReportRules, previous?: SavedReportFilter) => {
    const preferences = await reportFilterRepository.save(name, rules, previous);
    setSnapshot((current) => current && ({ ...current, filterPreferences: preferences }));
    setReportFilters((current) => ({ ...current, type: '', currency: '', categoryId: '', query: '', rules }));
    notify('过滤器已保存'); channel.current?.postMessage('changed');
  };
  const removeReportFilter = async (record: SavedReportFilter) => {
    const preferences = await reportFilterRepository.remove(record);
    setSnapshot((current) => current && ({ ...current, filterPreferences: preferences }));
    if (snapshot?.filterPreferences.activeId === record.id) setReportFilters((current) => ({ ...current, rules: undefined }));
    notify('过滤器已删除'); channel.current?.postMessage('changed');
  };

  if (!snapshot && isAndroid) return <main className="mobile-startup" aria-busy={!loadError}>
    <div className="mobile-startup-brand"><img src="./dailysum-startup.svg" width="76" height="76" alt="" /><h1>DailySum</h1></div>
    {loadError ? <div className="mobile-startup-error" role="alert"><strong>无法打开账本</strong><p>{loadError}</p><button className="button primary" onClick={() => setRetry((value) => value + 1)}>重新连接</button></div>
      : <span className="sr-only">正在打开账本…</span>}
  </main>;
  if (!snapshot) return <main className="startup-state"><img src="./favicon.svg" width="40" height="40" alt="DailySum" /><h1>{loadError ? '无法打开账本' : '正在打开账本…'}</h1>{loadError && <><p>{loadError}</p><button className="button primary" onClick={() => setRetry((value) => value + 1)}>重新连接</button></>}</main>;

  const titles = {
    transactions: '收支明细',
    reports: '收支统计',
    analysis: '消费分析',
    settings: '偏好设置',
  };

  return <div className="app-shell">
    <a className="skip-link" href="#main-content" onClick={(event) => {
      event.preventDefault();
      document.getElementById('main-content')?.focus();
    }}>跳到主要内容</a>
    {isAndroid ? <AndroidNavigation page={page} onNew={openNew} addRef={addButton} /> : <aside className="sidebar">
      <a className="brand" href="#/transactions" aria-label="DailySum 首页"><img src="./dime/log.svg" alt="" width="28" height="28" /><span>DailySum</span></a>
      <nav aria-label="主导航">
        {pages.map(({ id, label, icon: Icon }) => <Fragment key={id}>
          {id === 'settings' && <button ref={addButton} className="button primary new-button dime-add-button" aria-keyshortcuts="N" onClick={openNew}><Plus size={21} />记一笔<kbd aria-hidden="true">N</kbd></button>}
          <a href={`#/${id}`} aria-current={page === id ? 'page' : undefined} className={`nav-link ${page === id ? 'active' : ''}`}><Icon size={20} strokeWidth={1.7} aria-hidden="true" /><span>{label}</span></a>
        </Fragment>)}
      </nav>
      <div className="sidebar-bottom">
        {(sync.connected||sync.status==='error')&&<button className="sync-status-action" onClick={()=>setDataModal('sync')}><Info size={15}/>{!sync.connected?'GitHub 需重新连接':sync.status==='review'?'同步待确认':sync.status==='offline'?'同步等待联网':sync.status==='error'?'同步需处理':sync.status==='syncing'||sync.status==='checking'?'同步中…':sync.status==='pending'?'等待同步':sync.profile?.lastSyncAt?'已同步':'尚未同步'}</button>}
        <button className="sidebar-help" onClick={() => setHelp(true)}><CircleHelp size={17} />使用帮助</button>
        <span className="app-version">v0.1.0</span>
      </div>
    </aside>}

    <main id="main-content" className="main-content" tabIndex={-1}>
      <div className="page-content" key={isAndroid ? page : undefined}>
        <header className="page-header"><h1>{isAndroid && page === 'settings' ? '设置' : titles[page]}</h1><div className="header-actions">
          {page === 'transactions' && <MonthNavigator value={month} onChange={setMonth} />}
          {page === 'analysis' && <MonthNavigator label="分析月份" value={selectedAnalysisMonth} maxMonth={latestAnalysisMonth}
            onChange={(value) => setAnalysisMonth(value === latestAnalysisMonth ? null : value)} />}
        </div></header>

        {operationError && <div className="error-banner" role="alert"><Info size={17} /><span>{operationError}</span><button className="icon-button" aria-label="关闭错误提示" onClick={() => setOperationError('')}><X size={16} /></button></div>}
        {demo && page !== 'settings' && <div className="demo-banner"><span className="demo-label">示例账本</span><p>只读，不会保存到你的账本</p><button className="text-button" onClick={() => setDemo(false)}>退出示例<ArrowRight size={14} /></button></div>}

        {page === 'transactions' && <TransactionsPage key={`${month}-${demo}-${filterReset}`} transactions={shown} categories={snapshot.categories} preferred={snapshot.settings.reportCurrency} demo={demo} rates={fx.rates} fxStatus={fx} onRates={openRates} sync={sync} onSync={() => openData('sync')}
          onNew={openNew} onEdit={(transaction) => setEditor({ id: transaction.id, transaction })} onDelete={(transaction) => { setDeleteTarget(transaction); setDeleteError(''); }} onDemo={() => setDemo(true)} />}
        {page === 'reports' && <ReportsPage transactions={allShown} categories={snapshot.categories} preferred={snapshot.settings.reportCurrency} rates={fx.rates} filters={reportFilters} onFilters={setReportFilters} fxStatus={fx} onRates={openRates}
          preferences={snapshot.filterPreferences} onApplyRules={applyReportRules} onSaveRules={saveReportRules} onRemoveFilter={removeReportFilter} />}
        {analysisPeriods && <SpendingPage periods={analysisPeriods} current={currentSpending} previous={previousSpending} categories={snapshot.categories} preferred={snapshot.settings.reportCurrency} rates={fx.rates} fxStatus={fx} onRates={openRates} />}
        {page === 'settings' && <SettingsPage settings={snapshot.settings} categories={activeCategories(snapshot.categories)} transactions={snapshot.transactions} busy={settingsBusy} rates={snapshot.fxRates} onRates={openRates} onSettingsChange={(patch) => { void updateSettings(patch); }} onData={openData} sync={sync}/>}
      </div>
    </main>

    {editor && <TransactionDialog key={editor.id} session={editor} settings={snapshot.settings} categories={activeCategories(snapshot.categories)} onSave={save} onClose={closeEditor}
      onDelete={isAndroid ? (transaction) => { setDeleteTarget(transaction); setDeleteError(''); } : undefined} />}
    {dataModal&&<DataManager mode={dataModal} onClose={()=>setDataModal(null)} onChanged={dataChanged}/>}
    {deleteTarget && <ConfirmDialog title="删除这笔记录？" confirmLabel="删除记录" onClose={() => { if (!deleting) setDeleteTarget(null); }} onConfirm={() => { void remove(); }} busy={deleting} danger error={deleteError}>
      <p><strong className="money"><Money minor={deleteTarget.amountMinor} currency={deleteTarget.currency}/></strong> · {snapshot.categories.find((category) => category.id === deleteTarget.categoryId)?.name}</p><p>删除后可撤销。</p>
    </ConfirmDialog>}
    {fxModal && <FxManager initialDate={fxModal.date} records={fxModal.demo ? fx.rates : snapshot.fxRates} transactions={fxModal.demo ? (analysisPeriods ? fxTransactions : allShown) : active} readOnly={fxModal.demo} onChange={updateRates} onClose={() => setFxModal(null)} />}
    {help && <Modal title="使用帮助" onClose={() => setHelp(false)} className="help-modal"><div className="help-content">
      <p><strong>记账</strong>输入金额后选择币种与分类。切换 HKD / CNY 不会换算输入金额。</p>
      <p><strong>快捷键</strong>N 新建，Ctrl / ⌘ + Enter 保存，Esc 关闭。保存后 8 秒内可撤销，之后仍可编辑或删除记录。</p>
      <p><strong>数据存储</strong>账目保存在此浏览器的当前网址下，清除站点数据会删除账本。</p>
      <p><strong>汇率</strong>按交易日期的 ECB 参考价折算为报表币种，统一四舍五入至两位小数。原币金额不变。非发布日采用此前最近报价；汇率可在设置中查询、补录和修订。</p>
      <p><strong>统计</strong>日期、收支、分类、原币和搜索可组合筛选。趋势图支持日、周、月；点击图表或分类可查看明细。分类和趋势各自先汇总再舍入，与逐笔显示相加偶有一分差异。</p>
      <p><strong>备份与同步</strong>在设置中导出完整 JSON 备份、导入 Cent 账目或连接 GitHub 私有仓库。可记住此浏览器的连接，下次打开自动同步；凭据不进入账目备份，可在同步设置中忘记连接。导入与拉取前保留本地恢复点，账目冲突需核对后确认。</p>
    </div><footer className="modal-footer"><button className="button primary" onClick={() => setHelp(false)}>关闭</button></footer></Modal>}
    {isAndroid && <span className="sr-only" role="status">{saveAnnouncement}</span>}
    {toast && <div className="toast" key={toast.id} role="status" aria-live="polite"><span className="toast-check"><Check size={16} /></span><div><strong>{toast.message}</strong><span>已保存到本地</span></div>{toast.change && <button className="toast-undo" onClick={() => { void undo(); }} disabled={undoing}><Undo2 size={15} />{undoing ? '撤销中…' : '撤销'}</button>}<button className="icon-button" aria-label="关闭保存提示" disabled={undoing} onClick={() => setToast(null)}><X size={15} /></button></div>}
  </div>;
}


