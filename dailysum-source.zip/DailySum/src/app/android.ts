import { App as NativeApp } from '@capacitor/app';
import { Capacitor, registerPlugin } from '@capacitor/core';
import { isAndroidPreview } from './previewMode';

export const isNativeAndroid = Capacitor.getPlatform() === 'android';
export const isAndroid = isNativeAndroid || isAndroidPreview;

const touchFeedback = registerPlugin<{ play(options: { kind: 'key' | 'confirm' }): Promise<void> }>('TouchFeedback');

export function playAndroidHaptic(kind: 'key' | 'confirm') {
  if (isNativeAndroid) void touchFeedback.play({ kind }).catch(() => {});
}

export function listenForAndroidEvents(onResume: () => void) {
  if (!isNativeAndroid) return;

  const back = NativeApp.addListener('backButton', () => {
    const popover = Array.from(document.querySelectorAll<HTMLElement>(':popover-open')).at(-1);
    if (popover) {
      popover.hidePopover();
      return;
    }

    const dialog = Array.from(document.querySelectorAll('dialog[open]')).at(-1);
    if (dialog) {
      dialog.dispatchEvent(new Event('cancel', { cancelable: true }));
      return;
    }

    if (window.location.hash && window.location.hash !== '#/transactions') {
      window.location.replace('#/transactions');
      return;
    }

    void NativeApp.exitApp();
  });

  const resume = NativeApp.addListener('resume', onResume);
  return () => {
    void back.then((handle) => handle.remove());
    void resume.then((handle) => handle.remove());
  };
}
