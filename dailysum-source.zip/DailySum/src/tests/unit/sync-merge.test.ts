import { describe, expect, it } from 'vitest';
import { latestRates } from '../../domain/fx';
import { mergeLedger, syncSignature, toSyncData } from '../../domain/merge';
import { emptyReportRules } from '../../domain/reportFilters';
import { normalizeCategoryTransactions } from '../../domain/categories';
import { validateData, type LedgerData } from '../../domain/portable';
import { emptyData, now, rate, transaction } from './data-fixtures';
describe('content-based three-way synchronization',()=>{
  it('merges independent offline additions and tombstones without duplicate rows',()=>{
    const initial=transaction(),base={...emptyData(),transactions:[initial]},left=transaction(),right=transaction();
    const result=mergeLedger(base,{...base,transactions:[{...initial,deletedAt:now},left]},{...base,transactions:[initial,right]});
    expect(result.unresolved).toEqual([]);expect(result.data.transactions).toHaveLength(3);expect(result.data.transactions.find((row)=>row.id===initial.id)?.deletedAt).toBe(now);
  });
  it('only adopts the changed side relative to baseline, regardless of the device clock',()=>{
    const row=transaction(),base={...emptyData(),transactions:[row]};
    const result=mergeLedger(base,{...base,transactions:[{...row,updatedAt:'2099-01-01T00:00:00.000Z'}]},{...base,transactions:[{...row,amountMinor:4500,updatedAt:'2000-01-01T00:00:00.000Z'}]});
    expect(result.unresolved).toEqual([]);expect(result.data.transactions[0].amountMinor).toBe(4500);
  });
  it('requires explicit selection for divergent money changes and edit-versus-delete conflicts',()=>{
    const row=transaction(),base={...emptyData(),transactions:[row]},local={...base,transactions:[{...row,deletedAt:now}]},remote={...base,transactions:[{...row,amountMinor:3000}]};
    const result=mergeLedger(base,local,remote);expect(result.unresolved).toHaveLength(1);
    const chosen=mergeLedger(base,local,remote,{[result.conflicts[0].key]:'remote'});expect(chosen.unresolved).toEqual([]);expect(chosen.data.transactions[0]).toMatchObject({amountMinor:3000,deletedAt:null});
  });
  it('reconciles filters including deletion, and surfaces category and filter edit conflicts',()=>{
    const id=crypto.randomUUID(),view={id,name:'日常',rules:emptyReportRules(),createdAt:now,updatedAt:now};
    const base=emptyData();base.filterPreferences.views=[view];
    const local=structuredClone(base),remote=structuredClone(base);local.filterPreferences.views=[];
    expect(mergeLedger(base,local,remote).data.filterPreferences.views).toEqual([]);
    local.categories[0].name='本地分类';remote.categories[0].name='其他分类';remote.filterPreferences.views[0].name='远端过滤器';
    expect(mergeLedger(base,local,remote).unresolved.map((conflict)=>conflict.kind).sort()).toEqual(['category','filter']);
  });
  const route = (data: LedgerData, source: string, destination: string): LedgerData => {
    const categories = data.categories.map((category) => category.id === source ? { ...category, mergedIntoId: destination } : category);
    return { ...data, categories, transactions: normalizeCategoryTransactions(data.transactions, categories) };
  };
  it('resolves reciprocal category moves as one choice without losing edits to their transactions', () => {
    const first = transaction({ categoryId: 'food' }), second = transaction({ categoryId: 'shopping' });
    const base = { ...emptyData(), transactions: [first, second] };
    const local = route(base, 'food', 'shopping');
    const remote = route({ ...base, transactions: [first, { ...second, note: '另一台设备的备注' }] }, 'shopping', 'food');
    const preview = mergeLedger(base, local, remote);
    expect(preview.unresolved.map(({ kind }) => kind)).toEqual(['category-routing']);
    const accepted = mergeLedger(base, local, remote, { [preview.unresolved[0].key]: 'remote' });
    expect(accepted.unresolved).toEqual([]);
    const rows = validateData(accepted.data).transactions;
    expect(rows.find((row) => row.id === first.id)).toMatchObject({ categoryId: 'food', amountMinor: first.amountMinor });
    expect(rows.find((row) => row.id === second.id)).toMatchObject({ categoryId: 'food', note: '另一台设备的备注', categoryHistory: ['shopping'] });
  });
  it('moves old transactions to the selected destination when the same category was moved to different places', () => {
    const row = transaction({ categoryId: 'food' });
    const base = { ...emptyData(), transactions: [row] };
    const local = route(base, 'food', 'shopping');
    const remote = route(base, 'food', 'living');
    const preview = mergeLedger(base, local, remote);
    expect(preview.unresolved.map(({ kind }) => kind)).toEqual(['category']);
    const accepted = mergeLedger(base, local, remote, { [preview.unresolved[0].key]: 'remote' });
    expect(accepted.unresolved).toEqual([]);
    expect(accepted.data.transactions[0]).toMatchObject({ categoryId: 'living', categoryHistory: ['food'] });
  });
  it('preserves both FX histories, resolves a concurrent quote explicitly and makes the winner latest',()=>{
    const original=rate(),base={...emptyData(),fxRates:[original]},a=rate({rate:'1.2',revision:2}),b=rate({rate:'1.3',revision:2});
    const local={...base,fxRates:[original,a]},remote={...base,fxRates:[original,b]};const unresolved=mergeLedger(base,local,remote);expect(unresolved.unresolved[0].kind).toBe('fx');
    const resolved=mergeLedger(base,local,remote,{[unresolved.conflicts[0].key]:'local'});expect(resolved.data.fxRates).toHaveLength(4);expect(latestRates(resolved.data.fxRates).get(original.rateDate)).toMatchObject({revision:3,rate:'1.2'});
    const next=mergeLedger(resolved.data,resolved.data,remote);expect(next.unresolved).toEqual([]);
  });
  it('keeps independent input defaults and the current filter selection device-local',()=>{
    const a=emptyData(),b=emptyData();b.settings.inputCurrency='CNY';b.settings.lastExpenseCategoryId='transport';b.settings.lastTransactionType='income';
    expect(syncSignature(a)).toBe(syncSignature(b));expect(toSyncData(b).settings.inputCurrency).toBe('HKD');
    const base=emptyData();b.settings.reportCurrency='CNY';expect(mergeLedger(base,a,b).data.settings.reportCurrency).toBe('CNY');
  });
  it('rejects immutable rate-ID collisions instead of choosing one silently',()=>{
    const quote=rate();expect(()=>mergeLedger(null,{...emptyData(),fxRates:[quote]},{...emptyData(),fxRates:[{...quote,rate:'1.5'}]})).toThrow('不一致');
  });
});
