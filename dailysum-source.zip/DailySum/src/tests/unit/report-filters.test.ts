import { afterEach, describe, expect, it } from 'vitest';
import { DEFAULT_CATEGORIES, type FxRate, type Transaction } from '../../domain/models';
import { emptyReportRules, evaluateReportRule, parseRuleAmount, reportRulesSchema, splitKeywords } from '../../domain/reportFilters';
import { selectReportTransactions, summarizeSelection, type ReportFilters } from '../../domain/reports';
import { latestRates } from '../../domain/fx';
import { LedgerDatabase } from '../../storage/db';
import { LedgerRepository } from '../../storage/ledgerRepository';
import { ReportFilterRepository } from '../../storage/reportFilterRepository';

const date = '2026-11-03';
const rate: FxRate = { id: 'test-rate', rateDate: date, sourceDate: date, baseCurrency: 'CNY', quoteCurrency: 'HKD', rate: '1.18', source: 'test', fetchedAt: `${date}T00:00:00.000Z`, isManual: false, revision: 1 };
const row = (amountMinor: number, categoryId: string, note: string, currency: 'HKD' | 'CNY' = 'HKD', type: 'expense' | 'income' = 'expense'): Transaction => ({
  id: crypto.randomUUID(), type, amountMinor, currency, categoryId, note, occurredOn: date, createdAt: `${date}T00:00:00.000Z`, updatedAt: `${date}T00:00:00.000Z`, deletedAt: null, schemaVersion: 1,
});
const data = [row(3000,'food','午餐'),row(2000,'transport','地铁'),row(5000,'food','晚餐','CNY'),row(300000,'shopping','旅行'),row(8000,'food','水电费'),row(100000,'food','聚餐'),row(2800000,'salary','工资','HKD','income')];
const filters: ReportFilters = { from: date, to: date, type: '', categoryId: '', currency: '', query: '' };

describe('custom report filters', () => {
  it('combines type, multi-category inclusion, amount cap and excluded note as AND rules', () => {
    const rules = { ...emptyReportRules(), type: 'expense' as const, includeCategoryIds: ['food','transport'], maxAmountMinor: 50000, excludeKeywords: ['水电费'] };
    const selected = selectReportTransactions(data, { ...filters, rules }, DEFAULT_CATEGORIES, [rate]);
    expect(selected.matched).toEqual(data.slice(0,3));
    expect(selected.excluded).toHaveLength(4);
    expect(summarizeSelection(selected, 'HKD', [rate]).expense.amount).toBe(10900n);
    expect(summarizeSelection(selected, 'CNY', [rate]).expense.amount).toBe(9237n);
    expect(selected.excluded.find(({ transaction }) => transaction.note === '水电费')?.reason).toContain('水电费');
  });
  it('category exclusion wins over inclusion and keyword matching is normalized', () => {
    const rules = { ...emptyReportRules(), includeCategoryIds: ['food','transport'], excludeCategoryIds: ['food'] };
    expect(selectReportTransactions(data, { ...filters,rules }, DEFAULT_CATEGORIES,[rate]).matched).toEqual([data[1]]);
    const english = row(100,'food','ＰＯＷＥＲ Bill');
    expect(evaluateReportRule(english,{...emptyReportRules(),excludeKeywords:['power']},new Map()).state).toBe('excluded');
  });
  it('amount limits are inclusive and compare unrounded conversion, even if the displayed amount rounds down', () => {
    const limits = { ...emptyReportRules(), minAmountMinor: 11800, maxAmountMinor: 11800 };
    expect(evaluateReportRule(row(10000,'food','边界','CNY'),limits,latestRates([rate])).state).toBe('match');
    expect(evaluateReportRule(row(1,'food','小额','CNY'),{...emptyReportRules(),maxAmountMinor:1},latestRates([rate])).state).toBe('excluded');
  });
  it('keeps amount-rule currency fixed while the final display currency changes', () => {
    const rules = { ...emptyReportRules('HKD'), maxAmountMinor: 10000 };
    const selected = selectReportTransactions([row(10000,'food','午餐','CNY')],{...filters,rules},DEFAULT_CATEGORIES,[rate]);
    expect(selected.matched).toHaveLength(0);
    expect(selected.excluded[0].reason).toContain('HK$ 100.00');
  });
  it('unknown FX produces pending membership and never presents a complete zero / partial report', () => {
    const rules = { ...emptyReportRules('HKD'), maxAmountMinor: 15000 };
    const selected = selectReportTransactions([row(10000,'food','午餐','CNY')],{...filters,rules},DEFAULT_CATEGORIES,[]);
    expect(selected.pending).toHaveLength(1); expect(selected.excluded).toHaveLength(0);
    const report = summarizeSelection(selected,'CNY',[]);
    expect(report.expense.missing).toBe(1); expect(report.net).toBeNull();
    expect(selectReportTransactions([row(10000,'food','午餐','CNY')],{...filters,rules},DEFAULT_CATEGORIES,[rate]).matched).toHaveLength(1);
  });
  it('does not need FX for records already excluded by a category or keyword', () => {
    const rules = { ...emptyReportRules(),maxAmountMinor:100,excludeKeywords:['水电费'] };
    const selected = selectReportTransactions([row(10000,'food','水电费','CNY')],{...filters,rules},DEFAULT_CATEGORIES,[]);
    expect(selected.pending).toHaveLength(0); expect(selected.excluded).toHaveLength(1);
  });
  it('collects conversion candidates before the amount test, without resurrecting excluded records', () => {
    const rules = { ...emptyReportRules(), includeCategoryIds:['food'],maxAmountMinor:10000,excludeKeywords:['水电费'] };
    const candidates = selectReportTransactions(data,{...filters,rules},DEFAULT_CATEGORIES,[],true);
    expect(candidates.matched).toEqual([data[0],data[2],data[5]]);
    expect(candidates.pending).toHaveLength(0);
  });
  it('individual exclusions do not change transactions and can be restored', () => {
    const original = JSON.stringify(data);
    const rules = { ...emptyReportRules(),excludedTransactionIds:[data[0].id] };
    expect(selectReportTransactions(data,{...filters,rules},DEFAULT_CATEGORIES,[rate]).excluded[0].reason).toBe('手动排除此笔');
    expect(selectReportTransactions(data,{...filters,rules:{...rules,excludedTransactionIds:[]}},DEFAULT_CATEGORIES,[rate]).matched).toHaveLength(7);
    expect(JSON.stringify(data)).toBe(original);
  });
  it('supports original-currency, legacy category and search filters alongside saved rules', () => {
    const rules = { ...emptyReportRules(),includeCategoryIds:['food','transport'] };
    expect(selectReportTransactions(data,{...filters,rules,currency:'CNY',query:'晚餐'},DEFAULT_CATEGORIES,[rate]).matched).toEqual([data[2]]);
  });
  it('validates empty, zero, two decimals and invalid bounds exactly', () => {
    expect(parseRuleAmount('')).toBeNull(); expect(parseRuleAmount('0.00')).toBe(0); expect(parseRuleAmount('1,234.50')).toBe(123450);
    for (const input of ['-1','NaN','1.234','100000000']) expect(() => parseRuleAmount(input)).toThrow();
    expect(reportRulesSchema.safeParse({...emptyReportRules(),minAmountMinor:100,maxAmountMinor:99}).success).toBe(false);
    expect(splitKeywords('水电费，报销,水电费；房租')).toEqual(['水电费','报销','房租']);
  });
});

const databases: LedgerDatabase[] = [];
afterEach(async () => { await Promise.all(databases.splice(0).map((db) => db.delete())); });
async function repository() {
  const db = new LedgerDatabase(`filter-${crypto.randomUUID()}`); databases.push(db);
  const ledger = new LedgerRepository(db); await ledger.initialize();
  return { db,ledger,views:new ReportFilterRepository(db) };
}
describe('saved filter preferences in the existing database', () => {
  it('initializes without changing the v1 schema or the original user settings', async () => {
    const {db,ledger,views} = await repository();
    expect(db.verno).toBe(1); expect((await views.read()).views).toEqual([]);
    await views.save('日常', {...emptyReportRules(),includeCategoryIds:['food','transport']});
    const snapshot = await ledger.snapshot();
    expect(snapshot.settings.inputCurrency).toBe('HKD'); expect(snapshot.filterPreferences.views).toHaveLength(1);
    expect(await db.transactions.count()).toBe(0);
  });
  it('persists named rules and active selection across reopen', async () => {
    const {db,views} = await repository();
    const stored = await views.save('日常开支',{...emptyReportRules(),maxAmountMinor:50000,excludeKeywords:['水电费']});
    db.close(); await db.open();
    const loaded = await new ReportFilterRepository(db).read();
    expect(loaded).toEqual(stored); expect(loaded.activeId).toBe(loaded.views[0].id);
  });
  it('rejects duplicate names and stale edits without creating a second filter', async () => {
    const {views} = await repository(); const first = (await views.save('日常',emptyReportRules())).views[0];
    await expect(views.save('日常',emptyReportRules())).rejects.toThrow('同名');
    await views.save('日常修改', {...emptyReportRules(),maxAmountMinor:100},first);
    await expect(views.save('再次修改',emptyReportRules(),first)).rejects.toThrow('其他窗口');
    expect((await views.read()).views).toHaveLength(1);
  });
  it('rejects stale deletes, supports clearing the view and never deletes ledger entries', async () => {
    const {views,db} = await repository(); await db.transactions.add(data[0]);
    const first = (await views.save('日常',emptyReportRules())).views[0];
    const updated = (await views.save('日常修改',emptyReportRules(),first)).views[0];
    await expect(views.remove(first)).rejects.toThrow('其他窗口');
    await views.activate(null); expect((await views.read()).activeId).toBeNull();
    await views.remove(updated); expect((await views.read()).views).toHaveLength(0);
    expect(await db.transactions.get(data[0].id)).toEqual(data[0]);
  });
  it('serializes simultaneous duplicate creates in one settings transaction', async () => {
    const {views} = await repository();
    const results = await Promise.allSettled([views.save('日常',emptyReportRules()),views.save('日常',emptyReportRules())]);
    expect(results.filter((result) => result.status === 'fulfilled')).toHaveLength(1);
    expect((await views.read()).views).toHaveLength(1);
  });
});
