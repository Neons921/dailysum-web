import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { DEFAULT_CATEGORIES, type TransactionDraft } from '../../domain/models';
import { LedgerDatabase } from '../../storage/db';
import { LedgerRepository } from '../../storage/ledgerRepository';
import { LedgerService } from '../../services/ledgerService';

let db: LedgerDatabase;
let service: LedgerService;
const draft: TransactionDraft = {
  type: 'expense', amountMinor: 12850, currency: 'HKD', categoryId: 'food', note: '午饭', occurredOn: '2026-11-03',
};
beforeEach(async () => {
  db = new LedgerDatabase(`test-${crypto.randomUUID()}`);
  service = new LedgerService(new LedgerRepository(db));
  await service.initialize();
});
afterEach(async () => { vi.restoreAllMocks(); await db.delete(); });

describe('atomic local ledger operations', () => {
  it('initializes an empty real ledger and safely reinitializes its schema', async () => {
    const snapshot = await service.initialize();
    expect(snapshot.transactions).toEqual([]);
    expect(snapshot.categories).toHaveLength(DEFAULT_CATEGORIES.length);
    expect(snapshot.settings.inputCurrency).toBe('HKD');
    expect(await db.fxRates.count()).toBe(0);
  });
  it('persists records through database close/reopen', async () => {
    const id = crypto.randomUUID();
    await service.save(id, draft);
    db.close();
    await db.open();
    const snapshot = await service.snapshot();
    expect(snapshot.transactions[0]).toMatchObject({ id, ...draft });
  });
  it('keeps a create idempotent under simultaneous submissions', async () => {
    const id = crypto.randomUUID();
    const [first, second] = await Promise.all([service.save(id, draft), service.save(id, draft)]);
    expect(first.change.after.id).toBe(second.change.after.id);
    expect(await db.transactions.count()).toBe(1);
  });
  it('edits every field without converting the numeric amount and undoes the edit', async () => {
    const created = await service.save(crypto.randomUUID(), draft);
    const updated = await service.save(created.change.after.id, {
      ...draft, currency: 'CNY', categoryId: 'transport', note: '地铁', occurredOn: '2026-10-31',
    }, created.change.after);
    expect(updated.change.after).toMatchObject({ amountMinor: 12850, currency: 'CNY', categoryId: 'transport', note: '地铁', occurredOn: '2026-10-31' });
    expect(updated.change.after.createdAt).toBe(created.change.after.createdAt);
    const restored = await service.undo(updated.change);
    expect(restored).toMatchObject(draft);
  });
  it('tombstones a deletion and restores it by undo', async () => {
    const created = await service.save(crypto.randomUUID(), draft);
    const deleted = await service.remove(created.change.after);
    expect(deleted.after.deletedAt).toBeTruthy();
    expect((await service.snapshot()).transactions.filter((transaction) => !transaction.deletedAt)).toHaveLength(0);
    const restored = await service.undo(deleted);
    expect(restored.deletedAt).toBeNull();
    expect(restored).toMatchObject(draft);
  });
  it('undoes a create while retaining the original fields for the editor', async () => {
    const created = await service.save(crypto.randomUUID(), draft);
    const undone = await service.undo(created.change);
    expect(undone.deletedAt).toBeTruthy();
    expect(created.change.after).toMatchObject(draft);
    expect((await service.snapshot()).transactions.filter((transaction) => !transaction.deletedAt)).toHaveLength(0);
  });
  it('rolls back both the record and preferences on storage failure and permits a retry', async () => {
    const id = crypto.randomUUID();
    vi.spyOn(db.settings, 'put').mockRejectedValueOnce(new Error('模拟写入失败'));
    await expect(service.save(id, { ...draft, currency: 'CNY' })).rejects.toThrow('模拟写入失败');
    expect(await db.transactions.count()).toBe(0);
    expect((await service.snapshot()).settings.inputCurrency).toBe('HKD');
    await service.save(id, { ...draft, currency: 'CNY' });
    expect(await db.transactions.count()).toBe(1);
    expect((await service.snapshot()).settings.inputCurrency).toBe('CNY');
  });
  it('keeps report preferences independent of the most recent transaction currency', async () => {
    await service.save(crypto.randomUUID(), { ...draft, currency: 'CNY' });
    expect((await service.snapshot()).settings).toMatchObject({ inputCurrency: 'CNY', reportCurrency: 'HKD' });
    await service.updateSettings({ reportCurrency: 'CNY' });
    await service.save(crypto.randomUUID(), draft);
    expect((await service.snapshot()).settings).toMatchObject({ inputCurrency: 'HKD', reportCurrency: 'CNY' });
  });
  it('rejects invalid amounts, invalid dates and categories of the wrong transaction type', async () => {
    for (const invalid of [
      { ...draft, amountMinor: 0 }, { ...draft, amountMinor: -1 },
      { ...draft, amountMinor: 1.2 }, { ...draft, amountMinor: Number.POSITIVE_INFINITY },
      { ...draft, type: 'income' as const }, { ...draft, occurredOn: '2026-02-30' },
      { ...draft, note: '长'.repeat(10001) },
    ]) await expect(service.save(crypto.randomUUID(), invalid)).rejects.toThrow();
    expect(await db.transactions.count()).toBe(0);
  });
  it('prevents stale edits and undo from overwriting a later change', async () => {
    const created = await service.save(crypto.randomUUID(), draft);
    const edited = await service.save(created.change.after.id, { ...draft, amountMinor: 4200 }, created.change.after);
    await expect(service.save(created.change.after.id, { ...draft, amountMinor: 5500 }, created.change.after)).rejects.toThrow('其他窗口');
    await expect(service.undo(created.change)).rejects.toThrow('再次修改');
    expect((await db.transactions.get(edited.change.after.id))?.amountMinor).toBe(4200);
  });
});
