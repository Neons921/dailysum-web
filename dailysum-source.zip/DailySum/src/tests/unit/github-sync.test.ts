import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { GitHubClient } from '../../services/githubClient';
import { SyncService } from '../../services/syncService';
import { DataRepository } from '../../storage/dataRepository';
import { LedgerDatabase } from '../../storage/db';
import { LedgerRepository } from '../../storage/ledgerRepository';
import { base64ToUtf8, createEnvelope, dataSignature, utf8ToBase64, type LedgerEnvelope } from '../../domain/portable';
import { mergeLedger, toSyncData } from '../../domain/merge';
import { emptySyncProfile, repositoryName } from '../../domain/sync';
import { bill, emptyData, transaction } from './data-fixtures';
import { DataService } from '../../services/dataService';
import { GITHUB_CONNECTION_KEY } from '../../storage/githubConnectionRepository';
const CENT_SOURCE_REPOSITORY = 'example-user/cent-journal-example-ledger';
import Dexie from 'dexie';

class Remote {
  envelope:LedgerEnvelope|null=null;sha='a'.repeat(40);isPrivate=true;fail=false;unauthorized=false;conflict=false;writes=0;onWrite:(()=>Promise<void>)|undefined;
  requests:{path:string;method:string;body:Record<string,unknown>|null;auth:string|null}[]=[];
  fetch:typeof fetch=async(input,init)=>{
    if(this.fail)throw new TypeError('network failed');const url=new URL(String(input)),method=init?.method??'GET';
    const body=init?.body?JSON.parse(String(init.body)) as Record<string,unknown>:null;this.requests.push({path:url.pathname,method,body,auth:new Headers(init?.headers).get('Authorization')});
    if(url.origin!=='https://api.github.com')throw new Error('unexpected host');
    const reply=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json'}});
    if(this.unauthorized)return reply({},401);
    if(url.pathname==='/repos/example-user/DailySum')return reply({full_name:'example-user/DailySum',private:this.isPrivate,default_branch:'main',permissions:{push:true}});
    if(url.pathname.endsWith('/contents/dailysum/ledger.v1.json')) {
      if(method==='PUT'){
        this.writes++;if(this.conflict)return reply({},409);
        if((this.envelope&&body?.sha!==this.sha)||(!this.envelope&&body?.sha))return reply({},409);
        this.envelope=JSON.parse(base64ToUtf8(String(body?.content))) as LedgerEnvelope;this.sha=String(this.writes).padStart(40,'b');await this.onWrite?.();return reply({content:{sha:this.sha}});
      }
      return this.envelope?reply({type:'file',sha:this.sha,size:JSON.stringify(this.envelope).length,encoding:'base64',content:utf8ToBase64(JSON.stringify(this.envelope))}):reply({},404);
    }
    throw new Error(`Unhandled fixture path ${url.pathname}`);
  };
}
let db:LedgerDatabase,repository:DataRepository,remote:Remote,sync:SyncService;
let restoredSessions:SyncService[]=[];
beforeEach(async()=>{db=new LedgerDatabase(`sync-${crypto.randomUUID()}`);await new LedgerRepository(db).initialize();repository=new DataRepository(db);remote=new Remote();sync=new SyncService(repository,new GitHubClient(remote.fetch));await sync.initialize();});
afterEach(async()=>{vi.restoreAllMocks();vi.unstubAllGlobals();for(const session of restoredSessions)if(session.getState().connected)await session.disconnect();restoredSessions=[];if(sync.getState().connected)await sync.disconnect();await db.delete();});
const connect=()=>sync.connect('example-user/DailySum','FAKE_TOKEN_UNIT_TEST');
const restoredSession=()=>{const session=new SyncService(repository,new GitHubClient(remote.fetch));restoredSessions.push(session);return session;};
describe('GitHub API and synchronization transactions',()=>{
  it('uploads using SHA and keeps the remembered credential separate from all portable ledger data',async()=>{
    await db.transactions.put(transaction());await connect();await sync.commit(await sync.prepare());expect(remote.envelope?.data.transactions).toHaveLength(1);
    const row=transaction({note:'第二笔'});await db.transactions.put(row);await sync.commit(await sync.prepare());
    expect(remote.envelope?.data.transactions).toHaveLength(2);const puts=remote.requests.filter((request)=>request.method==='PUT');expect(puts[0].body?.sha).toBeUndefined();expect(puts[1].body?.sha).toBe('b'.repeat(39)+'1');
    expect(puts[0].auth).toBe('Bearer FAKE_TOKEN_UNIT_TEST');expect(JSON.stringify(remote.envelope)).not.toContain('FAKE_TOKEN');
    expect((await sync.connections.read()).connection?.token).toBe('FAKE_TOKEN_UNIT_TEST');
    expect(JSON.stringify(await repository.read())).not.toContain('FAKE_TOKEN');expect(await new DataService(repository).backup()).not.toContain('FAKE_TOKEN');
    expect(JSON.stringify(await repository.checkpoints())).not.toContain('FAKE_TOKEN');
  });
  it('pulls remote additions atomically and preserves local input preferences',async()=>{
    const row=transaction({currency:'CNY'});remote.envelope=await createEnvelope(toSyncData({...emptyData(),transactions:[row]}),crypto.randomUUID());
    await db.settings.update('user',{inputCurrency:'CNY'});await connect();const plan=await sync.prepare();expect((await repository.read()).transactions).toEqual([]);
    expect(await sync.commit(plan)).toBe(true);expect((await repository.read()).transactions[0].id).toBe(row.id);expect((await repository.read()).settings.inputCurrency).toBe('CNY');expect(await repository.checkpoints()).toHaveLength(1);
  });
  it('requires explicit choices for concurrent edits and leaves both local and remote untouched until selected',async()=>{
    const row=transaction();await db.transactions.put(row);await connect();await sync.commit(await sync.prepare());
    await db.transactions.put({...row,amountMinor:3000});remote.envelope=await createEnvelope({...remote.envelope!.data,transactions:[{...row,amountMinor:4000}]},remote.envelope!.ledgerId);
    const plan=await sync.prepare(),conflict=mergeLedger(plan.base,plan.before,plan.remote).conflicts[0];const writes=remote.writes;
    await expect(sync.commit(plan)).rejects.toThrow('冲突');expect(remote.writes).toBe(writes);expect((await db.transactions.get(row.id))?.amountMinor).toBe(3000);
    const fresh=await sync.prepare();await sync.commit(fresh,{[conflict.key]:'remote'});expect((await db.transactions.get(row.id))?.amountMinor).toBe(4000);
  });
  it('handles a remote 409 without force-writing or applying a stale local merge',async()=>{
    await db.transactions.put(transaction());await connect();const plan=await sync.prepare();const before=dataSignature(await repository.read());remote.conflict=true;
    await expect(sync.commit(plan)).rejects.toThrow('重新检查');expect(dataSignature(await repository.read())).toBe(before);expect((await repository.profile()).baseline).toBeNull();expect(remote.writes).toBe(1);
    remote.conflict=false;await sync.commit(await sync.prepare());expect(sync.getState().status).toBe('idle');
  });
  it('preserves local changes made during upload and keeps the previous baseline for the next merge',async()=>{
    const row=transaction();await db.transactions.put(row);await connect();await sync.commit(await sync.prepare());const baseline=(await repository.profile()).baseline;
    await db.transactions.put({...row,amountMinor:3000});remote.onWrite=async()=>{await db.transactions.put({...row,amountMinor:5000});};
    await expect(sync.commit(await sync.prepare())).rejects.toThrow('新变更');expect((await db.transactions.get(row.id))?.amountMinor).toBe(5000);expect((await repository.profile()).baseline).toEqual(baseline);expect(remote.envelope?.data.transactions[0].amountMinor).toBe(3000);
    remote.onWrite=undefined;const next=await sync.prepare();expect(mergeLedger(next.base,next.before,next.remote).unresolved).toHaveLength(1);
  });
  it('retries after a network failure without dropping unsynced records',async()=>{
    await connect();await db.transactions.put(transaction());remote.fail=true;await expect(sync.prepare()).rejects.toThrow('网络');expect((await repository.read()).transactions).toHaveLength(1);
    remote.fail=false;await sync.commit(await sync.prepare());expect(remote.envelope?.data.transactions).toHaveLength(1);
  });
  it('automatic sync stops for conflicts, skips work while paused and does not publish before initial review',async()=>{
    await connect();await expect(sync.setAuto(true)).rejects.toThrow('手动');await db.transactions.put(transaction());await sync.commit(await sync.prepare());await sync.setAuto(true);
    await db.transactions.put(transaction());sync.setPaused(true);await sync.autoSync();expect(remote.envelope?.data.transactions).toHaveLength(1);
    sync.setPaused(false);await sync.autoSync();expect(remote.envelope?.data.transactions,sync.getState().message).toHaveLength(2);
    const row=(await repository.read()).transactions[0];await db.transactions.put({...row,amountMinor:4000});remote.envelope=await createEnvelope({...remote.envelope!.data,transactions:remote.envelope!.data.transactions.map((item)=>item.id===row.id?{...item,amountMinor:6000}:item)},remote.envelope!.ledgerId);
    const writes=remote.writes;await sync.autoSync();expect(sync.getState().status).toBe('review');expect(remote.writes).toBe(writes);
  });
  it('rejects public targets, Cent source targets and unsafe repository URLs before upload',async()=>{
    remote.isPrivate=false;await expect(connect()).rejects.toThrow('私有');expect(remote.writes).toBe(0);
    await expect(sync.connect(CENT_SOURCE_REPOSITORY,'FAKE')).rejects.toThrow('Cent 原仓库');expect(()=>repositoryName('https://evil.example/example-user/DailySum')).toThrow('仅支持');
    expect(repositoryName('https://github.com/example-user/cent-journal-example-ledger')).toBe(CENT_SOURCE_REPOSITORY);
  });
  it('rechecks privacy on every upload, including after a repository visibility change',async()=>{
    await connect();const plan=await sync.prepare();remote.isPrivate=false;await expect(sync.commit(plan)).rejects.toThrow('私有');expect(remote.writes).toBe(0);
  });
  it('refuses a replaced remote ledger identity and the disappearance of a previously synced file',async()=>{
    await connect();await sync.commit(await sync.prepare());remote.envelope=await createEnvelope(emptyData(),crypto.randomUUID());await expect(sync.prepare()).rejects.toThrow('身份');remote.envelope=null;await expect(sync.prepare()).rejects.toThrow('移除');
  });
  it('reads Cent logs and binary assets by immutable blob SHA and never writes to the source',async()=>{
    const paths:string[]=[],metaSha='1'.repeat(40),chunkSha='2'.repeat(40),assetSha='3'.repeat(40);
    const client=new GitHubClient(async(input,init)=>{const url=new URL(String(input));paths.push(`${init?.method??'GET'} ${url.pathname}`);const json=(body:unknown)=>new Response(JSON.stringify(body));
      if(url.pathname.endsWith(`/repos/${CENT_SOURCE_REPOSITORY}`))return json({full_name:CENT_SOURCE_REPOSITORY,private:true,default_branch:'main'});
      if(url.pathname.includes('/git/trees/'))return json({sha:'4'.repeat(40),truncated:false,tree:[{path:'meta.json',type:'blob',sha:metaSha,size:40},{path:'ledger-0.json',type:'blob',sha:chunkSha,size:200},{path:'assets/test.png',type:'blob',sha:assetSha,size:3}]});
      const text=url.pathname.endsWith(metaSha)?JSON.stringify({baseCurrency:'CNY'}):url.pathname.endsWith(chunkSha)?JSON.stringify([{id:'action',type:'update',timestamp:1,value:bill()}]):'abc';return json({content:utf8ToBase64(text),encoding:'base64',size:text.length});
    });client.connect('FAKE');const result=await client.readCent(CENT_SOURCE_REPOSITORY);expect((result.data.items as unknown[])).toHaveLength(1);expect(result.attachments[0].content).toBe('YWJj');expect(paths.every((path)=>path.startsWith('GET '))).toBe(true);expect(result.source).toContain('4'.repeat(40));
  });
  it('does not checkpoint or notify a local change when a no-op synchronization only advances metadata',async()=>{
    await connect();expect(await sync.commit(await sync.prepare())).toBe(false);expect(await sync.commit(await sync.prepare())).toBe(false);expect(await repository.checkpoints()).toHaveLength(0);expect(remote.writes).toBe(1);
  });
  it('uses the object media type and a pinned blob for ledger files over the inline content threshold',async()=>{
    const envelope=await createEnvelope(emptyData(),crypto.randomUUID()),sha='f'.repeat(40),calls:string[]=[];
    const client=new GitHubClient(async(input,init)=>{const url=new URL(String(input));calls.push(url.pathname);if(url.pathname.includes('/contents/')){expect(new Headers(init?.headers).get('Accept')).toBe('application/vnd.github.object+json');return new Response(JSON.stringify({type:'file',sha,size:1100000,encoding:'none',content:''}));}return new Response(JSON.stringify({encoding:'base64',size:1100000,content:utf8ToBase64(JSON.stringify(envelope))}));});
    client.connect('FAKE');const result=await client.read({...emptySyncProfile(),repository:'example-user/DailySum',branch:'main'});expect(result?.envelope.integrity).toBe(envelope.integrity);expect(calls[1]).toContain(`/git/blobs/${sha}`);
  });
  it('restores a remembered connection and pulls new remote data on startup, once under repeated initialization',async()=>{
    await db.transactions.put(transaction());await connect();await sync.commit(await sync.prepare());
    remote.envelope=await createEnvelope({...remote.envelope!.data,transactions:[...remote.envelope!.data.transactions,transaction({note:'另一台设备'})]},remote.envelope!.ledgerId);
    const requests=remote.requests.length,session=restoredSession();await Promise.all([session.initialize(),session.initialize()]);
    expect(session.getState()).toMatchObject({connected:true,remembered:true,status:'idle',profile:{auto:true}});
    expect((await repository.read()).transactions).toHaveLength(2);expect(remote.requests.length-requests).toBe(2);
  });
  it('remembers a connection without bypassing the first manual review on a later startup',async()=>{
    await connect();await db.transactions.put(transaction());const requests=remote.requests.length;
    const session=restoredSession();await session.initialize();await session.autoSync();
    expect(session.getState()).toMatchObject({connected:true,remembered:true,profile:{baseline:null}});expect(remote.writes).toBe(0);expect(remote.requests).toHaveLength(requests);
  });
  it('keeps a connection session-only when remembering is unchecked',async()=>{
    await sync.connect('example-user/DailySum','FAKE_SESSION_ONLY',{remember:false});expect(sync.getState()).toMatchObject({connected:true,remembered:false});
    expect((await sync.connections.read()).connection).toBeNull();const session=restoredSession();await session.initialize();expect(session.getState().connected).toBe(false);
  });
  it('restores a saved connection with automatic sync disabled without making network requests',async()=>{
    await connect();await sync.commit(await sync.prepare());await sync.setAuto(false);
    const requests=remote.requests.length,session=restoredSession();await session.initialize();
    expect(session.getState()).toMatchObject({connected:true,remembered:true,profile:{auto:false}});expect(remote.requests).toHaveLength(requests);
  });
  it('retains the remembered connection offline and syncs when the network returns',async()=>{
    await connect();await sync.commit(await sync.prepare());remote.envelope=await createEnvelope({...remote.envelope!.data,transactions:[transaction()]},remote.envelope!.ledgerId);
    vi.stubGlobal('navigator',{onLine:false});const session=restoredSession(),requests=remote.requests.length;await session.initialize();
    expect(session.getState()).toMatchObject({connected:true,remembered:true,status:'offline'});expect(remote.requests).toHaveLength(requests);
    vi.stubGlobal('navigator',{onLine:true});await session.autoSync();expect((await repository.read()).transactions).toHaveLength(1);
  });
  it('expires an invalid saved credential without changing ledger data or repeatedly retrying it',async()=>{
    await db.transactions.put(transaction());await connect();await sync.commit(await sync.prepare());const before=dataSignature(await repository.read());remote.unauthorized=true;
    const session=restoredSession();await session.initialize();expect(session.getState()).toMatchObject({connected:false,remembered:false,status:'error'});expect(session.getState().message).toContain('Token 已失效');
    expect((await session.connections.read()).connection).toBeNull();expect(dataSignature(await repository.read())).toBe(before);
    const requests=remote.requests.length;await session.autoSync();expect(remote.requests).toHaveLength(requests);
  });
  it('forgets credentials and automatic startup while retaining the ledger and sync baseline',async()=>{
    await db.transactions.put(transaction());await connect();await sync.commit(await sync.prepare());const profile=await repository.profile(),before=dataSignature(await repository.read());
    await sync.disconnect();expect((await sync.connections.read()).connection).toBeNull();expect((await repository.profile()).auto).toBe(false);expect((await repository.profile()).baseline).toEqual(profile.baseline);expect(dataSignature(await repository.read())).toBe(before);
    const session=restoredSession();await session.initialize();expect(session.getState().connected).toBe(false);
  });
  it('rolls back profile and credential together when remembering a new token fails',async()=>{
    await connect();await sync.setAuto(false);const original=await sync.connections.read();const table=db.table<{id:string;[key:string]:unknown},string>('settings'),put=table.put.bind(table);
    vi.spyOn(table,'put').mockImplementation((record,key)=>record.id===GITHUB_CONNECTION_KEY?Dexie.Promise.reject(new Error('无法保存连接')):put(record,key));
    await expect(sync.connect('example-user/DailySum','FAKE_REPLACEMENT')).rejects.toThrow('保存连接');expect(await sync.connections.read()).toEqual(original);
  });
  it('never sends a saved token to a different target after a mismatched configuration change',async()=>{
    await connect();await repository.setProfile({...await repository.profile(),repository:'Other/Another'});const requests=remote.requests.length;
    const session=restoredSession();await session.initialize();expect(session.getState()).toMatchObject({connected:false,status:'error'});expect(session.getState().message).toContain('不匹配');expect(remote.requests).toHaveLength(requests);
  });
  it('a token rejection cannot delete a newer remembered credential from another window',async()=>{
    await connect();const first=(await sync.connections.read()).connection!;
    const latest=await sync.connections.configure(await repository.profile(),'FAKE_NEW_TOKEN');expect(await sync.connections.forget(first.revision)).toBe(false);expect((await sync.connections.read()).connection?.revision).toBe(latest?.revision);
  });
  it('a connection forgotten in another window prevents committing a prepared upload',async()=>{
    await db.transactions.put(transaction());await connect();const plan=await sync.prepare();const writes=remote.writes;
    await sync.connections.configure({...await repository.profile(),auto:false},null);
    await expect(sync.commit(plan)).rejects.toThrow('连接已变化');expect(remote.writes).toBe(writes);expect((await repository.profile()).auto).toBe(false);
  });
  it('backup imports and local checkpoint restores do not replace or export the saved credential',async()=>{
    await connect();const connection=(await sync.connections.read()).connection!,service=new DataService(repository);
    const envelope=await createEnvelope({...emptyData(),transactions:[transaction()]},crypto.randomUUID());
    await service.commit(await service.importPlan({source:'test.json',data:JSON.parse(JSON.stringify(envelope)),attachments:[]}),{});
    expect((await sync.connections.read()).connection?.revision).toBe(connection.revision);
    await repository.restore((await repository.checkpoints())[0]);expect((await sync.connections.read()).connection?.revision).toBe(connection.revision);
    expect(await service.backup()).not.toContain('FAKE_TOKEN');expect(JSON.stringify(await repository.checkpoints())).not.toContain('FAKE_TOKEN');
  });
});
