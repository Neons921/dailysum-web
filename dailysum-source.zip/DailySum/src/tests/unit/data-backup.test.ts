import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { LedgerDatabase } from '../../storage/db';
import { LedgerRepository } from '../../storage/ledgerRepository';
import { DataRepository } from '../../storage/dataRepository';
import { DataService } from '../../services/dataService';
import { createEnvelope, dataSignature, parseEnvelope, validateData } from '../../domain/portable';
import { emptySyncProfile } from '../../domain/sync';
import { emptyReportRules } from '../../domain/reportFilters';
import { bill, emptyData, now, rate, transaction } from './data-fixtures';
let db:LedgerDatabase,repository:DataRepository,service:DataService;
beforeEach(async()=>{db=new LedgerDatabase(`backup-${crypto.randomUUID()}`);await new LedgerRepository(db).initialize();repository=new DataRepository(db);service=new DataService(repository);});
afterEach(async()=>{vi.restoreAllMocks();await db.delete();});
describe('portable backups and atomic migration',()=>{
  it('roundtrips all ledger data, rates and filters with an integrity hash; credentials and connection metadata stay out',async()=>{
    const before=await repository.read();const row=transaction();const id=crypto.randomUUID();
    const data={...before,transactions:[row,transaction({deletedAt:now})],fxRates:[rate()],filterPreferences:{...before.filterPreferences,activeId:id,views:[{id,name:'日常',rules:emptyReportRules(),createdAt:now,updatedAt:now}]}};
    await repository.commit(data,dataSignature(before),'测试导入');await repository.setProfile({...emptySyncProfile(),auto:true});
    const backup=await service.backup();const result=await parseEnvelope(JSON.parse(backup));expect(result.data).toEqual(validateData(data));expect(result.integrity).toMatch(/^[a-f0-9]{64}$/);
    expect(backup).not.toContain('github-sync');expect(backup).not.toContain('checkpoint:');expect(backup).not.toContain('baseline');expect(await repository.identity()).toBe(result.ledgerId);
  });
  it('rejects damaged checksums, unknown versions, duplicate IDs and dangling references before writing',async()=>{
    const initial=await repository.read(),original=dataSignature(initial);const envelope=await createEnvelope(initial,crypto.randomUUID());
    await expect(parseEnvelope({...envelope,schemaVersion:2})).rejects.toThrow('版本');
    await expect(parseEnvelope({...envelope,data:{...initial,settings:{...initial.settings,reportCurrency:'CNY'}}})).rejects.toThrow('校验值');
    const row=transaction();expect(()=>validateData({...initial,transactions:[row,row]})).toThrow('重复');
    expect(()=>validateData({...initial,transactions:[{...row,categoryId:'missing'}]})).toThrow('分类');
    expect(()=>validateData({...initial,categories:[]})).toThrow('分类');expect(dataSignature(await repository.read())).toBe(original);
  });
  it('does not mutate during import preview and requires explicit consent for unsupported rows',async()=>{
    const before=dataSignature(await repository.read());const plan=await service.importPlan({source:'Cent.json',attachments:[],data:{items:[bill(),bill({id:'usd',currency:{target:'USD',amount:10000}})],meta:{baseCurrency:'CNY'}}});
    expect(dataSignature(await repository.read())).toBe(before);expect(await repository.checkpoints()).toEqual([]);
    await expect(service.commit(plan,{})).rejects.toThrow('确认');await service.commit(plan,{},true);
    expect((await repository.read()).transactions).toHaveLength(1);expect(await repository.checkpoints()).toHaveLength(1);
    const backup=await parseEnvelope(JSON.parse(await service.backup()));expect((backup.data.archives[0].data as {items:unknown[]}).items).toHaveLength(2);
  });
  it('rolls back a failed import including its checkpoint and keeps the same plan retryable',async()=>{
    const before=await repository.read();const plan=await service.importPlan({source:'test.json',attachments:[],data:{items:[bill()],meta:{baseCurrency:'CNY'}}});
    vi.spyOn(db.transactions,'bulkPut').mockRejectedValueOnce(new Error('quota failure'));
    await expect(service.commit(plan,{})).rejects.toThrow('quota');expect(dataSignature(await repository.read())).toBe(dataSignature(before));expect(await repository.checkpoints()).toEqual([]);
    await service.commit(plan,{});expect((await repository.read()).transactions).toHaveLength(1);
  });
  it('blocks a stale preview without overwriting a new local record',async()=>{
    const plan=await service.importPlan({source:'test.json',attachments:[],data:{items:[bill()],meta:{baseCurrency:'CNY'}}});await db.transactions.put(transaction());
    await expect(service.commit(plan,{})).rejects.toThrow('新变更');expect((await repository.read()).transactions).toHaveLength(1);expect(await repository.checkpoints()).toHaveLength(0);
  });
  it('retains three checkpoints and restores old values with tombstones for newer rows',async()=>{
    const row=transaction();let current=await repository.read();await repository.commit({...current,transactions:[row]},dataSignature(current),'初始账单');
    current=await repository.read();await repository.commit({...current,transactions:[{...row,amountMinor:9999},transaction()]},dataSignature(current),'编辑后');
    const point=(await repository.checkpoints())[0];expect(point.data.transactions[0].amountMinor).toBe(2500);
    await repository.restore(point);const restored=await repository.read();expect(restored.transactions.find((item)=>item.id===row.id)?.amountMinor).toBe(2500);expect(restored.transactions.filter((item)=>item.deletedAt)).toHaveLength(1);
    await repository.commit(restored,dataSignature(restored),'保留范围');expect(await repository.checkpoints()).toHaveLength(3);
  });
  it('preserves Cent provenance when an imported bill is edited and includes source in native backups',async()=>{
    const plan=await service.importPlan({source:'test.json',attachments:[],data:{items:[bill()],meta:{baseCurrency:'CNY'}}});await service.commit(plan,{});
    const original=(await repository.read()).transactions[0];expect(await repository.rawCentRecord(original.origin!.archiveId,original.origin!.sourceId)).toBeTruthy();
    const backup=await service.backup();expect((await parseEnvelope(JSON.parse(backup))).data.transactions[0].origin).toEqual(original.origin);
  });
  it('restoring a previous rate preserves history and promotes the restored quote',async()=>{
    const current=emptyData(),old=rate(),newer=rate({rate:'1.2',revision:2});
    const before=await repository.read();await repository.commit({...current,fxRates:[old]},dataSignature(before),'汇率一');
    const first=await repository.read();await repository.commit({...first,fxRates:[old,newer]},dataSignature(first),'汇率二');
    const point=(await repository.checkpoints())[0];await repository.restore(point);const rates=(await repository.read()).fxRates;expect(rates).toHaveLength(3);expect(rates.find((item)=>item.revision===3)?.rate).toBe('1.18');
  });
  it('a native backup restores input/report preferences and the active saved filter as well as records',async()=>{
    const data=emptyData(),id=crypto.randomUUID();data.settings.inputCurrency='CNY';data.settings.reportCurrency='CNY';data.filterPreferences={...data.filterPreferences,activeId:id,views:[{id,name:'备份条件',rules:emptyReportRules(),createdAt:now,updatedAt:now}]};data.transactions=[transaction()];
    const envelope=await createEnvelope(data,crypto.randomUUID());const plan=await service.importPlan({data:JSON.parse(JSON.stringify(envelope)),source:'DailySum.json',attachments:[]});await service.commit(plan,{});
    const restored=await repository.read();expect(restored.settings).toEqual(data.settings);expect(restored.filterPreferences).toEqual(data.filterPreferences);expect(restored.transactions).toEqual(data.transactions);
  });
  it('keeps backup signatures independent of browser locale and collation',async()=>{
    const data=emptyData(),envelope=await createEnvelope(data,crypto.randomUUID());
    vi.spyOn(String.prototype,'localeCompare').mockImplementation(()=>-1);
    expect((await parseEnvelope(envelope)).integrity).toBe(envelope.integrity);
    expect((await createEnvelope(data,envelope.ledgerId)).integrity).toBe(envelope.integrity);
  });
});
