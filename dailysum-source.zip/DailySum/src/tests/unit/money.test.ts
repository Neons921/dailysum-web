import { describe, expect, it } from 'vitest';
import { amountToInput, formatMoney, parseAmount } from '../../domain/money';
import { MAX_AMOUNT_MINOR } from '../../domain/models';

describe('exact minor-unit amount parsing', () => {
  it.each([
    ['0.5', 50], ['12.', 1200], ['12.30', 1230], ['128.50', 12850],
    [' 1,234.50 ', 123450], ['1，234.50', 123450], ['0.29', 29],
    ['0001.01', 101], ['99,999,999.99', MAX_AMOUNT_MINOR],
  ])('parses %s without floating point arithmetic', (input, minor) => {
    expect(parseAmount(input)).toEqual({ ok: true, minor });
  });
  it.each(['', '0', '0.00', '-1', '12.345', 'NaN', 'Infinity', '1e3', '1/2', '¥ 12', '12,50', '1,23,456', '1 234', '100000000', '9999999999999999999999999999999'])('rejects %s', (input) => {
    expect(parseAmount(input).ok).toBe(false);
  });
  it('formats large aggregates precisely and keeps ISO-currency symbols distinct', () => {
    expect(formatMoney(123450, 'HKD')).toBe('HK$ 1,234.50');
    expect(formatMoney(50, 'CNY')).toBe('¥ 0.50');
    expect(formatMoney(-51n, 'CNY')).toBe('−¥ 0.51');
    expect(formatMoney(900719925474099123n, 'HKD')).toBe('HK$ 9,007,199,254,740,991.23');
    expect(amountToInput(12850)).toBe('128.50');
  });
});
