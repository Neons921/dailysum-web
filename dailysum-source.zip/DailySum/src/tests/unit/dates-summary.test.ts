import { describe, expect, it } from 'vitest';
import { hongKongToday, reportPeriodPresets, shiftMonth } from '../../domain/dates';
import { isValidDate, type Transaction } from '../../domain/models';
import { summarizeOriginal } from '../../domain/summary';

describe('Hong Kong calendar dates', () => {
  it('uses the Hong Kong date across a UTC midnight boundary', () => {
    expect(hongKongToday(new Date('2026-11-02T16:01:00Z'))).toBe('2026-11-03');
    expect(hongKongToday(new Date('2026-11-02T15:59:00Z'))).toBe('2026-11-02');
  });
  it('validates real dates including leap years', () => {
    expect(isValidDate('2024-02-29')).toBe(true);
    expect(isValidDate('2026-02-29')).toBe(false);
    expect(isValidDate('2026-02-31')).toBe(false);
    expect(isValidDate('2026-13-01')).toBe(false);
    expect(isValidDate('11/03/2026')).toBe(false);
  });
  it('moves across year boundaries', () => {
    expect(shiftMonth('2026-01', -1)).toBe('2025-12');
    expect(shiftMonth('2026-12', 1)).toBe('2027-01');
  });
  it('offers the three complete preceding months while keeping this month through today', () => {
    const presets = reportPeriodPresets('2026-11-03');
    expect(presets.map(({ label }) => label)).toEqual(['本月', '上月', '9月', '8月', '近 30 天', '今年']);
    expect(presets.slice(0, 4).map(({ range }) => range)).toEqual([
      { from: '2026-11-01', to: '2026-11-03' }, { from: '2026-10-01', to: '2026-10-31' },
      { from: '2026-09-01', to: '2026-09-30' }, { from: '2026-08-01', to: '2026-08-31' },
    ]);
  });
  it('identifies preceding-year month shortcuts without confusing their year', () => {
    const presets = reportPeriodPresets('2026-01-02');
    expect(presets.map(({ label }) => label)).toEqual(['本月', '上月', '2025年11月', '2025年10月', '近 30 天', '今年']);
    expect(presets[1].range).toEqual({ from: '2025-12-01', to: '2025-12-31' });
    expect(presets[4].range).toEqual({ from: '2025-12-04', to: '2026-01-02' });
  });
  it('includes leap-day entries in the complete previous month', () => {
    expect(reportPeriodPresets('2024-03-01')[1].range).toEqual({ from: '2024-02-01', to: '2024-02-29' });
    expect(reportPeriodPresets('2025-03-01')[1].range).toEqual({ from: '2025-02-01', to: '2025-02-28' });
  });
});

describe('original-currency summary', () => {
  it('never adds currencies and ignores tombstones', () => {
    const base: Transaction = {
      id: crypto.randomUUID(), type: 'expense', amountMinor: 100000, currency: 'HKD',
      categoryId: 'food', note: '', occurredOn: '2026-11-03',
      createdAt: '2026-11-03T04:00:00.000Z', updatedAt: '2026-11-03T04:00:00.000Z', deletedAt: null, schemaVersion: 1,
    };
    const totals = summarizeOriginal([
      base,
      { ...base, id: crypto.randomUUID(), currency: 'CNY', amountMinor: 50000 },
      { ...base, id: crypto.randomUUID(), type: 'income', amountMinor: 200000 },
      { ...base, id: crypto.randomUUID(), amountMinor: 999999, deletedAt: base.updatedAt },
    ]);
    expect(totals.HKD).toEqual({ expense: 100000n, income: 200000n, count: 2 });
    expect(totals.CNY).toEqual({ expense: 50000n, income: 0n, count: 1 });
  });
});
