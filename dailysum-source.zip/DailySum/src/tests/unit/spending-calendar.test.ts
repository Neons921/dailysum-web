import { describe, expect, it } from 'vitest';
import { calendarWeeks, spendingCalendar, spendingCalendarRange } from '../../domain/spendingCalendar';
import { rate, transaction } from './data-fixtures';

describe('spending calendar', () => {
  it('shows 12 months, aligns Monday-first weeks and includes a leap day', () => {
    const range = spendingCalendarRange('2024-02-29');
    expect(range).toEqual({ from: '2023-03-01', to: '2024-02-29' });
    const weeks = calendarWeeks(range);
    expect(weeks[0].slice(0, 3)).toEqual([null, null, '2023-03-01']);
    expect(weeks.flat().filter(Boolean)).toHaveLength(366);
    expect(weeks.at(-1)?.[3]).toBe('2024-02-29');
    expect(weeks.at(-1)?.[4]).toBeNull();
  });

  it('scales converted daily expenses and flags days with incomplete rates', () => {
    const month = '2026-11';
    const rows = [
      transaction({ occurredOn: `${month}-02`, amountMinor: 10000 }),
      transaction({ occurredOn: `${month}-02`, amountMinor: 5000, currency: 'CNY' }),
      transaction({ occurredOn: `${month}-03`, amountMinor: 5000 }),
      transaction({ occurredOn: `${month}-04`, type: 'income', currency: 'CNY', categoryId: 'salary' }),
      transaction({ occurredOn: `${month}-05`, currency: 'CNY' }),
      transaction({ occurredOn: `${month}-06`, deletedAt: '2026-11-06T12:00:00.000Z' }),
      transaction({ occurredOn: '2026-10-01', amountMinor: 2500 }),
      transaction({ occurredOn: '2025-11-30' }),
      transaction({ occurredOn: `${month}-23` }),
    ];
    const calendar = spendingCalendar(spendingCalendarRange(`${month}-22`), rows, 'HKD', [rate({ rateDate: `${month}-02`, sourceDate: `${month}-02` })]);
    expect(calendar.days.get(`${month}-02`)).toMatchObject({ heat: 4, report: { expense: { amount: 15900n, missing: 0 } } });
    expect(calendar.days.get(`${month}-03`)?.heat).toBeLessThan(4);
    expect(calendar.days.get(`${month}-04`)).toMatchObject({ heat: 0, report: { income: { count: 1, missing: 1 } } });
    expect(calendar.days.get(`${month}-05`)).toMatchObject({ heat: 0, report: { expense: { missing: 1 } } });
    expect(calendar.days.has(`${month}-06`)).toBe(false);
    expect(calendar.days.get('2026-10-01')).toMatchObject({ heat: 2, report: { expense: { amount: 2500n } } });
    expect(calendar.days.has('2025-11-30')).toBe(false);
    expect(calendar.days.has(`${month}-23`)).toBe(false);
  });
});
