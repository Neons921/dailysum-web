import { describe, expect, it } from 'vitest';
import { calendarWeeks, spendingCalendar } from '../../domain/spendingCalendar';
import { rate, transaction } from './data-fixtures';

describe('spending calendar', () => {
  it('aligns Monday-first weeks, leap days and months spanning six weeks', () => {
    const february = calendarWeeks('2024-02');
    expect(february[0].slice(0, 4)).toEqual([null, null, null, '2024-02-01']);
    expect(february.flat().filter(Boolean)).toHaveLength(29);
    expect(february.at(-1)?.[3]).toBe('2024-02-29');
    const november = calendarWeeks('2026-11');
    expect(november).toHaveLength(6);
    expect(november.at(-1)?.[0]).toBe('2026-11-30');
  });

  it('scales converted daily expenses and flags days with incomplete rates', () => {
    const month = '2026-11';
    const rows = [
      transaction({ occurredOn: `${month}-02`, amountMinor: 10000 }),
      transaction({ occurredOn: `${month}-02`, amountMinor: 5000, currency: 'CNY' }),
      transaction({ occurredOn: `${month}-03`, amountMinor: 5000 }),
      transaction({ occurredOn: `${month}-04`, type: 'income', currency: 'CNY', categoryId: 'salary' }),
      transaction({ occurredOn: `${month}-05`, currency: 'CNY' }),
      transaction({ occurredOn: `${month}-06`, deletedAt: '2026-11-06T12:00:00.000Z' }),
      transaction({ occurredOn: '2026-10-01' }),
    ];
    const calendar = spendingCalendar(month, rows, 'HKD', [rate({ rateDate: `${month}-02`, sourceDate: `${month}-02` })]);
    expect(calendar.spendingDays).toBe(3);
    expect(calendar.expense).toMatchObject({ amount: 20900n, count: 4, missing: 1 });
    expect(calendar.days.get(`${month}-02`)).toMatchObject({ heat: 4, report: { expense: { amount: 15900n, missing: 0 } } });
    expect(calendar.days.get(`${month}-03`)?.heat).toBeLessThan(4);
    expect(calendar.days.get(`${month}-04`)).toMatchObject({ heat: 0, report: { income: { count: 1, missing: 1 } } });
    expect(calendar.days.get(`${month}-05`)).toMatchObject({ heat: 0, report: { expense: { missing: 1 } } });
    expect(calendar.days.has(`${month}-06`)).toBe(false);
    expect(calendar.days.has('2026-10-01')).toBe(false);
  });
});
