import { describe, expect, it } from 'vitest';
import { calendarWeeks, heatmapBuckets, spendingCalendar, spendingCalendarRange } from '../../domain/spendingCalendar';
import { rate, transaction } from './data-fixtures';

describe('spending calendar', () => {
  it('shows 12 months, aligns Monday-first weeks and includes a leap day', () => {
    const range = spendingCalendarRange('2024-02-29');
    expect(range).toEqual({ from: '2023-03-01', to: '2024-02-29' });
    const weeks = calendarWeeks(range);
    expect(weeks[0].slice(0, 3)).toEqual([null, null, '2023-03-01']);
    expect(weeks.flat().filter(Boolean)).toHaveLength(366);
    expect(weeks.at(-1)?.[3]).toBe('2024-02-29');
    expect(weeks.at(-1)?.[4]).toBeNull();
  });

  it('scales converted daily expenses and flags days with incomplete rates', () => {
    const month = '2026-11';
    const rows = [
      transaction({ occurredOn: `${month}-02`, amountMinor: 10000 }),
      transaction({ occurredOn: `${month}-02`, amountMinor: 5000, currency: 'CNY' }),
      transaction({ occurredOn: `${month}-03`, amountMinor: 5000 }),
      transaction({ occurredOn: `${month}-04`, type: 'income', currency: 'CNY', categoryId: 'salary' }),
      transaction({ occurredOn: `${month}-05`, currency: 'CNY' }),
      transaction({ occurredOn: `${month}-06`, deletedAt: '2026-11-06T12:00:00.000Z' }),
      transaction({ occurredOn: '2026-10-01', amountMinor: 2500 }),
      transaction({ occurredOn: '2025-11-30' }),
      transaction({ occurredOn: `${month}-23` }),
    ];
    const range = spendingCalendarRange(`${month}-22`);
    const calendar = spendingCalendar(range, rows, 'HKD', [rate({ rateDate: `${month}-02`, sourceDate: `${month}-02` })]);
    const daily = heatmapBuckets(calendarWeeks(range), calendar.days, 'day');
    expect(daily.get(`${month}-02`)).toMatchObject({ heat: 4, total: { amount: 15900n, missing: 0 } });
    expect(daily.get(`${month}-03`)?.heat).toBeLessThan(4);
    expect(daily.get(`${month}-04`)).toMatchObject({ heat: 0, total: { count: 0, missing: 0 } });
    expect(daily.get(`${month}-05`)).toMatchObject({ heat: 0, total: { missing: 1 } });
    expect(calendar.days.has(`${month}-06`)).toBe(false);
    expect(daily.get('2026-10-01')).toMatchObject({ heat: 2, total: { amount: 2500n } });
    expect(calendar.days.has('2025-11-30')).toBe(false);
    expect(calendar.days.has(`${month}-23`)).toBe(false);
  });

  it('uses clipped Monday-first weeks and rounds the final weekly and cumulative amount once', () => {
    const range = { from: '2026-11-17', to: '2026-11-24' };
    const weeks = calendarWeeks(range);
    const recordedDates = ['2026-11-17', '2026-11-18'];
    const transactions = [
      ...recordedDates.map((occurredOn) => transaction({ occurredOn, amountMinor: 1, currency: 'CNY' })),
      transaction({ occurredOn: '2026-11-23', amountMinor: 9 }),
      transaction({ occurredOn: '2026-11-24', amountMinor: 1, currency: 'CNY' }),
      transaction({ occurredOn: '2026-11-25', amountMinor: 500 }),
    ];
    const { days } = spendingCalendar(range, transactions, 'HKD', recordedDates.map((date) => rate({ rateDate: date, sourceDate: date, rate: '1.5' })));
    const daily = heatmapBuckets(weeks, days, 'day');
    for (const date of recordedDates) expect(daily.get(date)?.total.amount).toBe(2n);
    const weekly = heatmapBuckets(weeks, days, 'week');
    expect([...weekly.keys()]).toEqual(['2026-11-22', '2026-11-24']);
    expect(weekly.get('2026-11-22')).toMatchObject({ from: '2026-11-17', heat: 4, total: { amount: 3n, missing: 0 } });
    expect(weekly.get('2026-11-24')).toMatchObject({ from: '2026-11-23', heat: 0, total: { missing: 1 } });
    const cumulative = heatmapBuckets(weeks, days, 'cumulative');
    expect(cumulative.get('2026-11-18')).toMatchObject({ from: '2026-11-17', heat: 1, total: { amount: 3n } });
    expect(cumulative.get('2026-11-23')).toMatchObject({ heat: 4, total: { amount: 12n, missing: 0 } });
    expect(cumulative.get('2026-11-24')).toMatchObject({ heat: 0, total: { missing: 1 } });
  });
});
