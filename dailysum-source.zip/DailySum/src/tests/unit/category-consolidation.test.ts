import { afterEach, describe, expect, it } from 'vitest';
import { activeCategories, consolidateCategories, normalizeCategoryTransactions, resolveCategory } from '../../domain/categories';
import { convertCent } from '../../domain/cent';
import { mergeLedger } from '../../domain/merge';
import { canonical, createEnvelope, parseEnvelope, validateData, type LedgerData } from '../../domain/portable';
import { emptyReportRules, evaluateReportRule } from '../../domain/reportFilters';
import { selectReportTransactions } from '../../domain/reports';
import { LedgerDatabase } from '../../storage/db';
import { LedgerRepository } from '../../storage/ledgerRepository';
import { DataRepository } from '../../storage/dataRepository';
import { DataService } from '../../services/dataService';
import { LedgerService } from '../../services/ledgerService';
import { bill, emptyData, transaction } from './data-fixtures';
const databases:LedgerDatabase[]=[];
afterEach(async()=>{for(const db of databases)await db.delete();databases.length=0;});
async function centData():Promise<LedgerData> {
  const current=emptyData();const result=await convertCent({source:'fixture.json',attachments:[],data:{items:[bill({id:'breakfast',categoryId:'breakfast'}),bill({id:'lunch',categoryId:'launch'}),bill({id:'water',categoryId:'water'}),bill({id:'reward',type:'income',categoryId:'custom-reward'})],meta:{baseCurrency:'CNY',categories:[{id:'custom-reward',type:'income',name:'奖励',customName:true}]}}},current);
  return mergeLedger(result.base,current,result.incoming).data;
}
describe('lossless consolidation into the existing thirteen categories',()=>{
  it('merges detailed and custom categories using ancestry without altering any non-category transaction field',async()=>{
    const before=await centData(),result=consolidateCategories(before);expect(activeCategories(result.data.categories)).toHaveLength(13);
    expect(result.data.transactions.map((row)=>row.categoryId).sort()).toEqual(['bonus','food','food','living']);
    for(const row of result.data.transactions){const old=before.transactions.find((item)=>item.id===row.id)!;const strip=({categoryId,categoryHistory,...fields}:typeof row)=>fields;expect(strip(row)).toEqual(strip(old));expect(row.categoryHistory).toEqual([old.categoryId]);}
    expect(result.data.archives).toEqual(before.archives);expect(consolidateCategories(result.data).data).toEqual(result.data);
  });
  it('imports a cleaned backup into the original ledger without per-record conflicts or duplicate visible categories',async()=>{
    const before=await centData(),cleaned=consolidateCategories(before).data;const merged=mergeLedger(null,before,cleaned);
    expect(merged.unresolved).toEqual([]);expect(activeCategories(merged.data.categories)).toHaveLength(13);expect(merged.data.transactions).toEqual(cleaned.transactions);
    expect(validateData(merged.data)).toBeTruthy();
  });
  it('merges new offline records from an old child category into the compact taxonomy',async()=>{
    const before=await centData(),cleaned=consolidateCategories(before).data,old=before.transactions[0];
    const offline={...before,transactions:[...before.transactions,transaction({categoryId:old.categoryId,currency:'CNY'})]};
    const merged=mergeLedger(before,offline,cleaned);expect(merged.unresolved).toEqual([]);expect(activeCategories(merged.data.categories)).toHaveLength(13);expect(merged.data.transactions.at(-1)?.categoryId.startsWith('cent-')).toBe(false);
    const parent=before.categories.find((category)=>category.sourceCategoryId==='food')!;
    const added={id:'cent-offline-fruit',name:'餐饮 / 水果',type:'expense' as const,icon:'food',color:'gray',sortOrder:300,parentId:parent.id,sourceCategoryId:'offline-fruit'};
    const another={...offline,categories:[...offline.categories,added],transactions:[...offline.transactions,transaction({categoryId:added.id})]};
    const next=mergeLedger(before,another,cleaned);expect(next.unresolved).toEqual([]);expect(activeCategories(next.data.categories)).toHaveLength(13);expect(next.data.transactions.find((row)=>row.categoryHistory?.includes(added.id))?.categoryId).toBe('food');
  });
  it('preserves newer local money and note edits during a category-only merge',async()=>{
    const before=await centData(),cleaned=consolidateCategories(before).data,id=before.transactions[0].id;
    const local={...before,transactions:before.transactions.map((row)=>row.id===id?{...row,amountMinor:9012,note:'本地新备注'}:row)};
    const merged=mergeLedger(before,local,cleaned);expect(merged.unresolved).toEqual([]);expect(merged.data.transactions.find((row)=>row.id===id)).toMatchObject({amountMinor:9012,note:'本地新备注'});
  });
  it('keeps legacy include/exclude filters narrow instead of accidentally including or excluding all food',async()=>{
    const before=await centData(),breakfast=before.categories.find((category)=>category.sourceCategoryId==='breakfast')!,cleaned=consolidateCategories(before).data;
    const include={...emptyReportRules(),includeCategoryIds:[breakfast.id]};const exclude={...emptyReportRules(),excludeCategoryIds:[breakfast.id]};
    for(const row of before.transactions){const converted=cleaned.transactions.find((item)=>item.id===row.id)!;expect(evaluateReportRule(converted,include,new Map()).state).toBe(evaluateReportRule(row,include,new Map()).state);expect(evaluateReportRule(converted,exclude,new Map()).state).toBe(evaluateReportRule(row,exclude,new Map()).state);}
    expect(cleaned.transactions.filter((row)=>evaluateReportRule(row,include,new Map()).state==='match')).toHaveLength(1);
  });
  it('retains consolidated categories when importing Cent again, including a new custom child',async()=>{
    const cleaned=consolidateCategories(await centData()).data;
    const result=await convertCent({source:'fixture.json',attachments:[],data:{items:[bill({id:'new-child',categoryId:'fruit'}),bill({id:'new-salary',type:'income',categoryId:'wage'})],meta:{baseCurrency:'CNY',categories:[{id:'fruit',name:'水果',customName:true,parent:'food',type:'expense'}]}}},cleaned);
    const merged=mergeLedger(result.base,cleaned,result.incoming);expect(merged.unresolved).toEqual([]);expect(activeCategories(merged.data.categories)).toHaveLength(13);expect(merged.data.transactions.some((row)=>row.categoryId==='salary')).toBe(true);
  });
  it('can still search by an old detailed category name after merging it',async()=>{
    const cleaned=consolidateCategories(await centData()).data;
    const selected=selectReportTransactions(cleaned.transactions,{from:'2026-11-01',to:'2026-11-30',type:'',currency:'',categoryId:'',query:'早餐'},cleaned.categories,[]);
    expect(selected.matched).toHaveLength(1);expect(selected.matched[0].categoryId).toBe('food');
  });
  it('rejects cyclic and cross-type merge targets instead of corrupting category references',()=>{
    const data=emptyData();expect(()=>validateData({...data,categories:[...data.categories,{...data.categories[0],id:'bad',mergedIntoId:'salary'}]})).toThrow('收支类型');
    const categories=[{...data.categories[0],id:'a',mergedIntoId:'b'},{...data.categories[0],id:'b',mergedIntoId:'a'}];expect(()=>resolveCategory('a',new Map(categories.map((row)=>[row.id,row])))).toThrow('循环');
  });
  it('roundtrips the new history and merged category fields in a checksummed native envelope',async()=>{
    const cleaned=consolidateCategories(await centData()).data;const envelope=await createEnvelope(cleaned,crypto.randomUUID());expect((await parseEnvelope(JSON.parse(JSON.stringify(envelope)))).data).toEqual(validateData(cleaned));
  });
  it('saves, edits and undoes consolidated records and can restore the pre-consolidation checkpoint',async()=>{
    const db=new LedgerDatabase(`categories-${crypto.randomUUID()}`);databases.push(db);const ledger=new LedgerService(new LedgerRepository(db));await ledger.initialize();const repository=new DataRepository(db),service=new DataService(repository),before=await centData();
    await db.categories.bulkPut(before.categories);await db.transactions.bulkPut(before.transactions);
    for(const archive of before.archives)await db.table('settings').put({id:`archive:${archive.id}`,archive});
    const original=canonical(await repository.read()),envelope=await createEnvelope(consolidateCategories(before).data,crypto.randomUUID());
    const plan=await service.importPlan({data:JSON.parse(JSON.stringify(envelope)),source:'cleaned.json',attachments:[]});await service.commit(plan,{});
    const checkpoint=(await repository.checkpoints())[0],saved=(await repository.read()).transactions[0];
    expect(activeCategories((await repository.read()).categories)).toHaveLength(13);
    const edit=await ledger.save(saved.id,{...saved,note:'改备注'},saved);expect(edit.change.after.categoryHistory).toEqual(saved.categoryHistory);await ledger.undo(edit.change);
    const row=(await repository.read()).transactions.find((item)=>item.id===saved.id)!;await ledger.save(row.id,{...row,categoryId:row.type==='income'?'salary':'transport'},row);
    expect((await repository.read()).transactions.find((item)=>item.id===row.id)?.categoryHistory).toBeUndefined();
    await repository.restore(checkpoint);expect(activeCategories((await repository.read()).categories)).toHaveLength(before.categories.length);expect((await repository.read()).transactions.map((item)=>item.categoryId)).toEqual(before.transactions.map((item)=>item.categoryId));expect(original.length).toBeGreaterThan(0);
  });
  it('normalizes an edit submitted from a stale editor that still uses an old category ID',async()=>{
    const cleaned=consolidateCategories(await centData()).data,db=new LedgerDatabase(`stale-category-${crypto.randomUUID()}`);databases.push(db);
    const service=new LedgerService(new LedgerRepository(db));await service.initialize();await db.categories.bulkPut(cleaned.categories);
    const old=cleaned.categories.find((category)=>category.sourceCategoryId==='breakfast')!;
    const saved=await service.save(crypto.randomUUID(),{type:'expense',amountMinor:100,currency:'CNY',categoryId:old.id,note:'',occurredOn:'2026-11-03'});expect(saved.change.after).toMatchObject({categoryId:'food',categoryHistory:[old.id]});
  });
  it('leaves already compact ordinary records untouched when no merge applies',()=>{
    const data=emptyData(),row=transaction();expect(normalizeCategoryTransactions([row],data.categories)[0]).toBe(row);
  });
  it('normalizes an undo captured before categories were merged',async()=>{
    const data=await centData(),db=new LedgerDatabase(`undo-category-${crypto.randomUUID()}`);databases.push(db);const service=new LedgerService(new LedgerRepository(db));await service.initialize();await db.categories.bulkPut(data.categories);await db.transactions.bulkPut(data.transactions);
    const old=data.transactions.find((row)=>row.type==='expense')!,change=await service.save(old.id,{...old,note:'合并前编辑'},old);
    const compact=consolidateCategories({...data,transactions:[change.change.after]}).data;await db.categories.bulkPut(compact.categories);await db.transactions.bulkPut(compact.transactions);
    const restored=await service.undo(change.change);expect(restored.categoryId.startsWith('cent-')).toBe(false);expect(restored.categoryHistory).toContain(old.categoryId);expect(restored.note).toBe(old.note);
  });
});
