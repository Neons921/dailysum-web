import { describe, expect, it } from 'vitest';
import { monotoneLinePath } from '../../dime/chartGeometry';

describe('trend interpolation preserves measured ranges', () => {
  it.each([
    [[0, 100], [20, 0], [40, 100], [60, 100]],
    [[0, 0], [10, 1], [20, 500], [30, 501], [40, 0]],
    [[0, 0], [10, 0], [20, 0]],
  ] as [number, number][][])('does not introduce peaks, valleys or negative amounts: %j', (...points) => {
    const path = monotoneLinePath(points);
    const curves = path.split(' C ').slice(1);
    expect(curves).toHaveLength(points.length - 1);
    curves.forEach((curve, index) => {
      const [x1, y1, x2, y2, x3, y3] = curve.split(/[ ,]+/).map(Number);
      const [x0, y0] = points[index];
      expect([x3, y3]).toEqual(points[index + 1]);
      for (let sample = 0; sample <= 100; sample++) {
        const t = sample / 100, u = 1 - t;
        const x = u ** 3 * x0 + 3 * u ** 2 * t * x1 + 3 * u * t ** 2 * x2 + t ** 3 * x3;
        const y = u ** 3 * y0 + 3 * u ** 2 * t * y1 + 3 * u * t ** 2 * y2 + t ** 3 * y3;
        expect(x).toBeGreaterThanOrEqual(x0 - 1e-8);
        expect(x).toBeLessThanOrEqual(x3 + 1e-8);
        expect(y).toBeGreaterThanOrEqual(Math.min(y0, y3) - 1e-8);
        expect(y).toBeLessThanOrEqual(Math.max(y0, y3) + 1e-8);
      }
    });
  });
  it('handles empty and single-period charts without invalid geometry', () => {
    expect(monotoneLinePath([])).toBe('');
    expect(monotoneLinePath([[120, 80]])).toBe('M 120,80');
  });
});
