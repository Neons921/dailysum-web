import { DEFAULT_CATEGORIES, DEFAULT_SETTINGS, type FxRate, type Transaction } from '../../domain/models';
import { EMPTY_FILTER_PREFERENCES } from '../../domain/reportFilters';
import type { LedgerData } from '../../domain/portable';
export const day='2026-11-03',now='2026-11-03T12:00:00.000Z';
export const emptyData=():LedgerData=>structuredClone({transactions:[],categories:DEFAULT_CATEGORIES,settings:DEFAULT_SETTINGS,fxRates:[],filterPreferences:EMPTY_FILTER_PREFERENCES,archives:[]});
export const transaction=(patch:Partial<Transaction>={}):Transaction=>({id:crypto.randomUUID(),type:'expense',amountMinor:2500,currency:'HKD',categoryId:'food',note:'午餐',occurredOn:day,createdAt:now,updatedAt:now,deletedAt:null,schemaVersion:1,...patch});
export const rate=(patch:Partial<FxRate>={}):FxRate=>({id:crypto.randomUUID(),rateDate:day,sourceDate:day,baseCurrency:'CNY',quoteCurrency:'HKD',rate:'1.18',source:'手动汇率',fetchedAt:now,isManual:true,revision:1,...patch});
export const bill=(patch:Record<string,unknown>={})=>({id:'cent-record-1',type:'expense',categoryId:'launch',creatorId:123,comment:'午餐',amount:2560000,time:Date.parse('2026-11-02T16:10:00Z'),__create_at:Date.parse(now),__update_at:Date.parse(now),...patch});
