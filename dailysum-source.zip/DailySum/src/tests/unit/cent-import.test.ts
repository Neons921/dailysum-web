import { describe, expect, it } from 'vitest';
import { strToU8, zipSync } from 'fflate';
import { convertCent, parseJson, readCentZip, replayCent } from '../../domain/cent';
import { mergeLedger } from '../../domain/merge';
import { draftSignature, validateData } from '../../domain/portable';
import { bill, emptyData, now } from './data-fixtures';
const payload=(items:unknown[],meta:Record<string,unknown>={baseCurrency:'CNY'})=>({data:{items,meta},source:'cent-backup.json',attachments:[]});

describe('Cent interchange, independently implemented from documented source formats',()=>{
  it('reads original foreign amount at 10000:1, Hong Kong civil dates, long notes and child categories',async()=>{
    const raw=bill({amount:2300000,currency:{base:'CNY',target:'HKD',amount:2560000},comment:'长备注'.repeat(100),images:['assets/a.png'],location:{latitude:22.3,longitude:114.1},tagIds:['tag1'],extra:{scheduledId:'x'}});
    const result=await convertCent(payload([raw],{baseCurrency:'CNY',tags:[{id:'tag1',name:'工作'}]}),emptyData());
    expect(result.issues).toEqual([]);expect(result.incoming.transactions[0]).toMatchObject({currency:'HKD',amountMinor:25600,occurredOn:'2026-11-03',note:raw.comment});
    expect(result.incoming.categories.find((row)=>row.id===result.incoming.transactions[0].categoryId)?.name).toBe('餐饮 / 午餐');
    expect((result.incoming.archives[0].data as {items:unknown[]}).items[0]).toEqual(raw);
    expect(validateData(mergeLedger(result.base,emptyData(),result.incoming).data).transactions).toHaveLength(1);
  });
  it('rounds half up only once, warns, and retains the exact 10000-scale source',async()=>{
    const result=await convertCent(payload([bill({amount:123450}),bill({id:'other',amount:123449})]),emptyData());
    expect(result.incoming.transactions.map((row)=>row.amountMinor)).toEqual([1235,1234]);expect(result.rounded).toBe(2);
    expect(result.warnings.join(' ')).toContain('四舍五入');expect(result.incoming.transactions[0].origin?.amount10000).toBe('123450');
  });
  it('preserves custom category names, original IDs and metadata instead of flattening into defaults',async()=>{
    const result=await convertCent(payload([bill({categoryId:'my-power'})],{baseCurrency:'CNY',categories:[{id:'my-power',name:'水电费',customName:true,type:'expense',parent:'housing'}]}),emptyData());
    const category=result.incoming.categories.find((row)=>row.sourceCategoryId==='my-power');expect(category).toMatchObject({name:'居住 / 水电费',icon:'living'});expect(category?.parentId).toBeTruthy();
  });
  it('lists unsupported currencies and invalid rows explicitly; the source archive keeps them intact',async()=>{
    const rows=[bill(),bill({id:'usd',currency:{target:'USD',amount:10000}}),bill({id:'bad',time:'wrong'}),bill({id:'zero',amount:1}),bill({id:'note',comment:'x'.repeat(10001)})];
    const result=await convertCent(payload(rows),emptyData());expect(result.issues).toHaveLength(4);expect(result.incoming.transactions).toHaveLength(1);expect((result.incoming.archives[0].data as {items:unknown[]}).items).toHaveLength(5);
  });
  it('uses stable IDs, keeps equal-value separate bills and never resurrects unchanged locally deleted imports',async()=>{
    const input=payload([bill(),bill({id:'cent-record-2'})]);const initial=await convertCent(input,emptyData());
    const current=mergeLedger(initial.base,emptyData(),initial.incoming).data;expect(new Set(current.transactions.map((row)=>row.id)).size).toBe(2);
    current.transactions[0]={...current.transactions[0],deletedAt:now,updatedAt:now};
    const again=await convertCent(input,current);const merged=mergeLedger(again.base,current,again.incoming);
    expect(again.duplicates).toBe(2);expect(merged.conflicts).toEqual([]);expect(merged.data.transactions.find((row)=>row.id===current.transactions[0].id)?.deletedAt).toBe(now);
  });
  it('updates source edits only if local content is unchanged; concurrent local edits require a choice',async()=>{
    const initial=await convertCent(payload([bill()]),emptyData());const current=mergeLedger(initial.base,emptyData(),initial.incoming).data;
    const remote=await convertCent(payload([bill({amount:3000000})]),current);expect(mergeLedger(remote.base,current,remote.incoming).data.transactions[0].amountMinor).toBe(30000);
    current.transactions[0]={...current.transactions[0],note:'本地另加备注'};
    const conflict=await convertCent(payload([bill({amount:3000000})]),current);const merged=mergeLedger(conflict.base,current,conflict.incoming);
    expect(merged.unresolved).toHaveLength(1);expect(merged.unresolved[0].kind).toBe('transaction');
    expect(draftSignature(current.transactions[0])).not.toBe(current.transactions[0].origin?.importedDraft);
  });
  it('replays numeric chunks, stable timestamp ties, updates, deletions, and metadata patches',()=>{
    const update=(id:string,amount:number,timestamp:number)=>({id:crypto.randomUUID(),type:'update',timestamp,value:bill({id,amount})});
    const result=replayCent({$$patch:true,baseCurrency:'HKD'},[
      {path:'ledger-10.json',actions:[update('a',30000,3)]},
      {path:'ledger-2.json',actions:[update('a',20000,3),{id:'d',type:'delete',value:'gone',timestamp:4}]},
      {path:'ledger-1.json',actions:[update('a',10000,2),update('gone',10000,1),{id:'m',type:'meta',timestamp:1,metaValue:{tags:[{name:'测试'}]}}]},
    ]);
    const rows=result.items as Record<string,unknown>[];expect(rows.find((row)=>row.id==='a')?.amount).toBe(30000);expect(rows.find((row)=>row.id==='gone')?.__delete_at).toBe(4);expect(result.meta).toEqual({baseCurrency:'HKD',tags:[{name:'测试'}]});
    expect(()=>replayCent({},[{path:'ledger-0.json',actions:[{type:'unknown',timestamp:1}]}])).toThrow('无法识别');
  });
  it('reads a Cent ZIP and archives attachments without extracting paths on disk',()=>{
    const result=readCentZip(zipSync({'backup.json':strToU8(JSON.stringify({items:[bill()],meta:{baseCurrency:'CNY'}})),'assets/image.png':new Uint8Array([1,2,3,4])}),'book.cent.zip');
    expect(result.attachments[0]).toMatchObject({path:'assets/image.png',size:4,content:'AQIDBA=='});
    expect(()=>readCentZip(zipSync({'../bad':new Uint8Array([1])}),'bad.zip')).toThrow('路径');
    expect(()=>readCentZip(zipSync({'other.json':strToU8('{}')}),'bad.zip')).toThrow('无法保留');
    expect(()=>readCentZip(zipSync({'backup.json':new Uint8Array(29*1024*1024)}),'large.zip')).toThrow('28 MB');
    expect(()=>parseJson('{"__proto__":{"polluted":true}}')).toThrow('不支持');
  });
  it('reports a missing base currency and respects the explicitly selected legacy fallback',async()=>{
    const result=await convertCent(payload([bill()],{}),emptyData(),'HKD');expect(result.incoming.transactions[0].currency).toBe('HKD');expect(result.warnings[0]).toContain('HKD');
  });
  it('localizes default category translation keys and keeps category ordering stable across export order',async()=>{
    const a=bill(),b=bill({id:'b',categoryId:'electricity'}),meta={baseCurrency:'CNY',categories:[{id:'launch',name:'launch',parent:'food'},{id:'food',name:'Food'}]};
    const first=await convertCent(payload([a,b],meta),emptyData()),second=await convertCent(payload([b,a],meta),emptyData());
    expect(first.incoming.categories.find((row)=>row.sourceCategoryId==='launch')?.name).toBe('餐饮 / 午餐');
    for(const category of first.incoming.categories)expect(second.incoming.categories.find((row)=>row.id===category.id)).toEqual(category);
  });
  it('honors deletes from compacted journals even when the original update was removed',async()=>{
    const initial=await convertCent(payload([bill()]),emptyData());const current=mergeLedger(initial.base,emptyData(),initial.incoming).data;
    const data=replayCent({baseCurrency:'CNY'},[{path:'ledger-0.json',actions:[{id:'delete-only',type:'delete',timestamp:Date.parse(now),value:'cent-record-1'}]}]);
    const next=await convertCent({data,source:'GitHub',attachments:[]},current);const merged=mergeLedger(next.base,current,next.incoming);expect(merged.unresolved).toEqual([]);expect(merged.data.transactions[0].deletedAt).toBe(now);
    current.transactions[0].note='本地修改';const conflict=await convertCent({data,source:'GitHub',attachments:[]},current);expect(mergeLedger(conflict.base,current,conflict.incoming).unresolved).toHaveLength(1);
  });
});
