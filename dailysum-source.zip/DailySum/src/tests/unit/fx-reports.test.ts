import { afterEach, describe, expect, it, vi } from 'vitest';
import { DEFAULT_CATEGORIES, type FxRate, type Transaction } from '../../domain/models';
import { convertedMinor, latestRates, missingRateDates, rateInputSchema, roundMinor } from '../../domain/fx';
import { categoryTotals, changePercent, filterTransactions, summarizeConverted, trendPoints, type ReportFilters } from '../../domain/reports';
import { monthRange, offsetDay, previousRange, rangeDays } from '../../domain/dates';
import { fetchDailyRates, FxService } from '../../services/fxService';
import { LedgerDatabase } from '../../storage/db';
import { FxRepository } from '../../storage/fxRepository';

const date = '2025-11-03';
function transaction(amountMinor: number, currency: 'HKD' | 'CNY', overrides: Partial<Transaction> = {}): Transaction {
  return { id: crypto.randomUUID(), type: 'expense', amountMinor, currency, categoryId: 'food', note: '午餐', occurredOn: date,
    createdAt: `${date}T00:00:00.000Z`, updatedAt: `${date}T00:00:00.000Z`, deletedAt: null, schemaVersion: 1, ...overrides };
}
function rate(value = '1.18', day = date, revision = 1): FxRate {
  return { id: crypto.randomUUID(), rateDate: day, sourceDate: day, baseCurrency: 'CNY', quoteCurrency: 'HKD', rate: value,
    source: 'test', fetchedAt: `${date}T12:00:00.000Z`, isManual: false, revision };
}
const rows = [transaction(100000, 'HKD'), transaction(50000, 'CNY')];
const filters: ReportFilters = { from: date, to: date, type: '', categoryId: '', currency: '', query: '' };

describe('daily conversion and report precision', () => {
  it('converts both directions, without changing original transactions', () => {
    const original = JSON.stringify(rows);
    expect(summarizeConverted(rows, 'HKD', [rate()]).expense.amount).toBe(159000n);
    expect(summarizeConverted(rows, 'CNY', [rate()]).expense.amount).toBe(134746n);
    expect(JSON.stringify(rows)).toBe(original);
  });
  it('uses each transaction date instead of a current / average rate', () => {
    const otherDay = offsetDay(date, -1);
    const data = [transaction(10000, 'CNY'), transaction(10000, 'CNY', { occurredOn: otherDay })];
    expect(summarizeConverted(data, 'HKD', [rate('1.2'), rate('1.1', otherDay)]).expense.amount).toBe(23000n);
  });
  it('aggregates exact decimal minor units before rounding, not rounded rows', () => {
    const data = [transaction(1, 'CNY'), transaction(1, 'CNY'), transaction(1, 'CNY')];
    const rates = [rate('1.18')];
    expect(data.map((row) => roundMinor(convertedMinor(row, 'HKD', latestRates(rates))!))).toEqual([1n, 1n, 1n]);
    expect(summarizeConverted(data, 'HKD', rates).expense.amount).toBe(4n);
  });
  it('uses decimal half-up and keeps displayed income minus expense equal to net', () => {
    const data = [transaction(1, 'CNY'), transaction(2, 'CNY', { type: 'income', categoryId: 'salary' })];
    const report = summarizeConverted(data, 'HKD', [rate('1.5')]);
    expect(report.expense.amount).toBe(2n);
    expect(report.income.amount).toBe(3n);
    expect(report.net).toBe(1n);
  });
  it('uses bigint totals above Number.MAX_SAFE_INTEGER', () => {
    const data = Array.from({ length: 1000 }, () => transaction(9_999_999_999, 'CNY'));
    expect(summarizeConverted(data, 'HKD', [rate('999')]).expense.amount).toBe(9_989_999_999_001_000n);
  });
  it('marks only affected types incomplete and never assumes a 1:1 rate', () => {
    const report = summarizeConverted([...rows, transaction(20000, 'HKD', { type: 'income', categoryId: 'salary' })], 'HKD', []);
    expect(report.expense.missing).toBe(1); expect(report.expense.amount).toBe(100000n);
    expect(report.income.missing).toBe(0); expect(report.income.amount).toBe(20000n); expect(report.net).toBeNull();
    expect(missingRateDates(rows, 'HKD', [])).toEqual([date]);
    expect(summarizeConverted([rows[0]], 'HKD', []).missing).toBe(0);
  });
  it('ignores deleted rows and selects only the latest valid rate revision', () => {
    const records = [rate('1.1', date, 1), rate('1.2', date, 2), rate('-1', date, 3)];
    const data = [transaction(10000, 'CNY'), transaction(99999, 'HKD', { deletedAt: `${date}T00:00:00Z` })];
    expect(summarizeConverted(data, 'HKD', records).expense.amount).toBe(12000n);
    expect(latestRates(records).get(date)?.revision).toBe(2);
  });
  it.each(['0', '-1', 'NaN', 'Infinity', '1e2', '1000.1', '1,18', ' 1.18 '])('rejects invalid saved ratio %s', (value) => {
    expect(rateInputSchema.safeParse(value).success).toBe(false);
  });
});

describe('shared analytics scope', () => {
  it('combines date, type, category, original currency and search filters', () => {
    const data = [...rows, transaction(20000, 'CNY', { categoryId: 'shopping', note: '书籍' }), transaction(20000, 'CNY', { occurredOn: offsetDay(date, -1) })];
    const selected = filterTransactions(data, { ...filters, currency: 'CNY', type: 'expense', categoryId: 'shopping', query: '书' }, DEFAULT_CATEGORIES);
    expect(selected).toHaveLength(1); expect(selected[0].note).toBe('书籍');
    expect(filterTransactions(data, { ...filters, query: '500.00' }, DEFAULT_CATEGORIES)).toEqual([rows[1]]);
  });
  it('uses the same converted inputs for cards, category breakdown and trend', () => {
    const data = [...rows, transaction(20000, 'CNY', { categoryId: 'shopping' })], records = [rate()];
    const report = summarizeConverted(data, 'HKD', records);
    const categories = categoryTotals(data, DEFAULT_CATEGORIES, 'expense', 'HKD', records);
    const points = trendPoints(data, filters, 'day', 'HKD', records);
    expect(categories.reduce((sum, row) => sum + row.total.amount, 0n)).toBe(report.expense.amount);
    expect(categories.reduce((sum, row) => sum + row.share, 0)).toBeCloseTo(1, 12);
    expect(points[0].report.expense.amount).toBe(report.expense.amount);
  });
  it('fills empty buckets and uses calendar weeks and months across years', () => {
    const range = { from: '2025-12-30', to: '2026-01-07' };
    expect(trendPoints([], range, 'day', 'CNY', [])).toHaveLength(9);
    expect(trendPoints([], range, 'week', 'CNY', []).map(({ from, to }) => [from, to])).toEqual([['2025-12-30', '2026-01-04'], ['2026-01-05', '2026-01-07']]);
    expect(trendPoints([], range, 'month', 'CNY', []).map(({ from, to }) => [from, to])).toEqual([['2025-12-30', '2025-12-31'], ['2026-01-01', '2026-01-07']]);
    expect(trendPoints([], { from: '2000-01-01', to: '2026-11-03' }, 'day', 'CNY', [])).toEqual([]);
  });
  it('uses inclusive civil dates, leap years and an equal-length previous period', () => {
    expect(monthRange('2024-02', '2026-11-03')).toEqual({ from: '2024-02-01', to: '2024-02-29' });
    expect(monthRange('2026-11', '2026-11-03')).toEqual({ from: '2026-11-01', to: '2026-11-03' });
    const range = { from: '2026-11-01', to: '2026-11-03' };
    expect(previousRange(range)).toEqual({ from: '2026-10-29', to: '2026-10-31' });
    expect(rangeDays(previousRange(range))).toBe(3);
  });
  it('does not invent a percentage when the baseline is zero or incomplete', () => {
    const current = summarizeConverted(rows, 'HKD', [rate()]).expense;
    expect(changePercent(current, summarizeConverted([], 'HKD', []).expense)).toBeNull();
    expect(changePercent(current, summarizeConverted(rows, 'HKD', []).expense)).toBeNull();
    expect(changePercent(current, current)).toBe('+0.0%');
  });
});

const quotes = [
  { date: '2025-10-31', base: 'EUR', quote: 'CNY', rate: 8.222 }, { date: '2025-10-31', base: 'EUR', quote: 'HKD', rate: 8.9787 },
  { date, base: 'EUR', quote: 'CNY', rate: 8.1987 }, { date, base: 'EUR', quote: 'HKD', rate: 8.9501 },
];
const fetchJson = (data: unknown) => vi.fn<typeof fetch>().mockImplementation(async () => new Response(JSON.stringify(data), { status: 200 }));
afterEach(() => { vi.restoreAllMocks(); vi.useRealTimers(); });
describe('verified provider and cache', () => {
  it('derives unrounded same-date EUR cross rates and records weekend provenance', async () => {
    const fetcher = fetchJson(quotes);
    const rates = await fetchDailyRates(['2025-11-02', date], fetcher, date);
    expect(rates[0]).toMatchObject({ rateDate: '2025-11-02', sourceDate: '2025-10-31', sourceRates: { EUR_CNY: '8.222', EUR_HKD: '8.9787' } });
    expect(rates[1].rate).not.toBe('1.0916');
    expect(rates[1].rate).toMatch(/^1\.091648676/);
    const url = new URL(String(fetcher.mock.calls[0][0]));
    expect(url.pathname).toBe('/v2/providers/ecb/rates');
    expect([...url.searchParams.keys()].sort()).toEqual(['base', 'from', 'quotes', 'to']);
  });
  it('never uses future quotes, unmatched pairs, or a quote older than seven days', async () => {
    const fetcher = fetchJson([quotes[0]]);
    expect(await fetchDailyRates([date], fetcher, date)).toEqual([]);
    const futureFetcher = fetchJson(quotes);
    expect(await fetchDailyRates(['2030-01-01'], futureFetcher, date)).toEqual([]);
    expect(futureFetcher).not.toHaveBeenCalled();
    const oldFetcher = fetchJson(quotes.slice(0, 2));
    await expect(fetchDailyRates(['2025-11-10'], oldFetcher, '2025-11-10')).rejects.toThrow('区间外');
  });
  it.each([
    [{ ...quotes[0], rate: -1 }], [{ ...quotes[0], rate: 0 }], [{ ...quotes[0], quote: 'USD' }],
    [{ ...quotes[0], date: '2025-02-30' }], { error: 'invalid' },
    [quotes[0], { ...quotes[0], rate: 9 }],
  ])('rejects unverifiable provider payload %j', async (payload) => {
    await expect(fetchDailyRates([date], fetchJson(payload), date)).rejects.toThrow();
  });
  it('returns a clear timeout instead of blocking local operations', async () => {
    vi.useFakeTimers();
    const fetcher = vi.fn<typeof fetch>().mockImplementation((_url, options) => new Promise((_resolve, reject) => {
      options?.signal?.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')));
    }));
    const task = expect(fetchDailyRates([date], fetcher, date)).rejects.toThrow('超时');
    await vi.advanceTimersByTimeAsync(8000);
    await task;
  });
  it('freezes automatic history, retains explicit revisions and rejects stale writes', async () => {
    const db = new LedgerDatabase(`fx-${crypto.randomUUID()}`), repository = new FxRepository(db);
    try {
      await repository.addAutomatic([rate('1.1')]);
      await repository.addAutomatic([rate('1.9')]);
      expect(latestRates(await repository.list()).get(date)?.rate).toBe('1.1');
      const service = new FxService(repository, fetchJson(quotes));
      await service.saveManual(date, '1.2', 1);
      expect(await db.fxRates.count()).toBe(2);
      expect(latestRates(await repository.list()).get(date)).toMatchObject({ rate: '1.2', isManual: true, revision: 2 });
      await expect(service.saveManual(date, '1.3', 1)).rejects.toThrow('其他窗口');
      expect(await db.fxRates.count()).toBe(2);
    } finally { await db.delete(); }
  });
  it('deduplicates concurrent requests, then works from cache with no network', async () => {
    const db = new LedgerDatabase(`fx-${crypto.randomUUID()}`), repository = new FxRepository(db), fetcher = fetchJson(quotes);
    try {
      const service = new FxService(repository, fetcher);
      await Promise.all([service.ensure([date]), service.ensure([date])]);
      expect(fetcher).toHaveBeenCalledTimes(1);
      const offline = vi.fn<typeof fetch>().mockRejectedValue(new TypeError('offline'));
      expect(await new FxService(repository, offline).ensure([date])).toHaveLength(1);
      expect(offline).not.toHaveBeenCalled();
      await new FxService(repository, fetchJson(quotes.slice(0, 2))).ensure(['2025-11-02'], false);
      expect(await db.fxRates.count()).toBe(1);
    } finally { await db.delete(); }
  });
});
