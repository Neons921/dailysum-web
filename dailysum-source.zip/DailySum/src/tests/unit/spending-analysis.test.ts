import { describe, expect, it } from 'vitest';
import type { FxRate, Transaction } from '../../domain/models';
import { spendingAnalysis, spendingPeriods, spendingRows } from '../../domain/spendingAnalysis';

const today = '2025-11-03';
const timestamp = `${today}T12:00:00.000Z`;
const fx: FxRate = {
  id: 'analysis-test-rate', rateDate: today, sourceDate: today, baseCurrency: 'CNY', quoteCurrency: 'HKD',
  rate: '1.18', source: 'test', fetchedAt: timestamp, isManual: false, revision: 1,
};
function expense(amountMinor: number, overrides: Partial<Transaction> = {}): Transaction {
  return { id: crypto.randomUUID(), type: 'expense', amountMinor, currency: 'HKD', categoryId: 'food', note: '',
    occurredOn: today, createdAt: timestamp, updatedAt: timestamp, deletedAt: null, schemaVersion: 1, ...overrides };
}

describe('monthly spending analysis', () => {
  it('caps the comparison to the previous calendar month, including across a year boundary', () => {
    expect(spendingPeriods('2024-03', '2024-03-31').previous).toEqual({ from: '2024-02-01', to: '2024-02-29' });
    expect(spendingPeriods('2026-01', '2026-01-04').previous).toEqual({ from: '2025-12-01', to: '2025-12-04' });
  });

  it('compares entire historical months across a year boundary', () => {
    const periods = spendingPeriods('2026-01', '2026-02-03');
    expect(periods).toEqual({ current: { from: '2026-01-01', to: '2026-01-31' },
      previous: { from: '2025-12-01', to: '2025-12-31' }, monthToDate: false });
    const current = [600, 500, 400, 300, 200, 100].map((amount) => expense(amount, { occurredOn: '2026-01-31' }));
    const previous = expense(1800, { occurredOn: '2025-12-31', categoryId: 'transport' });
    const data = [...current, previous];
    const analysis = spendingAnalysis(spendingRows(data, periods.current), spendingRows(data, periods.previous), 'HKD', []);
    expect(analysis.largest.map(({ amount }) => amount)).toEqual([600n, 500n, 400n, 300n, 200n]);
    expect(analysis.large.current.amount - analysis.large.previous.amount).toBe(200n);
    expect(analysis.routine.current.amount - analysis.routine.previous.amount).toBe(300n);
  });

  it('ranks by converted amount and compares routine expenses over the same dates', () => {
    const periods = spendingPeriods(today.slice(0, 7), today);
    const food = expense(1100, { currency: 'CNY' });
    const data = [food, expense(1200, { categoryId: 'transport' }), expense(1500, { categoryId: 'shopping' }),
      expense(900, { occurredOn: '2025-10-02' }), expense(9000, { occurredOn: '2025-10-04' }),
      expense(100000, { type: 'income' }), expense(100000, { deletedAt: timestamp }), expense(100000, { occurredOn: '2025-11-04' })];
    const current = spendingRows(data, periods.current), previous = spendingRows(data, periods.previous);
    const analysis = spendingAnalysis(current, previous, 'HKD', [fx]);
    expect(analysis.total.current.amount).toBe(3998n);
    expect(analysis.total.previous.amount).toBe(900n);
    expect(analysis.routine.current.amount).toBe(2498n);
    expect(analysis.largest[1]).toEqual({ transaction: food, amount: 1298n });
    expect(analysis.categories[1].previous.count).toBe(0);
    const incomplete = spendingAnalysis(current, previous, 'HKD', []);
    expect(incomplete.largest).toEqual([]);
    expect(incomplete.large.current.missing).toBe(1);
    expect(incomplete.total.current.missing).toBe(1);
    expect(incomplete.categories[1].current.missing).toBe(0);
  });
});
