import { expect, test } from '@playwright/test';
import { hongKongToday, offsetDay, shiftMonth } from '../../domain/dates';
import { createEnvelope } from '../../domain/portable';
import { emptyData, transaction } from '../unit/data-fixtures';
import { mockFx } from './fx-fixture';

test('analysis heatmap changes months and saves a converted expense on the selected day @smoke', async ({ page }) => {
  await mockFx(page);
  await page.goto('/#/calendar');
  await expect(page).toHaveURL(/#\/analysis$/);
  await expect(page.getByRole('heading', { name: '消费分析' })).toBeVisible();
  await expect(page.getByRole('link', { name: '日历', exact: true })).toHaveCount(0);
  const calendar = page.getByRole('grid', { name: /每日支出热图/ });
  const today = hongKongToday();
  const month = shiftMonth(today.slice(0, 7), -1);
  const date = `${month}-04`;
  await page.getByRole('button', { name: '上个月', exact: true }).click();
  const day = (value: string) => calendar.locator(`button[data-date="${value}"]`);
  await day(`${month}-03`).press('ArrowDown');
  await expect(day(date)).toBeFocused();
  await day(date).press('Enter');
  const detail = page.getByRole('dialog', { name: `${month.slice(0, 4)}年${Number(month.slice(5))}月4日`, exact: true });
  await expect(detail).toContainText('当天暂无记录');
  await detail.getByRole('button', { name: '在所选日期记一笔' }).click();
  const editor = page.getByRole('dialog', { name: '记一笔', exact: true });
  await expect(editor.locator('#occurredOn')).toHaveValue(date);
  await editor.getByRole('group', { name: '记账币种' }).getByRole('button', { name: /人民币/ }).click();
  await editor.getByLabel('金额', { exact: true }).fill('50');
  await editor.getByRole('button', { name: /^保存/ }).click();
  await expect(editor).not.toBeVisible();
  await expect(detail).toContainText('HK$ 59.00');
  await expect(detail.getByTestId('transaction-row')).toContainText('¥ 50.00');
  await detail.getByRole('button', { name: '关闭', exact: true }).click();
  await expect(day(date)).toHaveAttribute('data-heat', '4');
  await page.getByRole('button', { name: '下个月', exact: true }).click();
  await expect(day(today)).toHaveAttribute('aria-current', 'date');
  await expect(day(today)).toHaveAttribute('tabindex', '0');
  await page.setViewportSize({ width: 320, height: 812 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await expect.poll(() => page.locator('.heatmap-scroll').evaluate((node) => node.scrollWidth - node.clientWidth - node.scrollLeft)).toBeLessThan(2);
});

test('heatmap switches amounts and shows anchored tooltips with even analysis spacing @smoke', async ({ page }) => {
  const today = hongKongToday();
  const weekday = (new Date(`${today}T12:00:00Z`).getUTCDay() + 6) % 7;
  const monday = offsetDay(today, -weekday - 7);
  const tuesday = offsetDay(monday, 1);
  const sunday = offsetDay(monday, 6);
  const transactions = [
    transaction({ occurredOn: offsetDay(monday, -1), amountMinor: 2000 }),
    transaction({ occurredOn: monday, amountMinor: 1000 }),
    transaction({ occurredOn: tuesday, amountMinor: 2500 }),
  ];
  const envelope = await createEnvelope({ ...emptyData(), transactions }, crypto.randomUUID());
  await page.goto('/#/settings');
  await page.getByRole('button', { name: /^导入账目/ }).click();
  await page.getByLabel('选择备份文件').setInputFiles({ name: 'heatmap-fixture.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(envelope)) });
  const preview = page.getByRole('dialog', { name: '核对账目' });
  await preview.getByRole('button', { name: '确认导入' }).click();
  await expect(preview).not.toBeVisible();
  await page.getByRole('link', { name: '分析', exact: true }).click();

  const chart = page.getByRole('region', { name: '消费热图' });
  const mode = (name: string) => chart.getByRole('button', { name, exact: true });
  const tile = (date: string) => chart.locator(`button[data-date="${date}"]`);
  const tooltip = page.getByRole('tooltip');
  const overview = page.locator('.analysis-overview');
  await expect(overview.getByRole('button', { name: '汇率依据' })).toBeVisible();
  const [summaryBox, heatmapBox, rankingBox] = await Promise.all([overview.boundingBox(), chart.boundingBox(), page.locator('.analysis-card').first().boundingBox()]);
  expect(heatmapBox!.y - (summaryBox!.y + summaryBox!.height)).toBeCloseTo(rankingBox!.y - (heatmapBox!.y + heatmapBox!.height), 1);
  await expect(mode('每天')).toHaveAttribute('aria-pressed', 'true');
  await tile(tuesday).hover();
  await expect(tooltip).toContainText('HK$ 25.00');
  const [cellBox, tooltipBox] = await Promise.all([tile(tuesday).boundingBox(), tooltip.boundingBox()]);
  expect(tooltipBox!.y + tooltipBox!.height <= cellBox!.y || tooltipBox!.y >= cellBox!.y + cellBox!.height).toBe(true);
  await chart.getByRole('heading').hover();
  await expect(tooltip).toHaveCount(0);

  await mode('每周').click();
  await expect(mode('每周')).toHaveAttribute('aria-pressed', 'true');
  await tile(sunday).hover();
  await expect(tooltip).toContainText('HK$ 35.00');
  await tile(sunday).click();
  const detail = page.getByRole('dialog');
  await expect(detail).toContainText('HK$ 35.00');
  await expect(detail.getByRole('list', { name: '本周记录' }).getByTestId('transaction-row')).toHaveCount(2);
  await detail.getByRole('button', { name: '关闭', exact: true }).click();

  await mode('累计总量').click();
  await tile(tuesday).hover();
  await expect(tooltip).toContainText('累计支出 HK$ 55.00');
  await tile(tuesday).press('ArrowUp');
  await expect(tooltip).toContainText('累计支出 HK$ 30.00');
  await page.keyboard.press('Escape');
  await expect(tooltip).toHaveCount(0);
  await tile(tuesday).click();
  await expect(detail.locator('.heatmap-aggregate')).toContainText('HK$ 55.00');
  await expect(detail.getByRole('list', { name: '当天记录' }).getByTestId('transaction-row')).toHaveCount(1);
  await detail.getByRole('button', { name: '关闭', exact: true }).click();
  await page.getByRole('button', { name: '上个月', exact: true }).click();
  await expect(mode('累计总量')).toHaveAttribute('aria-pressed', 'true');
});
