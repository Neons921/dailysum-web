import { expect, test, type Locator, type Page } from '@playwright/test';
import { hongKongToday } from '../../domain/dates';
import { mockFx } from './fx-fixture';
import { choose } from './ui-helpers';

async function openNew(page: Page) {
  await page.getByRole('button', { name: '记一笔', exact: true }).click();
  return page.getByRole('dialog', { name: '记一笔', exact: true });
}

async function save(dialog: Locator) {
  await dialog.getByRole('button', { name: /^保存/ }).click();
  await expect(dialog).not.toBeVisible();
}

test.beforeEach(async ({ page }) => {
  await mockFx(page);
  await page.goto('/');
  await expect(page.getByRole('heading', { name: '收支明细' })).toBeVisible();
});

test('records, refreshes, edits and restores a deletion @smoke', async ({ page }) => {
  const dialog = await openNew(page);
  await expect(dialog.getByLabel('金额', { exact: true })).toBeFocused();
  await dialog.getByLabel('金额', { exact: true }).fill('128.50');
  await dialog.getByRole('group', { name: '记账币种' }).getByRole('button', { name: /人民币/ }).click();
  await expect(dialog.getByLabel('金额', { exact: true })).toHaveValue('128.50');
  await dialog.getByRole('button', { name: '添加备注' }).click();
  await dialog.getByLabel('备注').fill('两地生活的一顿午饭');
  await save(dialog);
  await expect(page.getByRole('status').filter({ hasText: '已保存到本地' })).toBeVisible();
  await page.reload();
  const row = page.getByTestId('transaction-row');
  await expect(row).toHaveCount(1);
  await expect(row).toContainText('¥ 128.50');
  await expect(row).toContainText('两地生活的一顿午饭');
  await row.hover();
  await row.getByRole('button', { name: /编辑/ }).click();
  const edit = page.getByRole('dialog', { name: '编辑记录' });
  await edit.getByLabel('金额', { exact: true }).fill('42');
  await edit.getByRole('group', { name: '记账币种' }).getByRole('button', { name: /港币/ }).click();
  await edit.getByRole('group', { name: '交易分类' }).getByRole('button', { name: '交通' }).click();
  await save(edit);
  await expect(row).toContainText('HK$ 42.00');
  await expect(row).toContainText('交通');
  await row.hover();
  await row.getByRole('button', { name: /删除/ }).click();
  await page.getByRole('dialog', { name: '删除这笔记录？' }).getByRole('button', { name: '删除记录', exact: true }).click();
  await expect(row).toHaveCount(0);
  await page.getByRole('button', { name: '撤销', exact: true }).click();
  await expect(row).toHaveCount(1);
  await expect(row).toContainText('HK$ 42.00');
});

test('undo create restores the complete original draft', async ({ page }) => {
  const dialog = await openNew(page);
  await dialog.getByLabel('金额', { exact: true }).fill('88.30');
  await dialog.getByRole('group', { name: '记账币种' }).getByRole('button', { name: /人民币/ }).click();
  await dialog.getByRole('button', { name: '购物', exact: true }).click();
  await dialog.getByRole('button', { name: '添加备注' }).click();
  await dialog.getByLabel('备注').fill('一本喜欢的书');
  await dialog.locator('#occurredOn').fill('2026-10-22');
  await save(dialog);
  await page.getByRole('button', { name: '撤销', exact: true }).click();
  const restored = page.getByRole('dialog', { name: '记一笔', exact: true });
  await expect(restored.getByLabel('金额', { exact: true })).toHaveValue('88.30');
  await expect(restored.getByRole('group', { name: '记账币种' }).getByRole('button', { name: /人民币/ })).toHaveAttribute('aria-pressed', 'true');
  await expect(restored.getByRole('button', { name: '购物', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await expect(restored.getByLabel('备注')).toHaveValue('一本喜欢的书');
  await expect(restored.locator('#occurredOn')).toHaveValue('2026-10-22');
  await expect(page.getByTestId('transaction-row')).toHaveCount(0);
  await save(restored);
  await expect(page.getByTestId('transaction-row')).toHaveCount(1);
});

test('remembers type, currency and category but resets amount, note and date', async ({ page }) => {
  const dialog = await openNew(page);
  await dialog.getByRole('group', { name: '收支类型' }).getByRole('button', { name: '收入' }).click();
  await expect(dialog.getByRole('button', { name: '餐饮', exact: true })).toHaveCount(0);
  await dialog.getByRole('button', { name: '奖金', exact: true }).click();
  await dialog.getByRole('group', { name: '记账币种' }).getByRole('button', { name: /人民币/ }).click();
  await dialog.getByLabel('金额', { exact: true }).fill('250');
  await dialog.getByRole('button', { name: '添加备注' }).click();
  await dialog.getByLabel('备注').fill('上次的备注');
  await dialog.locator('#occurredOn').fill('2026-01-02');
  await save(dialog);
  const next = await openNew(page);
  await expect(next.getByLabel('金额', { exact: true })).toHaveValue('');
  await expect(next.getByRole('group', { name: '收支类型' }).getByRole('button', { name: '收入' })).toHaveAttribute('aria-pressed', 'true');
  await expect(next.getByRole('button', { name: '奖金', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await expect(next.getByRole('group', { name: '记账币种' }).getByRole('button', { name: /人民币/ })).toHaveAttribute('aria-pressed', 'true');
  await expect(next.locator('#note')).toHaveCount(0);
  await expect(next.locator('#occurredOn')).toHaveValue(hongKongToday());
});

test('rejects invalid input with an explanation and accepts a pasted grouped amount', async ({ page }) => {
  const dialog = await openNew(page);
  for (const amount of ['0', '-1', '1.234', 'NaN', '12,50', '100000000']) {
    await dialog.getByLabel('金额', { exact: true }).fill(amount);
    await expect(dialog.getByRole('button', { name: /^保存/ })).toBeDisabled();
    await expect(dialog.locator('#amount-help')).not.toBeEmpty();
  }
  await dialog.getByLabel('金额', { exact: true }).fill('99,999,999.99');
  await expect(dialog.getByRole('button', { name: /^保存/ })).toBeEnabled();
  expect(await dialog.getByLabel('金额', { exact: true }).evaluate((element) => element.scrollWidth <= element.clientWidth + 2)).toBe(true);
  await dialog.getByLabel('金额', { exact: true }).fill(' 1,234.50 ');
  await save(dialog);
  await expect(page.getByTestId('transaction-row')).toContainText('HK$ 1,234.50');
});

test('repeated submit triggers persist only once', async ({ page }) => {
  const dialog = await openNew(page);
  await dialog.getByLabel('金额', { exact: true }).fill('42');
  await dialog.evaluate((element) => {
    const form = element.querySelector('form')!;
    form.requestSubmit(); form.requestSubmit(); form.requestSubmit();
  });
  await expect(dialog).not.toBeVisible();
  await page.reload();
  await expect(page.getByTestId('transaction-row')).toHaveCount(1);
});

test('storage failure retains the form, shows no success and can be retried', async ({ page }) => {
  const dialog = await openNew(page);
  await dialog.getByLabel('金额', { exact: true }).fill('42.50');
  await page.evaluate(() => {
    const original = IDBObjectStore.prototype.put;
    IDBObjectStore.prototype.put = function (this: IDBObjectStore, ...args: Parameters<IDBObjectStore['put']>) {
      if (this.name === 'transactions') throw new DOMException('模拟磁盘已满', 'QuotaExceededError');
      return original.apply(this, args);
    };
    (window as unknown as { restoreDb: () => void }).restoreDb = () => { IDBObjectStore.prototype.put = original; };
  });
  await dialog.getByRole('button', { name: /^保存/ }).click();
  await expect(dialog.getByRole('alert')).toContainText('输入内容已保留');
  await expect(dialog.getByLabel('金额', { exact: true })).toHaveValue('42.50');
  await expect(page.getByRole('status')).toHaveCount(0);
  await page.evaluate(() => { (window as unknown as { restoreDb: () => void }).restoreDb(); });
  await save(dialog);
  await expect(page.getByTestId('transaction-row')).toHaveCount(1);
});

test('keyboard focus, discard confirmation and IME composition behave correctly', async ({ page }) => {
  await page.keyboard.press('n');
  const dialog = page.getByRole('dialog', { name: '记一笔', exact: true });
  const amount = dialog.getByLabel('金额', { exact: true });
  await expect(amount).toBeFocused();
  await amount.fill('18.90');
  await amount.dispatchEvent('compositionstart', { data: '十' });
  await page.keyboard.press('Control+Enter');
  await expect(dialog).toBeVisible();
  await expect(page.getByTestId('transaction-row')).toHaveCount(0);
  await amount.dispatchEvent('compositionend', { data: '' });
  for (let index = 0; index < 25; index++) {
    await page.keyboard.press('Tab');
    expect(await page.evaluate(() => Boolean(document.activeElement?.closest('dialog[open]')))).toBe(true);
  }
  for (let index = 0; index < 25; index++) {
    await page.keyboard.press('Shift+Tab');
    expect(await page.evaluate(() => Boolean(document.activeElement?.closest('dialog[open]')))).toBe(true);
  }
  await page.keyboard.press('Escape');
  const discard = page.getByRole('dialog', { name: '放弃这次修改？' });
  await expect(discard).toBeVisible();
  await discard.getByRole('button', { name: '取消', exact: true }).click();
  await expect(amount).toHaveValue('18.90');
  await amount.focus();
  await page.keyboard.press('Control+Enter');
  await expect(dialog).not.toBeVisible();
  await expect(page.getByRole('button', { name: '记一笔', exact: true })).toBeFocused();
});

test('report currency never overwrites the next transaction currency', async ({ page }) => {
  await page.getByRole('link', { name: '设置', exact: true }).click();
  await page.getByRole('group', { name: '默认报表币种' }).getByRole('button', { name: /人民币/ }).click();
  await expect(page.getByRole('group', { name: '默认报表币种' }).getByRole('button', { name: /人民币/ })).toHaveAttribute('aria-pressed', 'true');
  const dialog = await openNew(page);
  await expect(dialog.getByRole('group', { name: '记账币种' }).getByRole('button', { name: /港币/ })).toHaveAttribute('aria-pressed', 'true');
  await dialog.getByLabel('金额', { exact: true }).fill('100');
  await save(dialog);
  await expect(page.getByRole('group', { name: '默认报表币种' }).getByRole('button', { name: /人民币/ })).toHaveAttribute('aria-pressed', 'true');
});

test('preview data is visibly separate and never persists', async ({ page }) => {
  await page.getByRole('button', { name: '查看示例' }).click();
  await expect(page.getByText('只读，不会保存到你的账本')).toBeVisible();
  await expect(page.getByTestId('transaction-row')).toHaveCount(7);
  await expect(page.getByRole('button', { name: /编辑.*记录/ })).toHaveCount(0);
  await page.reload();
  await expect(page.getByRole('heading', { name: '本月暂无记录' })).toBeVisible();
  await expect(page.getByTestId('transaction-row')).toHaveCount(0);
});

test('filters isolate original currencies and transaction types', async ({ page }) => {
  await page.getByRole('button', { name: '查看示例' }).click();
  await choose(page, '币种筛选', 'CNY');
  await expect(page.getByTestId('transaction-row')).toHaveCount(2);
  await choose(page, '分类筛选', 'shopping');
  await expect(page.getByTestId('transaction-row')).toHaveCount(1);
  await page.getByRole('button', { name: '清除筛选' }).click();
  await choose(page, '收支筛选', 'income');
  await expect(page.getByTestId('transaction-row')).toHaveCount(1);
  await expect(page.getByTestId('transaction-row')).toContainText('工资');
});

test('the loaded app saves and edits locally while offline', async ({ page, context }) => {
  await context.setOffline(true);
  const dialog = await openNew(page);
  await dialog.getByLabel('金额', { exact: true }).fill('32.50');
  await save(dialog);
  const row = page.getByTestId('transaction-row');
  await row.hover();
  await row.getByRole('button', { name: /编辑/ }).click();
  const edit = page.getByRole('dialog', { name: '编辑记录' });
  await edit.getByLabel('金额', { exact: true }).fill('33');
  await save(edit);
  await expect(row).toContainText('HK$ 33.00');
  await context.setOffline(false);
  await page.reload();
  await expect(row).toContainText('HK$ 33.00');
});

test('Dime summary blocks filter transactions and the search finds notes', async ({ page }) => {
  await page.getByRole('button', { name: '查看示例' }).click();
  await page.getByRole('button', { name: '筛选HKD收入', exact: true }).click();
  await expect(page.getByTestId('transaction-row')).toHaveCount(1);
  await expect(page.getByTestId('transaction-row')).toContainText('月薪');
  await expect(page.getByRole('button', { name: '收支筛选', exact: true })).toContainText('仅收入');
  await expect(page.getByRole('button', { name: '币种筛选', exact: true })).toContainText('全部币种');
  await page.getByRole('button', { name: '清除筛选' }).click();
  await page.getByLabel('搜索记录').fill('咖啡');
  await expect(page.getByTestId('transaction-row')).toHaveCount(1);
  await expect(page.getByTestId('transaction-row')).toContainText('咖啡');
});

test('Dime number pad preserves decimal input and saves in the chosen currency', async ({ page }) => {
  const dialog = await openNew(page);
  await dialog.getByRole('button', { name: '显示数字键盘', exact: true }).click();
  const pad = dialog.getByRole('group', { name: '数字键盘', exact: true });
  for (const digit of ['1', '2', '8']) await pad.getByRole('button', { name: '数字 ' + digit, exact: true }).click();
  await pad.getByRole('button', { name: '小数点' }).click();
  for (const digit of ['5', '0']) await pad.getByRole('button', { name: '数字 ' + digit, exact: true }).click();
  await expect(dialog.getByLabel('金额', { exact: true })).toHaveValue('128.50');
  await pad.getByRole('button', { name: '数字 9', exact: true }).click();
  await expect(dialog.getByLabel('金额', { exact: true })).toHaveValue('128.50');
  await dialog.getByRole('button', { name: '删除最后一位' }).click();
  await pad.getByRole('button', { name: '数字 9', exact: true }).click();
  await expect(dialog.getByLabel('金额', { exact: true })).toHaveValue('128.59');
  await dialog.getByRole('group', { name: '记账币种' }).getByRole('button', { name: /人民币/ }).click();
  await pad.getByRole('button', { name: '键盘保存' }).click();
  await expect(dialog).not.toBeVisible();
  await page.reload();
  await expect(page.getByTestId('transaction-row')).toHaveCount(1);
  await expect(page.getByTestId('transaction-row')).toContainText('¥ 128.59');
});

test('skip navigation moves focus to content without changing the current page', async ({ page }) => {
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByRole('heading', { name: '收支统计' })).toBeVisible();
  const skip = page.getByRole('link', { name: '跳到主要内容' });
  await skip.focus();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('main')).toBeFocused();
  await expect(page.getByRole('heading', { name: '收支统计' })).toBeVisible();
  await expect(page).toHaveURL(/#\/reports$/);
});

test('desktop layouts and modal fit at 1280, 1440 and 1920 widths', async ({ page }, testInfo) => {
  await page.getByRole('button', { name: '查看示例' }).click();
  for (const width of [1280, 1440, 1920]) {
    await page.setViewportSize({ width, height: width === 1280 ? 720 : 1080 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
    await expect(page.getByRole('button', { name: '记一笔', exact: true })).toBeVisible();
    const dialog = await openNew(page);
    const rect = await dialog.boundingBox();
    expect(rect!.x).toBeGreaterThanOrEqual(0);
    expect(rect!.y).toBeGreaterThanOrEqual(0);
    expect(rect!.height).toBeLessThanOrEqual(width === 1280 ? 720 : 1080);
    await page.keyboard.press('Escape');
  }
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.screenshot({ path: testInfo.outputPath('dailysum-desktop.png'), animations: 'disabled' });
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByRole('heading', { name: '收支统计' })).toBeVisible();
  await expect(page.getByTestId('trend-chart')).toBeVisible();
  await page.screenshot({ path: testInfo.outputPath('dailysum-reports.png'), fullPage: true, animations: 'disabled' });
  await page.getByRole('link', { name: '设置', exact: true }).click();
  await expect(page.getByRole('heading', { name: '偏好设置' })).toBeVisible();
  await page.screenshot({ path: testInfo.outputPath('dailysum-settings.png'), fullPage: true, animations: 'disabled' });
  await page.getByRole('link', { name: '明细', exact: true }).click();
  await expect(page.getByRole('heading', { name: '收支明细' })).toBeVisible();
  const dialog = await openNew(page);
  await dialog.getByLabel('金额', { exact: true }).fill('128.50');
  await expect(dialog.getByRole('button', { name: /^保存/ })).toBeEnabled();
  await page.screenshot({ path: testInfo.outputPath('dailysum-dialog.png'), animations: 'disabled' });
});


