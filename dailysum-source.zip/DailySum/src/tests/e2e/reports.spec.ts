import { expect, test, type Page } from '@playwright/test';
import { hongKongToday, monthRange, offsetDay, shiftMonth } from '../../domain/dates';
import { mockFx } from './fx-fixture';
import { choose, dateRange } from './ui-helpers';

async function add(page: Page, amount: string, currency: 'HKD' | 'CNY', date?: string) {
  await page.getByRole('button', { name: '记一笔', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: '记一笔', exact: true });
  await dialog.getByLabel('金额', { exact: true }).fill(amount);
  await dialog.getByRole('group', { name: '记账币种' }).getByRole('button', { name: currency === 'HKD' ? /港币/ : /人民币/ }).click();
  if (date) await dialog.locator('#occurredOn').fill(date);
  await dialog.getByRole('button', { name: /^保存/ }).click();
  await expect(dialog).not.toBeVisible();
}
async function currency(page: Page, value: 'HKD' | 'CNY') {
  await page.getByRole('link', { name: '设置', exact: true }).click();
  const button = page.getByRole('group', { name: '默认报表币种' }).getByRole('button', { name: value === 'HKD' ? /港币/ : /人民币/ });
  await button.click();
  await expect(button).toHaveAttribute('aria-pressed', 'true');
}
test.beforeEach(async ({ page }) => {
  await mockFx(page);
  await page.goto('/');
  await expect(page.getByRole('heading', { name: '收支明细' })).toBeVisible();
});

test('daily FX unifies detail and reports, preserving original inputs @smoke', async ({ page }) => {
  await add(page, '1000', 'HKD'); await add(page, '500', 'CNY');
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 1,590.00');
  await expect(page.getByTestId('transaction-row').filter({ hasText: '¥ 500.00' })).toContainText('≈ −HK$ 590.00');
  await currency(page, 'CNY');
  await page.getByRole('link', { name: '明细', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('¥ 1,347.46');
  await expect(page.getByTestId('transaction-row').filter({ hasText: 'HK$ 1,000.00' })).toContainText('≈ −¥ 847.46');
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('¥ 1,347.46');
  await expect(page.getByTestId('summary-net')).toContainText('−¥ 1,347.46');
  await page.getByRole('button', { name: '记一笔', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: '记一笔', exact: true });
  await expect(dialog.getByRole('group', { name: '记账币种' }).getByRole('button', { name: /人民币/ })).toHaveAttribute('aria-pressed', 'true');
  await page.keyboard.press('Escape');
  await page.reload();
  await expect(page.getByTestId('summary-expense')).toContainText('¥ 1,347.46');
});

test('missing FX allows booking and manual revisions recalculate after confirmation', async ({ page }) => {
  await page.route('https://api.frankfurter.dev/**', (route) => route.abort('failed'));
  await add(page, '100', 'CNY');
  await expect(page.getByTestId('transaction-row')).toContainText('¥ 100.00');
  await expect(page.getByTestId('summary-expense')).toContainText('待折算');
  await expect(page.getByText('缺少 1 天汇率', { exact: false })).toBeVisible();
  await page.getByRole('button', { name: '查看与补录', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: '每日汇率', exact: true });
  await dialog.getByLabel('1 人民币兑换港币').fill('1.18');
  await dialog.getByRole('button', { name: '保存', exact: true }).click();
  await expect(dialog.getByRole('status')).toContainText('汇率已保存');
  await dialog.getByLabel('1 人民币兑换港币').fill('1.20');
  await dialog.getByRole('button', { name: '保存', exact: true }).click();
  await expect(dialog.getByRole('region', { name: '确认汇率修订' })).toContainText('该日 1 笔记录');
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 118.00');
  await dialog.getByRole('button', { name: '确认更新汇率' }).click();
  await expect(dialog.getByRole('region', { name: '已保存汇率' })).toContainText('v2');
  await dialog.getByText('修订记录（2）').click();
  await expect(dialog.getByText('v1 · 手动录入')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 120.00');
  await page.reload();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 120.00');
  await expect(page.getByTestId('transaction-row')).toContainText('¥ 100.00');
});

test('cached daily rates support reports and currency changes while offline', async ({ page, context }) => {
  let requests = 0;
  page.on('request', (request) => { if (request.url().startsWith('https://api.frankfurter.dev/')) requests++; });
  await add(page, '1000', 'HKD'); await add(page, '500', 'CNY');
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 1,590.00');
  const count = requests;
  await context.setOffline(true);
  await currency(page, 'CNY');
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('¥ 1,347.46');
  await expect(page.getByTestId('trend-chart')).toBeVisible();
  expect(requests).toBe(count);
  await add(page, '1.18', 'HKD');
  await expect(page.getByTestId('summary-expense')).toContainText('¥ 1,348.46');
  await context.setOffline(false);
});

test('a pending daily quote updates the cache even after navigating to settings', async ({ page }, testInfo) => {
  let release!: () => void;
  const gate = new Promise<void>((resolve) => { release = resolve; });
  await page.route('https://api.frankfurter.dev/**', async (route) => { await gate; await route.fallback(); });
  await add(page, '100', 'CNY');
  await expect(page.getByText('正在获取每日汇率…')).toBeVisible();
  await page.screenshot({ path: testInfo.outputPath('fx-loading.png'), animations: 'disabled' });
  await page.getByRole('link', { name: '设置', exact: true }).click();
  const dailyRates = page.getByRole('button', { name: /每日汇率/ });
  await expect(dailyRates).toContainText('0 天');
  release();
  await expect(dailyRates).toContainText('1 天');
  await dailyRates.click();
  await expect(page.getByRole('region', { name: '已保存汇率' })).toContainText('1.18000000');
  await page.keyboard.press('Escape');
  await page.getByRole('link', { name: '明细', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 118.00');
});

test('statistics filters, category drilldown and keyboard chart tooltips agree', async ({ page }) => {
  await page.getByRole('button', { name: '查看示例' }).click();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 453.37');
  await expect(page.getByTestId('summary-income')).toContainText('HK$ 28,000.00');
  const chart = page.getByRole('application', { name: /收支趋势图/ });
  await chart.focus(); await page.keyboard.press('ArrowRight');
  await expect(page.getByRole('tooltip')).toContainText('HK$ 75.00');
  await page.keyboard.press('Enter');
  await expect(page.getByRole('region', { name: '统计明细' })).toContainText('2 笔');
  await page.getByRole('button', { name: '切换折线图' }).click();
  await expect(page.getByRole('button', { name: '切换折线图' })).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: '筛选餐饮分类', exact: true }).click();
  await expect(page.getByRole('button', { name: '统计分类筛选', exact: true })).toContainText('餐饮');
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 75.63');
  await choose(page, '统计原币筛选', 'CNY');
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 33.63');
  await page.getByRole('button', { name: '清除统计筛选' }).click();
  await page.getByLabel('搜索统计记录').fill('书籍');
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 198.24');
  await expect(page.getByRole('region', { name: '统计明细' })).toContainText('1 笔');
});

test('custom date range validates and date presets change the same report scope', async ({ page }) => {
  const today = hongKongToday(), older = offsetDay(today, -12);
  await add(page, '50', 'HKD', older);
  await add(page, '100', 'HKD', today);
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await dateRange(page, today, today);
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 100.00');
  await page.getByRole('button', { name: '近 30 天', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 150.00');
  await page.getByRole('button', { name: '统计日期范围', exact: true }).click();
  await page.getByLabel('统计开始日期').fill(offsetDay(today, 1));
  await expect(page.getByRole('alert')).toContainText('开始日期须早于');
  await page.getByRole('button', { name: '今年', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 150.00');
  await expect(page.getByRole('button', { name: '月', exact: true })).toHaveAttribute('aria-pressed', 'true');
});

test('recent-month shortcuts include month-end entries and preserve currency filters @smoke', async ({ page }) => {
  const today = hongKongToday(), month = today.slice(0, 7);
  const previous = [1, 2, 3].map((offset) => monthRange(shiftMonth(month, -offset), today));
  await add(page, '10', 'HKD', previous[0].from);
  await add(page, '20', 'HKD', previous[0].to);
  await add(page, '999', 'CNY', previous[0].to);
  await add(page, '100', 'HKD', previous[1].from);
  await add(page, '1000', 'HKD', previous[2].to);
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await choose(page, '统计原币筛选', 'HKD');
  const shortcuts = page.getByRole('group', { name: '统计时间快捷选择' });
  const buttons = shortcuts.getByRole('button');
  await expect(buttons).toHaveCount(6);
  for (const [index, total] of [[1, 'HK$ 30.00'], [2, 'HK$ 100.00'], [3, 'HK$ 1,000.00']] as const) {
    await buttons.nth(index).click();
    await expect(buttons.nth(index)).toHaveAttribute('aria-pressed', 'true');
    await expect(page.getByTestId('summary-expense')).toContainText(total);
    await expect(page.getByRole('button', { name: '统计原币筛选', exact: true })).toContainText('港币');
  }
  await buttons.nth(0).click();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 0.00');
  await page.clock.setFixedTime(new Date('2026-01-02T04:00:00Z'));
  await page.reload();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(shortcuts).toContainText('2025年11月');
  const pressed = shortcuts.locator('[aria-pressed="true"]');
  await expect(pressed).toHaveCount(1);
  await expect(pressed).toHaveText('本月');
  await shortcuts.getByRole('button', { name: '今年', exact: true }).click();
  await expect(pressed).toHaveCount(1);
  await expect(pressed).toHaveText('今年');
});

test('report charts, tooltips and FX dialog fit supported sizes', async ({ page }, testInfo) => {
  await page.getByRole('button', { name: '查看示例' }).click();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByTestId('trend-chart')).toBeVisible();
  for (const width of [375, 620, 1280, 1440, 1920]) {
    await page.setViewportSize({ width, height: 900 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    const reportTable = page.getByRole('table');
    if (width > 620) expect(await reportTable.evaluate((element) => element.scrollWidth <= element.parentElement!.clientWidth)).toBe(true);
    else expect(await reportTable.evaluate((element) => {
      const wrapper = element.parentElement!;
      return getComputedStyle(wrapper).overflowX === 'auto' && wrapper.getBoundingClientRect().right <= innerWidth;
    })).toBe(true);
    const chart = page.getByRole('application', { name: /收支趋势图/ });
    await chart.scrollIntoViewIfNeeded();
    const bounds = (await chart.boundingBox())!;
    await page.mouse.move(bounds.x + bounds.width - 5, bounds.y + 40);
    const tooltip = page.getByRole('tooltip');
    await expect(tooltip).toBeVisible();
    const box = (await tooltip.boundingBox())!;
    expect(box.x).toBeGreaterThanOrEqual(0);
    expect(box.x + box.width).toBeLessThanOrEqual(width);
  }
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.screenshot({ path: testInfo.outputPath('statistics-full.png'), fullPage: true, animations: 'disabled' });
  await page.getByRole('button', { name: '汇率依据', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: '每日汇率' });
  await expect(dialog).toBeVisible();
  expect(await dialog.evaluate((element) => element.scrollWidth <= element.clientWidth)).toBe(true);
  await page.screenshot({ path: testInfo.outputPath('fx-dialog.png'), animations: 'disabled' });
});

