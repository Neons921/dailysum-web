import { expect, test, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { strToU8, zipSync } from 'fflate';
import { createEnvelope, type LedgerEnvelope } from '../../domain/portable';
import { emptyReportRules } from '../../domain/reportFilters';
import { consolidateCategories } from '../../domain/categories';
import { bill, emptyData, now, transaction } from '../unit/data-fixtures';
import { mockFx } from './fx-fixture';

class GitHubFixture {
  envelope:LedgerEnvelope|null=null;sha='a'.repeat(40);writes=0;private=true;conflict=false;offline=false;unauthorized=false;requests=0;
  async install(page:Page){await page.route('https://api.github.com/**',async(route)=>{
    if(this.offline){await route.abort('internetdisconnected');return;}
    const request=route.request(),url=new URL(request.url());const json=(body:unknown,status=200)=>route.fulfill({contentType:'application/json',status,body:JSON.stringify(body)});
    this.requests++;if(this.unauthorized)return json({},401);
    if(url.pathname==='/repos/example-user/DailySum')return json({full_name:'example-user/DailySum',private:this.private,default_branch:'main',permissions:{push:true}});
    if(url.pathname.endsWith('/contents/dailysum/ledger.v1.json')){
      if(request.method()==='PUT'){
        this.writes++;const body=request.postDataJSON();if(this.conflict||this.envelope&&body.sha!==this.sha)return json({},409);
        this.envelope=JSON.parse(Buffer.from(body.content,'base64').toString('utf8'));this.sha=String(this.writes).padStart(40,'b');return json({content:{sha:this.sha}});
      }
      return this.envelope?json({type:'file',sha:this.sha,size:JSON.stringify(this.envelope).length,encoding:'base64',content:Buffer.from(JSON.stringify(this.envelope)).toString('base64')}):json({},404);
    }
    return json({},404);
  });}
}
async function settings(page:Page){await page.getByRole('link',{name:'设置',exact:true}).click();}
async function importFile(page:Page,items:unknown[],name='cent-backup.json'){
  await page.getByRole('button',{name:/^导入账目/}).click();
  await page.getByLabel('选择备份文件',{exact:true}).setInputFiles({name,mimeType:'application/json',buffer:Buffer.from(JSON.stringify({items,meta:{baseCurrency:'HKD'}}))});
  return page.getByRole('dialog',{name:'核对账目'});
}
async function add(page:Page,amount:string){await page.getByRole('button',{name:'记一笔',exact:true}).click();const dialog=page.getByRole('dialog',{name:'记一笔'});await dialog.getByLabel('金额',{exact:true}).fill(amount);await dialog.getByRole('button',{name:/^保存/}).click();await expect(dialog).not.toBeVisible();}
async function connect(page:Page,remember=true){await page.getByRole('button',{name:/^GitHub 同步/}).click();const dialog=page.getByRole('dialog',{name:'GitHub 同步'});await dialog.getByLabel('DailySum 私有仓库').fill('example-user/DailySum');if(!remember)await dialog.getByLabel('记住 GitHub 连接').uncheck();await dialog.getByLabel('GitHub Token',{exact:true}).fill('FAKE_TOKEN_BROWSER_TEST');await dialog.getByRole('button',{name:'连接并检查',exact:true}).click();}
test.beforeEach(async({page})=>{await mockFx(page);await page.goto('/');await expect(page.getByRole('heading',{name:'收支明细'})).toBeVisible();});

test('Cent import retains originals and backup roundtrips, with clear monetary hierarchy @smoke',async({page},testInfo)=>{
  await settings(page);let dialog=await importFile(page,[bill({amount:2560000,categoryId:'entertainment',comment:'电影'}),bill({id:'dinner',amount:210000,categoryId:'dinner',currency:{base:'HKD',target:'CNY',amount:210000}})]);
  await expect(dialog).toContainText('Cent 导入预览');await page.screenshot({path:testInfo.outputPath('cent-import-preview.png'),animations:'disabled'});await dialog.getByRole('button',{name:'确认导入',exact:true}).click();await expect(dialog).not.toBeVisible();
  await page.getByRole('link',{name:'明细',exact:true}).click();await expect(page.getByTestId('transaction-row')).toHaveCount(2);
  const row=page.getByTestId('transaction-row').filter({hasText:'电影'});await expect(row).toContainText('−HK$ 256.00');await expect(page.getByTestId('summary-expense')).toContainText('HK$ 280.78');
  const hierarchy=await page.evaluate(()=>{const total=document.querySelector('.dime-day-totals strong')!,item=document.querySelector('.dime-row-amount')!,unit=document.querySelector('.dime-row-amount .money-unit')!;return {totalSize:parseFloat(getComputedStyle(total).fontSize),rowSize:parseFloat(getComputedStyle(item).fontSize),totalWeight:parseInt(getComputedStyle(total).fontWeight),unitColor:getComputedStyle(unit).color,digitsColor:getComputedStyle(item).color,spaced:unit.nextSibling?.textContent===' '};});
  expect(hierarchy.totalSize).toBeGreaterThan(hierarchy.rowSize);expect(hierarchy.totalWeight).toBeGreaterThanOrEqual(600);expect(hierarchy.unitColor).not.toBe(hierarchy.digitsColor);expect(hierarchy.spaced).toBe(true);
  await page.screenshot({path:testInfo.outputPath('money-hierarchy.png'),fullPage:true});await row.getByRole('button',{name:'修改娱乐记录',exact:true}).click();dialog=page.getByRole('dialog',{name:'编辑记录'});
  await dialog.getByText('Cent 原始记录',{exact:true}).click();await expect(dialog).toContainText('原始金额：HKD 256');await dialog.getByRole('button',{name:'取消',exact:true}).click();
  await settings(page);const downloadEvent=page.waitForEvent('download');await page.getByRole('button',{name:/^导出备份/}).click();const download=await downloadEvent;const exported=JSON.parse(await readFile((await download.path())!,'utf8'));expect(exported.data.transactions).toHaveLength(2);expect(exported.data.archives[0].data.items).toHaveLength(2);expect(JSON.stringify(exported)).not.toContain('Token');
  dialog=await importFile(page,[bill({amount:2560000,categoryId:'entertainment',comment:'电影'}),bill({id:'dinner',amount:210000,categoryId:'dinner',currency:{base:'HKD',target:'CNY',amount:210000}})]);
  await expect(dialog).toContainText('2 笔已存在');await dialog.getByRole('button',{name:'确认导入',exact:true}).click();await expect(dialog).not.toBeVisible();
  await page.getByRole('button',{name:/^导入账目/}).click();await page.getByLabel('选择备份文件',{exact:true}).setInputFiles({name:'DailySum.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(exported))});dialog=page.getByRole('dialog',{name:'核对账目'});await expect(dialog).toContainText('DailySum 备份预览');await dialog.getByRole('button',{name:'确认导入',exact:true}).click();await expect(dialog).not.toBeVisible();
  await page.getByRole('button',{name:'本地恢复点',exact:true}).click();await expect(page.getByRole('dialog',{name:'本地恢复点'}).getByRole('button',{name:/2 笔/}).first()).toBeVisible();
});

test('partial Cent migration and ZIP attachments require review and remain recoverable',async({page})=>{
  await settings(page);let dialog=await importFile(page,[bill({amount:123450}),bill({id:'unsupported',currency:{target:'USD',amount:100000}})]);
  await expect(dialog).toContainText('四舍五入');await expect(dialog).toContainText('1 笔无法导入');await expect(dialog.getByRole('button',{name:'确认导入',exact:true})).toBeDisabled();await dialog.getByLabel('导入其余有效记录').check();await dialog.getByRole('button',{name:'确认导入',exact:true}).click();await expect(dialog).not.toBeVisible();
  await page.getByRole('button',{name:/^导入账目/}).click();const zip=zipSync({'backup.json':strToU8(JSON.stringify({items:[bill({id:'with-image',images:['assets/receipt.png']})],meta:{baseCurrency:'HKD'}})),'assets/receipt.png':new Uint8Array([1,2,3,4])});await page.getByLabel('选择备份文件',{exact:true}).setInputFiles({name:'journal.cent.zip',mimeType:'application/zip',buffer:Buffer.from(zip)});
  dialog=page.getByRole('dialog',{name:'核对账目'});await dialog.getByRole('button',{name:'确认导入',exact:true}).click();await expect(dialog).not.toBeVisible();
  await page.getByRole('link',{name:'明细',exact:true}).click();await page.getByTestId('transaction-row').filter({hasText:'256.00'}).getByRole('button',{name:'修改餐饮 / 午餐记录',exact:true}).click();const editor=page.getByRole('dialog',{name:'编辑记录'});await editor.getByText('Cent 原始记录',{exact:true}).click();await expect(editor.getByRole('button',{name:'下载附件 1',exact:true})).toBeVisible();
  const downloadEvent=page.waitForEvent('download');await editor.getByRole('button',{name:'下载附件 1',exact:true}).click();expect(await readFile((await (await downloadEvent).path())!)).toEqual(Buffer.from([1,2,3,4]));
});

test('private GitHub connection previews remote data, restores it and auto uploads later edits',async({page},testInfo)=>{
  const github=new GitHubFixture(),data=emptyData(),filterId=crypto.randomUUID();data.filterPreferences.views=[{id:filterId,name:'小额',rules:emptyReportRules(),createdAt:now,updatedAt:now}];github.envelope=await createEnvelope({...data,transactions:[transaction({note:'远端午餐'})]},crypto.randomUUID());await github.install(page);await settings(page);await connect(page);
  let dialog=page.getByRole('dialog',{name:'核对账目'});await expect(dialog).toContainText('GitHub 同步计划');expect(github.writes).toBe(0);await dialog.getByRole('button',{name:'确认同步',exact:true}).click();await expect(dialog).not.toBeVisible();
  await page.getByRole('button',{name:/^GitHub 同步/}).click();dialog=page.getByRole('dialog',{name:'GitHub 同步'});await dialog.getByLabel('自动同步').check();await page.screenshot({path:testInfo.outputPath('github-connected.png'),animations:'disabled'});await dialog.getByRole('button',{name:'取消',exact:true}).click();
  await page.getByRole('link',{name:'明细',exact:true}).click();await expect(page.getByTestId('transaction-row')).toHaveCount(1);await add(page,'40');await expect.poll(()=>github.envelope?.data.transactions.filter((row)=>!row.deletedAt).length,{timeout:10000}).toBe(2);
  const uploads=github.writes;await page.waitForTimeout(2200);expect(github.writes).toBe(uploads); // no self-triggering auto-upload loop
  await page.getByRole('link',{name:'统计',exact:true}).click();await page.getByRole('button',{name:'小额',exact:true}).click();await expect(page.getByTestId('summary-expense')).toContainText('HK$ 65.00');
  const changed=structuredClone(github.envelope!.data);changed.filterPreferences.views[0].rules.maxAmountMinor=3000;github.envelope=await createEnvelope(changed,github.envelope!.ledgerId);await page.evaluate(()=>window.dispatchEvent(new Event('online')));await expect(page.getByTestId('summary-expense')).toContainText('HK$ 25.00');
  const afterRestart=structuredClone(github.envelope!.data);afterRestart.transactions.push(transaction({amountMinor:1000,note:'下次打开拉取'}));github.envelope=await createEnvelope(afterRestart,github.envelope!.ledgerId);
  await page.reload();await expect(page.getByTestId('summary-expense')).toContainText('HK$ 35.00');await settings(page);await expect(page.getByRole('button',{name:/^GitHub 同步/})).toContainText('已连接');await page.getByRole('button',{name:/^GitHub 同步/}).click();dialog=page.getByRole('dialog',{name:'GitHub 同步'});await expect(dialog).toContainText('此浏览器已记住 GitHub 连接');await expect(dialog.getByLabel('GitHub Token',{exact:true})).toHaveCount(0);await expect(dialog.getByLabel('自动同步')).toBeChecked();
  await page.screenshot({path:testInfo.outputPath('remembered-connection.png'),animations:'disabled'});await dialog.getByRole('button',{name:'取消',exact:true}).click();const downloadEvent=page.waitForEvent('download');await page.getByRole('button',{name:/^导出备份/}).click();const exported=await readFile((await (await downloadEvent).path())!,'utf8');expect(exported).not.toContain('FAKE_TOKEN');expect(exported).not.toContain('github-connection');expect(JSON.stringify(github.envelope)).not.toContain('FAKE_TOKEN');
});

test('sync conflicts and conditional-write failures preserve local data and can be checked again',async({page},testInfo)=>{
  const github=new GitHubFixture();await github.install(page);await add(page,'25');await settings(page);await connect(page);let dialog=page.getByRole('dialog',{name:'核对账目'});await dialog.getByRole('button',{name:'确认同步',exact:true}).click();await expect(dialog).not.toBeVisible();
  await page.getByRole('link',{name:'明细',exact:true}).click();await page.getByRole('button',{name:'修改餐饮记录',exact:true}).click();const editor=page.getByRole('dialog',{name:'编辑记录'});await editor.getByLabel('金额',{exact:true}).fill('30');await editor.getByRole('button',{name:/^保存/}).click();await expect(editor).not.toBeVisible();
  github.envelope=await createEnvelope({...github.envelope!.data,transactions:github.envelope!.data.transactions.map((row)=>({...row,amountMinor:4000}))},github.envelope!.ledgerId);await settings(page);await page.getByRole('button',{name:/^GitHub 同步/}).click();dialog=page.getByRole('dialog',{name:'GitHub 同步'});await dialog.getByRole('button',{name:'检查同步',exact:true}).click();dialog=page.getByRole('dialog',{name:'核对账目'});
  await expect(dialog).toContainText('1 项待处理');await expect(dialog.getByRole('button',{name:'确认同步',exact:true})).toBeDisabled();await dialog.getByRole('radio',{name:/此设备/}).check();await page.screenshot({path:testInfo.outputPath('sync-conflict.png'),animations:'disabled'});github.conflict=true;await dialog.getByRole('button',{name:'确认同步',exact:true}).click();await expect(dialog.getByRole('alert')).toContainText('重新检查');
  github.conflict=false;await dialog.getByRole('button',{name:'重新检查',exact:true}).click();await dialog.getByRole('radio',{name:/此设备/}).check();await dialog.getByRole('button',{name:'确认同步',exact:true}).click();await expect(dialog).not.toBeVisible();expect(github.envelope?.data.transactions[0].amountMinor).toBe(3000);
  await page.getByRole('link',{name:'明细',exact:true}).click();await expect(page.getByTestId('transaction-row')).toContainText('HK$ 30.00');
});

test('public repository and invalid file errors remain in the dialog and keep fields editable',async({page})=>{
  const github=new GitHubFixture();github.private=false;await github.install(page);await settings(page);await connect(page);const sync=page.getByRole('dialog',{name:'GitHub 同步'});await expect(sync.getByRole('alert')).toContainText('私有');await expect(sync.getByLabel('DailySum 私有仓库')).toHaveValue('example-user/DailySum');expect(github.writes).toBe(0);await sync.getByRole('button',{name:'取消',exact:true}).click();
  await page.getByRole('button',{name:/^导入账目/}).click();await page.getByLabel('选择备份文件',{exact:true}).setInputFiles({name:'broken.json',mimeType:'application/json',buffer:Buffer.from('{invalid')});const dialog=page.getByRole('dialog',{name:'导入账目'});await expect(dialog.getByRole('alert')).toContainText('JSON');await expect(dialog.getByLabel('选择备份文件',{exact:true})).toBeEnabled();
});

test('Cent GitHub migration replays source actions using read-only requests',async({page})=>{
  const requests:string[]=[],meta='1'.repeat(40),chunk='2'.repeat(40);
  await page.route('https://api.github.com/**',async(route)=>{
    const url=new URL(route.request().url());requests.push(route.request().method());const body=url.pathname.includes('/git/trees/')?{sha:'3'.repeat(40),truncated:false,tree:[{type:'blob',path:'meta.json',sha:meta,size:100},{type:'blob',path:'ledger-0.json',sha:chunk,size:400}]}:url.pathname.includes('/git/blobs/')?{encoding:'base64',size:400,content:Buffer.from(JSON.stringify(url.pathname.endsWith(meta)?{baseCurrency:'HKD'}:[{id:'one',type:'update',timestamp:1,value:bill({id:'first',amount:100000})},{id:'two',type:'update',timestamp:2,value:bill({id:'removed',amount:200000})},{id:'three',type:'delete',timestamp:3,value:'removed'}])).toString('base64')}:{full_name:'example-user/cent-journal-example-ledger',private:true,default_branch:'main'};
    await route.fulfill({contentType:'application/json',body:JSON.stringify(body)});
  });
  await settings(page);await page.getByRole('button',{name:/^导入账目/}).click();let dialog=page.getByRole('dialog',{name:'导入账目'});await dialog.getByRole('button',{name:'Cent 仓库',exact:true}).click();await dialog.getByLabel('Cent 仓库',{exact:true}).fill('example-user/cent-journal-example-ledger');await dialog.getByLabel('GitHub Token',{exact:true}).fill('FAKE_READ_ONLY_TOKEN');await dialog.getByRole('button',{name:'读取 Cent 数据',exact:true}).click();dialog=page.getByRole('dialog',{name:'核对账目'});await expect(dialog).toContainText('Cent 导入预览');await dialog.getByRole('button',{name:'确认导入',exact:true}).click();await expect(dialog).not.toBeVisible();
  expect(requests.length).toBe(4);expect(requests.every((method)=>method==='GET')).toBe(true);await page.getByRole('link',{name:'明细',exact:true}).click();await expect(page.getByTestId('transaction-row')).toHaveCount(1);await expect(page.getByTestId('summary-expense')).toContainText('HK$ 10.00');
});

test('data dialogs fit narrow and desktop viewports, trap focus and restore a selected checkpoint',async({page},testInfo)=>{
  await settings(page);await page.getByRole('button',{name:/^导入账目/}).click();let dialog=page.getByRole('dialog',{name:'导入账目'});
  for(const [width,height] of [[375,812],[1280,720],[1440,900],[1920,1080]]){
    await page.setViewportSize({width,height});const box=(await dialog.boundingBox())!;expect(box.x).toBeGreaterThanOrEqual(0);expect(box.y).toBeGreaterThanOrEqual(0);expect(box.x+box.width).toBeLessThanOrEqual(width);expect(box.y+box.height).toBeLessThanOrEqual(height);expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(width);
    await page.screenshot({path:testInfo.outputPath(`import-${width}.png`),animations:'disabled'});
  }
  for(let index=0;index<12;index++){await page.keyboard.press('Tab');expect(await dialog.evaluate((element)=>element.contains(document.activeElement))).toBe(true);}
  await page.keyboard.press('Escape');await expect(dialog).not.toBeVisible();dialog=await importFile(page,[bill()]);await dialog.getByRole('button',{name:'确认导入',exact:true}).click();await expect(dialog).not.toBeVisible();await page.getByRole('button',{name:'本地恢复点',exact:true}).click();dialog=page.getByRole('dialog',{name:'本地恢复点'});await dialog.getByRole('button',{name:/0 笔/}).click();await dialog.getByRole('button',{name:'恢复此版本',exact:true}).click();await expect(dialog).not.toBeVisible();await page.getByRole('link',{name:'明细',exact:true}).click();await expect(page.getByTestId('transaction-row')).toHaveCount(0);await expect(page.getByRole('heading',{name:'本月暂无记录'})).toBeVisible();
});

test('a saved connection survives reopening a tab and forgetting it also disconnects another tab',async({page,context})=>{
  const github=new GitHubFixture();await github.install(page);await add(page,'25');await settings(page);await connect(page);let dialog=page.getByRole('dialog',{name:'核对账目'});await dialog.getByRole('button',{name:'确认同步',exact:true}).click();await expect(dialog).not.toBeVisible();
  const reopened=await context.newPage();await mockFx(reopened);await github.install(reopened);await page.close();await reopened.goto('/#/settings');await expect(reopened.getByRole('button',{name:/^GitHub 同步/})).toContainText('已连接');await reopened.getByRole('button',{name:/^GitHub 同步/}).click();dialog=reopened.getByRole('dialog',{name:'GitHub 同步'});await expect(dialog).toContainText('此浏览器已记住 GitHub 连接');await dialog.getByRole('button',{name:'取消',exact:true}).click();
  const peer=await context.newPage();await mockFx(peer);await github.install(peer);await peer.goto('/#/settings');await expect(peer.getByRole('button',{name:/^GitHub 同步/})).toContainText('已连接');
  await reopened.getByRole('button',{name:/^GitHub 同步/}).click();dialog=reopened.getByRole('dialog',{name:'GitHub 同步'});await dialog.getByRole('button',{name:'忘记连接',exact:true}).click();await expect(dialog.getByLabel('GitHub Token',{exact:true})).toHaveValue('');await expect(peer.getByRole('button',{name:/^GitHub 同步/})).toContainText('未连接');
  await dialog.getByRole('button',{name:'取消',exact:true}).click();await reopened.reload();await reopened.getByRole('button',{name:/^GitHub 同步/}).click();await expect(reopened.getByRole('dialog',{name:'GitHub 同步'}).getByLabel('GitHub Token',{exact:true})).toHaveValue('');
  await reopened.getByRole('dialog').getByRole('button',{name:'取消',exact:true}).click();await reopened.getByRole('link',{name:'明细',exact:true}).click();await expect(reopened.getByTestId('transaction-row')).toContainText('HK$ 25.00');await peer.close();
});

test('session-only opt-out and disabling automatic sync both survive reload as chosen',async({page})=>{
  const github=new GitHubFixture();await github.install(page);await add(page,'25');await settings(page);await connect(page,false);let dialog=page.getByRole('dialog',{name:'核对账目'});await dialog.getByRole('button',{name:'确认同步',exact:true}).click();await expect(dialog).not.toBeVisible();
  const requests=github.requests;await page.reload();await page.getByRole('button',{name:/^GitHub 同步/}).click();dialog=page.getByRole('dialog',{name:'GitHub 同步'});await expect(dialog.getByLabel('GitHub Token',{exact:true})).toHaveValue('');expect(github.requests).toBe(requests);
  await dialog.getByLabel('GitHub Token',{exact:true}).fill('FAKE_REMEMBERED_TOKEN');await dialog.getByRole('button',{name:'连接并检查',exact:true}).click();dialog=page.getByRole('dialog',{name:'核对账目'});await dialog.getByRole('button',{name:'确认同步',exact:true}).click();await expect(dialog).not.toBeVisible();
  await page.getByRole('button',{name:/^GitHub 同步/}).click();dialog=page.getByRole('dialog',{name:'GitHub 同步'});await dialog.getByLabel('自动同步').uncheck();await dialog.getByRole('button',{name:'取消',exact:true}).click();const idleRequests=github.requests;
  await page.reload();await expect(page.getByRole('button',{name:/^GitHub 同步/})).toContainText('已连接');await page.getByRole('button',{name:/^GitHub 同步/}).click();dialog=page.getByRole('dialog',{name:'GitHub 同步'});await expect(dialog.getByLabel('自动同步')).not.toBeChecked();await expect(dialog).toContainText('此浏览器已记住 GitHub 连接');expect(github.requests).toBe(idleRequests);
});

test('an expired saved token prompts reconnection while a network error keeps it for retry',async({page})=>{
  const github=new GitHubFixture();await github.install(page);await add(page,'25');await settings(page);await connect(page);let dialog=page.getByRole('dialog',{name:'核对账目'});await dialog.getByRole('button',{name:'确认同步',exact:true}).click();await expect(dialog).not.toBeVisible();
  github.offline=true;await page.reload();await expect(page.getByRole('button',{name:/^GitHub 同步/})).toContainText('待处理');await page.getByRole('button',{name:/^GitHub 同步/}).click();dialog=page.getByRole('dialog',{name:'GitHub 同步'});await expect(dialog).toContainText('此浏览器已记住 GitHub 连接');await dialog.getByRole('button',{name:'取消',exact:true}).click();
  github.offline=false;await page.evaluate(()=>window.dispatchEvent(new Event('online')));await expect(page.getByRole('button',{name:/^GitHub 同步/})).toContainText('已连接');
  github.unauthorized=true;await page.reload();await expect(page.getByRole('button',{name:/^GitHub 同步/})).toContainText('需重新连接');await page.getByRole('button',{name:/^GitHub 同步/}).click();dialog=page.getByRole('dialog',{name:'GitHub 同步'});await expect(dialog.getByRole('alert')).toContainText('Token 已失效');await expect(dialog.getByLabel('GitHub Token',{exact:true})).toHaveValue('');
  github.unauthorized=false;await dialog.getByLabel('GitHub Token',{exact:true}).fill('FAKE_REPLACEMENT_TOKEN');await dialog.getByRole('button',{name:'连接并检查',exact:true}).click();dialog=page.getByRole('dialog',{name:'核对账目'});await dialog.getByRole('button',{name:'确认同步',exact:true}).click();await expect(dialog).not.toBeVisible();await page.getByRole('link',{name:'明细',exact:true}).click();await expect(page.getByTestId('transaction-row')).toContainText('HK$ 25.00');
});

test('a category-cleaned native file merges without conflicts and keeps legacy filters narrow @smoke',async({page})=>{
  const data=emptyData(),parent={id:'cent-test-food',name:'餐饮',type:'expense' as const,icon:'food',color:'gray',sortOrder:100,sourceCategoryId:'food'};
  const breakfast={...parent,id:'cent-test-breakfast',name:'餐饮 / 早餐',parentId:parent.id,sourceCategoryId:'breakfast'},lunch={...parent,id:'cent-test-lunch',name:'餐饮 / 午餐',parentId:parent.id,sourceCategoryId:'launch'};
  data.categories.push(parent,breakfast,lunch);data.transactions=[transaction({categoryId:breakfast.id,amountMinor:1000,note:'记录一'}),transaction({categoryId:lunch.id,amountMinor:2300,note:'记录二'})];
  const filterId=crypto.randomUUID();data.filterPreferences={...data.filterPreferences,activeId:filterId,views:[{id:filterId,name:'不含早餐',rules:{...emptyReportRules(),excludeCategoryIds:[breakfast.id]},createdAt:now,updatedAt:now}]};
  const original=await createEnvelope(data,crypto.randomUUID()),cleaned=await createEnvelope(consolidateCategories(data).data,original.ledgerId);
  const importNative=async(envelope:LedgerEnvelope)=>{await settings(page);await page.getByRole('button',{name:/^导入账目/}).click();await page.getByLabel('选择备份文件',{exact:true}).setInputFiles({name:'ledger.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(envelope))});const dialog=page.getByRole('dialog',{name:'核对账目'});await expect(dialog.getByRole('radio')).toHaveCount(0);await dialog.getByRole('button',{name:'确认导入',exact:true}).click();await expect(dialog).not.toBeVisible();};
  await importNative(original);await expect(page.locator('.settings-category')).toHaveCount(16);
  await importNative(cleaned);await expect(page.locator('.settings-category')).toHaveCount(13);
  await page.getByRole('link',{name:'统计',exact:true}).click();await expect(page.getByTestId('summary-expense')).toContainText('HK$ 23.00');await expect(page.getByLabel('当前过滤条件')).toContainText('餐饮 / 早餐');
  await page.getByRole('link',{name:'明细',exact:true}).click();await page.getByLabel('搜索记录',{exact:true}).fill('早餐');await expect(page.getByTestId('transaction-row')).toHaveCount(1);await expect(page.getByTestId('transaction-row')).toContainText('记录一');
  await importNative(original);await expect(page.locator('.settings-category')).toHaveCount(13);await page.getByRole('button',{name:'记一笔',exact:true}).click();const editor=page.getByRole('dialog',{name:'记一笔'});await expect(editor.getByRole('group',{name:'交易分类'}).getByRole('button')).toHaveCount(7);await editor.getByRole('button',{name:'收入',exact:true}).click();await expect(editor.getByRole('group',{name:'交易分类'}).getByRole('button')).toHaveCount(6);
});
