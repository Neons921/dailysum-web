import { expect, test, type Page } from '@playwright/test';
import { mockFx } from './fx-fixture';
import { choose } from './ui-helpers';

async function add(page: Page, amount: string, note: string, category = '餐饮', currency: 'HKD' | 'CNY' = 'HKD') {
  await page.getByRole('button', { name: '记一笔', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: '记一笔', exact: true });
  await dialog.getByLabel('金额', { exact: true }).fill(amount);
  await dialog.getByRole('group', { name: '记账币种' }).getByRole('button', { name: currency === 'CNY' ? /人民币/ : /港币/ }).click();
  await dialog.getByRole('button', { name: category, exact: true }).click();
  await dialog.getByRole('button', { name: '添加备注', exact: true }).click();
  await dialog.getByLabel('备注').fill(note);
  await dialog.getByRole('button', { name: /^保存/ }).click();
  await expect(dialog).not.toBeVisible();
}
test.beforeEach(async ({ page }) => {
  await mockFx(page); await page.goto('/');
  await expect(page.getByRole('heading', { name: '收支明细' })).toBeVisible();
});

test('custom named filters combine categories, capped amounts and exclusions and survive reload @smoke', async ({ page }, testInfo) => {
  await add(page,'30','午餐'); await add(page,'20','地铁','交通'); await add(page,'50','晚餐','餐饮','CNY');
  await add(page,'3000','旅行','购物'); await add(page,'80','水电费'); await add(page,'1000','聚餐');
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await page.getByRole('button', { name: '新建过滤器', exact: true }).click();
  const editor = page.getByRole('dialog', { name: '自定义过滤器' });
  await editor.getByRole('button', { name: '日常餐饮交通', exact: true }).click();
  await editor.getByLabel('过滤器最高金额').fill('500');
  await editor.getByLabel('过滤器排除备注').fill('水电费');
  await editor.getByLabel('过滤器名称').fill('日常开支');
  await editor.getByRole('button', { name: '保存并应用', exact: true }).click();
  await expect(editor).not.toBeVisible();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 109.00');
  await expect(page.getByRole('button', { name: '日常开支', exact: true })).toHaveAttribute('aria-pressed','true');
  await page.screenshot({ path: testInfo.outputPath('filter-saved.png'), animations: 'disabled' });
  await page.getByRole('button', { name: '已排除', exact: false }).click();
  const table = page.getByRole('table');
  await expect(table).toContainText('水电费'); await expect(table).toContainText('高于 HK$ 500.00');
  await expect(table).toContainText('不在所选分类中');
  await page.reload();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 109.00');
  await page.getByRole('link', { name: '设置', exact: true }).click();
  await page.getByRole('group', { name: '默认报表币种' }).getByRole('button', { name: /人民币/ }).click();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('¥ 92.37');
  await expect(page.getByLabel('当前过滤条件')).toContainText('HK$ 500.00');
  await page.getByRole('link', { name: '明细', exact: true }).click();
  await expect(page.getByTestId('transaction-row')).toHaveCount(6);
});

test('exclude-category rules and individual exclusions remain reversible and never delete records', async ({ page }) => {
  await page.getByRole('button', { name: '查看示例' }).click();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 453.37');
  await page.getByRole('button', { name: '从统计中排除咖啡记录', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 419.74');
  await page.getByRole('button', { name: /已排除/ }).click();
  await expect(page.getByRole('table')).toContainText('手动排除此笔');
  await page.getByRole('button', { name: '恢复纳入咖啡记录', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 453.37');
  await page.getByRole('button', { name: /^过滤器/ }).click();
  const editor = page.getByRole('dialog', { name: '自定义过滤器' });
  await editor.getByRole('button', { name: '排除分类', exact: true }).click();
  await editor.getByRole('checkbox', { name: '购物', exact: true }).click();
  await editor.getByRole('button', { name: '应用过滤器', exact: true }).click();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 255.13');
  await page.getByRole('button', { name: /已排除/ }).click();
  await expect(page.getByRole('table')).toContainText('已排除此分类');
  await page.getByRole('link', { name: '明细', exact: true }).click();
  await expect(page.getByTestId('transaction-row')).toHaveCount(7);
});

test('pending amount membership is visible even when the report currency itself needs no conversion', async ({ page }, testInfo) => {
  await page.route('https://api.frankfurter.dev/**', (route) => route.abort('failed'));
  await add(page,'100','待核对','餐饮','CNY');
  await page.getByRole('link', { name: '设置', exact: true }).click();
  await page.getByRole('group', { name: '默认报表币种' }).getByRole('button', { name: /人民币/ }).click();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await page.getByRole('button', { name: '新建过滤器', exact: true }).click();
  const editor = page.getByRole('dialog', { name: '自定义过滤器' });
  await editor.getByRole('group', { name: '金额比较币种' }).getByRole('button', { name: /港币/ }).click();
  await editor.getByLabel('过滤器最高金额').fill('150');
  await editor.getByRole('button', { name: '应用过滤器' }).click();
  await expect(page.getByText('1 笔记录的金额条件待汇率校验', { exact: false })).toBeVisible();
  await expect(page.getByTestId('summary-expense')).toContainText('待折算');
  await page.screenshot({ path: testInfo.outputPath('fx-pending.png'), animations: 'disabled' });
  await page.getByRole('button', { name: '补齐汇率', exact: true }).click();
  const rates = page.getByRole('dialog', { name: '每日汇率', exact: true });
  await rates.getByLabel('1 人民币兑换港币').fill('1.18');
  await rates.getByRole('button', { name: '保存', exact: true }).click();
  await expect(rates.getByRole('status')).toContainText('汇率已保存');
  await page.keyboard.press('Escape');
  await expect(page.getByTestId('summary-expense')).toContainText('¥ 100.00');
  await expect(page.getByText('1 笔记录的金额条件待汇率校验', { exact: false })).toHaveCount(0);
});

test('filter validation retains input and saved views can be edited and deleted safely', async ({ page }) => {
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await page.getByRole('button', { name: '新建过滤器', exact: true }).click();
  const editor = page.getByRole('dialog', { name: '自定义过滤器' });
  await editor.getByLabel('过滤器最低金额').fill('500');
  await editor.getByLabel('过滤器最高金额').fill('50');
  await editor.getByRole('button', { name: '保存并应用' }).click();
  await expect(editor.getByRole('alert')).toContainText('最低金额不能高于');
  await expect(editor.getByRole('alert')).toBeFocused();
  await expect(editor.getByLabel('过滤器最高金额')).toHaveValue('50');
  await editor.getByLabel('过滤器最高金额').fill('1000');
  await editor.getByLabel('过滤器名称').fill('区间统计');
  await editor.getByRole('button', { name: '保存并应用' }).click();
  await expect(editor).not.toBeVisible();
  await page.getByRole('button', { name: /^过滤器/ }).click();
  const edit = page.getByRole('dialog', { name: '编辑过滤器' });
  await expect(edit.getByLabel('过滤器最低金额')).toHaveValue('500.00');
  await edit.getByLabel('过滤器名称').fill('更新后的区间');
  await edit.getByRole('button', { name: '保存并应用' }).click();
  await expect(page.getByRole('button', { name: '更新后的区间', exact: true })).toBeVisible();
  await page.getByRole('button', { name: '删除当前过滤器', exact: true }).click();
  await page.getByRole('dialog', { name: '删除“更新后的区间”？' }).getByRole('button', { name: '删除过滤器', exact: true }).click();
  await expect(page.getByRole('button', { name: '更新后的区间', exact: true })).toHaveCount(0);
});

test('custom menus and calendars support keyboard navigation and Escape without dismissing the parent form', async ({ page }) => {
  await page.getByRole('button', { name: '查看示例' }).click();
  const type = page.getByRole('button', { name: '收支筛选', exact: true });
  await type.focus(); await page.keyboard.press('ArrowDown');
  const list = page.getByRole('listbox', { name: '收支筛选', exact: true });
  await expect(list).toBeVisible();
  await page.keyboard.press('End'); await page.keyboard.press('Enter');
  await expect(type).toContainText('仅收入'); await expect(type).toBeFocused();
  await expect(page.getByTestId('transaction-row')).toHaveCount(1);
  await page.getByRole('button', { name: '记一笔', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: '记一笔', exact: true });
  await dialog.getByRole('button', { name: '打开交易日期日历', exact: true }).click();
  const calendar = page.getByRole('dialog', { name: '打开交易日期日历', exact: true });
  await expect(calendar).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(calendar).not.toBeVisible(); await expect(dialog).toBeVisible();
  await page.keyboard.press('Escape'); await expect(dialog).not.toBeVisible();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await page.getByRole('button', { name: '统计日期范围', exact: true }).click();
  const range = page.getByRole('dialog', { name: '统计日期范围', exact: true });
  await expect(range).toBeVisible(); await page.keyboard.press('Escape'); await expect(range).not.toBeVisible();
  await choose(page,'统计原币筛选','CNY');
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 231.87');
});

test('a failed filter save keeps the draft and can retry without duplicate views', async ({ page }, testInfo) => {
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await page.getByRole('button', { name: '新建过滤器', exact: true }).click();
  const editor = page.getByRole('dialog', { name: '自定义过滤器' });
  await editor.getByRole('button', { name: '排除水电费', exact: true }).click();
  await page.evaluate(() => {
    const original = IDBObjectStore.prototype.put;
    (window as unknown as { restoreFilterPut: () => void }).restoreFilterPut = () => { IDBObjectStore.prototype.put = original; };
    IDBObjectStore.prototype.put = function(value, key) {
      if (this.name === 'settings' && value?.id === 'report-views') throw new DOMException('Test quota failure', 'QuotaExceededError');
      return key === undefined ? original.call(this,value) : original.call(this,value,key);
    };
  });
  await editor.getByRole('button', { name: '保存并应用' }).click();
  await expect(editor.getByRole('alert')).toBeVisible();
  await expect(editor.getByLabel('过滤器名称')).toHaveValue('排除水电费');
  await expect(editor.getByLabel('过滤器排除备注')).toHaveValue('水电费');
  await page.screenshot({ path: testInfo.outputPath('filter-save-error.png'), animations: 'disabled' });
  await page.evaluate(() => (window as unknown as { restoreFilterPut: () => void }).restoreFilterPut());
  await editor.getByRole('button', { name: '保存并应用' }).click();
  await expect(editor).not.toBeVisible();
  await expect(page.getByRole('button', { name: '排除水电费', exact: true })).toHaveCount(1);
});

test('redesigned states fit narrow and desktop viewports and produce review artifacts', async ({ page }, testInfo) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  const errors: string[] = []; page.on('pageerror', (cause) => errors.push(cause.message));
  await page.screenshot({ path: testInfo.outputPath('empty.png'), animations: 'disabled' });
  await page.getByRole('button', { name: '查看示例' }).click();
  await page.getByRole('link', { name: '统计', exact: true }).click();
  await expect(page.getByTestId('trend-chart')).toBeVisible();
  for (const [width,height] of [[375,812],[1280,720],[1440,900],[1920,1080]]) {
    await page.setViewportSize({ width,height });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await page.screenshot({ path: testInfo.outputPath(`reports-${width}x${height}.png`),fullPage:true,animations:'disabled' });
    await page.getByRole('button', { name: '统计原币筛选', exact: true }).click();
    const list = page.getByRole('listbox', { name: '统计原币筛选', exact: true });
    const bounds = (await list.boundingBox())!;
    expect(bounds.x).toBeGreaterThanOrEqual(0); expect(bounds.x+bounds.width).toBeLessThanOrEqual(width);
    await page.screenshot({ path:testInfo.outputPath(`menu-${width}.png`),animations:'disabled' });
    await page.keyboard.press('Escape');
    await page.getByRole('button', { name: '统计日期范围', exact: true }).click();
    const range = page.getByRole('dialog', { name: '统计日期范围', exact: true });
    const rangeBounds = (await range.boundingBox())!;
    expect(rangeBounds.x).toBeGreaterThanOrEqual(0); expect(rangeBounds.x+rangeBounds.width).toBeLessThanOrEqual(width);
    await page.screenshot({ path:testInfo.outputPath(`calendar-${width}.png`),animations:'disabled' });
    await page.keyboard.press('Escape');
  }
  await page.setViewportSize({width:1440,height:900});
  await page.getByRole('button', {name:'新建过滤器',exact:true}).click();
  const editor=page.getByRole('dialog',{name:'自定义过滤器'});
  await editor.getByRole('button',{name:'日常餐饮交通',exact:true}).click();
  await editor.getByLabel('过滤器最高金额').fill('500');
  await editor.getByLabel('过滤器排除备注').fill('水电费');
  await page.screenshot({path:testInfo.outputPath('filter-editor.png'),animations:'disabled'});
  await editor.getByRole('button',{name:'应用过滤器',exact:true}).click();
  await expect(page.getByTestId('summary-expense')).toContainText('HK$ 93.63');
  await page.screenshot({path:testInfo.outputPath('filtered-report.png'),fullPage:true,animations:'disabled'});
  expect(errors).toEqual([]);
});

