import type { Page } from '@playwright/test';
import { offsetDay } from '../../domain/dates';

/** Deterministic provider stub used only in tests; no production fallback ratio. */
export async function mockFx(page: Page) {
  await page.route('https://api.frankfurter.dev/**', async (route) => {
    const url = new URL(route.request().url());
    const from = url.searchParams.get('from')!, to = url.searchParams.get('to')!;
    const body = [];
    for (let day = from; day <= to; day = offsetDay(day, 1)) {
      body.push({ date: day, base: 'EUR', quote: 'CNY', rate: 10 }, { date: day, base: 'EUR', quote: 'HKD', rate: 11.8 });
    }
    await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body), headers: { 'access-control-allow-origin': '*' } });
  });
}
