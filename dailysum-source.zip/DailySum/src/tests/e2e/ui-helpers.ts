import type { Page } from '@playwright/test';
export async function choose(page: Page, label: string, value: string) {
  await page.getByRole('button', { name: label, exact: true }).click();
  await page.getByRole('listbox', { name: label, exact: true }).locator(`[role="option"][data-value="${value}"]`).click();
}
export async function dateRange(page: Page, from: string, to: string) {
  await page.getByRole('button', { name: '统计日期范围', exact: true }).click();
  const popup = page.getByRole('dialog', { name: '统计日期范围', exact: true });
  await popup.getByLabel('统计开始日期').fill(from);
  await popup.getByLabel('统计结束日期').fill(to);
  await popup.getByRole('button', { name: '应用日期', exact: true }).click();
}
