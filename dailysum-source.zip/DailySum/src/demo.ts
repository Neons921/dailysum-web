import type { Transaction } from './domain/models';

/** Read-only preview fixtures. These never enter the user's IndexedDB. */
export function demoTransactions(month: string): Transaction[] {
  const entries = [
    ['03', 'expense', 4200, 'HKD', 'food', '午餐'],
    ['03', 'expense', 1800, 'HKD', 'transport', '电车'],
    ['03', 'expense', 2850, 'CNY', 'food', '咖啡'],
    ['02', 'expense', 16800, 'CNY', 'shopping', '书籍'],
    ['02', 'expense', 8650, 'HKD', 'living', '超市'],
    ['01', 'income', 2800000, 'HKD', 'salary', '月薪'],
    ['01', 'expense', 7500, 'HKD', 'fun', '电影'],
  ] as const;
  return entries.map(([day, type, amountMinor, currency, categoryId, note], index) => ({
    id: `demo-${index}`, type, amountMinor, currency, categoryId, note,
    occurredOn: `${month}-${day}`, createdAt: `${month}-${day}T04:00:00.000Z`,
    updatedAt: `${month}-${day}T04:00:00.000Z`, deletedAt: null, schemaVersion: 1,
  }));
}
