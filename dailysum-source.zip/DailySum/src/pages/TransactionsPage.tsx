/**
 * GPL-3.0. Web port of Rafael Soh's LogView / ListView in rafsoh/dimeApp.
 * Native grouped fetches become the existing local repository's date groups;
 * SearchView and filter controls stay keyboard-accessible on desktop.
 */
import { useState } from 'react';
import { Plus, Search, SlidersHorizontal, X } from 'lucide-react';
import type { Category, Currency, FxRate, Transaction, TransactionType } from '../domain/models';
import { formatDay } from '../domain/dates';
import { amountToInput } from '../domain/money';
import { Money } from '../components/Money';
import { summarizeConverted } from '../domain/reports';
import { convertedMinor, latestRates, missingRateDates, roundMinor } from '../domain/fx';
import { FxStatus, type FxStatusData } from '../components/FxStatus';
import { SummaryCards } from '../components/SummaryCards';
import { DimeTransactionRow } from '../dime/DimeTransactionRow';
import { Select } from '../components/Select';
import { Modal } from '../components/Modal';
import { isAndroid } from '../app/android';
import { AndroidSummary } from '../android/AndroidSummary';
import { AndroidLedgerRow } from '../android/AndroidLedgerRow';
import { AndroidRecordActions } from '../android/AndroidRecordActions';

export function TransactionsPage({ transactions, categories, preferred, demo, onNew, onEdit, onDelete, onDemo, rates, fxStatus, onRates }: {
  transactions: Transaction[];
  categories: Category[];
  preferred: Currency;
  demo: boolean;
  onNew: () => void;
  onEdit: (transaction: Transaction) => void;
  onDelete: (transaction: Transaction) => void;
  onDemo: () => void;
  rates: FxRate[];
  fxStatus: FxStatusData;
  onRates: (date?: string) => void;
}) {
  const [type, setType] = useState<TransactionType | ''>('');
  const [currency, setCurrency] = useState<Currency | ''>('');
  const [categoryId, setCategoryId] = useState('');
  const [query, setQuery] = useState('');
  const [filterSheet, setFilterSheet] = useState(false);
  const [actionId, setActionId] = useState<string | null>(null);
  const categoryMap = new Map(categories.map((category) => [category.id, category]));
  const search = query.trim().toLocaleLowerCase();
  const filtered = transactions.filter((transaction) =>
    (!type || transaction.type === type) && (!currency || transaction.currency === currency)
    && (!categoryId || transaction.categoryId === categoryId)
    && (!search || [transaction.note, categoryMap.get(transaction.categoryId)?.name ?? '', transaction.currency,
      transaction.occurredOn,amountToInput(transaction.amountMinor),...(transaction.categoryHistory??[]).map((id)=>categoryMap.get(id)?.name??'')].join(' ').toLocaleLowerCase().includes(search)),
  ).sort((a, b) => b.occurredOn.localeCompare(a.occurredOn) || b.createdAt.localeCompare(a.createdAt) || a.id.localeCompare(b.id));
  const days = [...new Set(filtered.map((transaction) => transaction.occurredOn))];
  const hasFilters = Boolean(type || currency || categoryId || query);
  const clear = () => { setType(''); setCurrency(''); setCategoryId(''); setQuery(''); };
  const rateMap = latestRates(rates);
  const summary = summarizeConverted(filtered, preferred, rates);
  const applyType = (nextType: TransactionType | '') => {
    setType(nextType);
    if (nextType && categoryId && categoryMap.get(categoryId)?.type !== nextType) setCategoryId('');
  };
  const filterControls = <>
    <Select label="收支筛选" value={type} onChange={(value) => applyType(value as TransactionType | '')} options={[{ value: '', label: '全部收支' }, { value: 'expense', label: '仅支出' }, { value: 'income', label: '仅收入' }]} />
    <Select label="分类筛选" value={categoryId} onChange={setCategoryId} options={[{ value: '', label: '全部分类' }, ...categories.filter((category) => !category.mergedIntoId&&(!type || category.type === type)).map((category) => ({ value: category.id, label: category.name + (category.name === '其他' ? ' · ' + (category.type === 'expense' ? '支出' : '收入') : '') }))]} />
    <Select label="币种筛选" value={currency} onChange={(value) => setCurrency(value as Currency | '')} options={[{ value: '', label: '全部币种' }, { value: 'HKD', label: '港币 HKD' }, { value: 'CNY', label: '人民币 CNY' }]} />
  </>;
  const empty = <div className="empty-state">
    <img className="dime-empty-icon" src="./dime/empty.svg" width="64" height="64" alt="" />
    <h3>{hasFilters ? '没有符合条件的记录' : '本月暂无记录'}</h3>
    {hasFilters ? <button className="button secondary" onClick={clear}>清除筛选</button> : <>
      <button className="button primary" onClick={onNew}><Plus size={17} />添加记录</button>
      <button className="text-button demo-link" onClick={onDemo}>查看示例</button>
    </>}
  </div>;
  const searchInput = <label className="dime-search"><Search size={17} aria-hidden="true" /><input type="search" aria-label="搜索记录" placeholder="搜索记录" value={query} onChange={(event) => setQuery(event.target.value)} /></label>;
  const status = <FxStatus status={{ ...fxStatus, missing: missingRateDates(filtered, preferred, rates) }} onManage={onRates} />;

  if (isAndroid) {
    const activeCount = Number(Boolean(type)) + Number(Boolean(categoryId)) + Number(Boolean(currency));
    const actionTarget = !demo && actionId ? filtered.find((row) => row.id === actionId) : undefined;
    return <>
      <AndroidSummary report={summary} preferred={preferred} selected={type} onFilter={(value) => applyType(type === value ? '' : value)} />
      {transactions.length > 0 && status}
      <section className="mobile-ledger" aria-label="交易明细">
        <div className="mobile-ledger-toolbar">{searchInput}
          <button type="button" className="mobile-filter-trigger" onClick={() => setFilterSheet(true)}><SlidersHorizontal size={17} />筛选{activeCount > 0 && <span>{activeCount}</span>}</button>
        </div>
        {filtered.length ? days.map((day) => {
          const rows = filtered.filter((transaction) => transaction.occurredOn === day);
          const { label } = formatDay(day);
          const total = summarizeConverted(rows, preferred, rates);
          return <section className="mobile-day" key={day} aria-label={day}>
            <header className="mobile-day-heading">
              <h2><time dateTime={day}>{['今天', '昨天'].includes(label) ? label : `${Number(day.slice(5, 7))}月${Number(day.slice(8))}日`}</time>
                {['今天', '昨天'].includes(label) && <small>{day.slice(5).replace('-', '/')}</small>}</h2>
              <strong className={`money daily-net${total.net === null ? ' pending' : ''}`} aria-label="当日结余">{total.net === null ? '待补汇率' : <Money minor={total.net} currency={preferred} positive />}</strong>
            </header>
            <div className="mobile-day-rows">{rows.map((transaction) => {
              const amount = convertedMinor(transaction, preferred, rateMap);
              return <AndroidLedgerRow key={transaction.id} transaction={transaction} category={categoryMap.get(transaction.categoryId)}
                preferred={preferred} converted={amount === null ? null : roundMinor(amount)} readOnly={demo} onActions={(row) => setActionId(row.id)} />;
            })}</div>
          </section>;
        }) : empty}
      </section>
      {filterSheet && <Modal title="筛选记录" className="mobile-sheet" onClose={() => setFilterSheet(false)}>
        <div className="mobile-sheet-content mobile-ledger-filters">{filterControls}</div>
        <footer className="modal-footer"><button className="button secondary" type="button" disabled={!activeCount} onClick={() => { applyType(''); setCategoryId(''); setCurrency(''); }}>重置</button><button className="button primary" type="button" onClick={() => setFilterSheet(false)}>查看 {filtered.length} 笔</button></footer>
      </Modal>}
      {actionTarget && <AndroidRecordActions transaction={actionTarget} category={categoryMap.get(actionTarget.categoryId)}
        onClose={() => setActionId(null)}
        onEdit={() => { setActionId(null); onEdit(actionTarget); }}
        onDelete={() => { setActionId(null); onDelete(actionTarget); }} />}
    </>;
  }

  return <>
    {transactions.length > 0 && <><SummaryCards report={summary} preferred={preferred}
      onFilter={(nextType) => { setType(nextType); if (categoryId && categoryMap.get(categoryId)?.type !== nextType) setCategoryId(''); }} />
      {status}</>}

    <section className="dime-log" aria-label="交易明细">
      <div className="dime-log-toolbar">
        {searchInput}
        <div className="filters" aria-label="筛选交易">
          {filterControls}
          {hasFilters && <button className="icon-button" aria-label="清除筛选" onClick={clear}><X size={15} /></button>}
        </div>
      </div>

      {filtered.length ? <div className="dime-transaction-groups">
        {days.map((day) => {
          const rows = filtered.filter((transaction) => transaction.occurredOn === day);
          const formatted = formatDay(day);
          const total = summarizeConverted(rows, preferred, rates);
          return <section className="dime-day-group" key={day} aria-label={day}>
            <header className="dime-day-heading">
              <h3><time dateTime={day}>{formatted.label}</time><span>{['今天', '昨天'].includes(formatted.label) ? day.slice(5).replace('-', ' / ') : formatted.secondary.split(' · ')[1]}</span></h3>
              <div className="dime-day-totals" aria-label="当日折算结余"><span className="day-total-label">当日结余</span><strong className={`money daily-net${total.net === null ? ' pending' : ''}`}>{total.net === null ? '待补汇率' : <Money minor={total.net} currency={preferred} positive />}</strong></div>
            </header>
            {rows.map((transaction) => {
              const amount = convertedMinor(transaction, preferred, rateMap);
              return <DimeTransactionRow key={transaction.id} transaction={transaction} converted={amount === null ? null : roundMinor(amount)} reportCurrency={preferred}
                category={categoryMap.get(transaction.categoryId)} readOnly={demo} onEdit={onEdit} onDelete={onDelete} />;
            })}
          </section>;
        })}
      </div> : empty}
    </section>
  </>;
}

