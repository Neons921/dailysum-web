/** GPL-3.0. Desktop port of Dime SettingsView's grouped rows; iOS-only rows omitted. */
import type { Category, Currency, FxRate, Transaction, UserSettings } from '../domain/models';
import { Archive, ArrowLeftRight, CalendarDays, ChartColumn, ChevronRight, Coins, Database, GitBranch as Github, History, Import } from 'lucide-react';
import { latestRates } from '../domain/fx';
import { DimeSettingsLabel } from '../dime/DimeSettingsLabel';
import { CategoryIcon } from '../components/CategoryIcon';
import { CurrencyToggle } from '../components/CurrencyToggle';
import type { DataMode } from '../components/DataManager';
import type { SyncState } from '../services/syncService';

export function SettingsPage({ settings, categories, transactions, onSettingsChange, busy, rates, onRates, onData, sync }: {
  settings: UserSettings;
  categories: Category[];
  transactions: Transaction[];
  onSettingsChange: (patch: Partial<UserSettings>) => void;
  busy: boolean;
  rates: FxRate[];
  onRates: () => void;
  onData: (mode:DataMode|'export') => void;
  sync: SyncState;
}) {
  const change = (field: 'inputCurrency' | 'reportCurrency') => (currency: Currency) => onSettingsChange({ [field]: currency });
  const syncLabel=!sync.connected?sync.status==='error'?'需重新连接':'未连接':sync.status==='error'||sync.status==='review'?'待处理':sync.status==='checking'||sync.status==='syncing'?'同步中':sync.status==='pending'?'等待同步':sync.status==='offline'?'等待联网':'已连接';
  return <div className="settings-page">
    <section className="settings-section"><div className="section-title"><h2>币种与日期</h2></div>
      <div className="setting-row"><DimeSettingsLabel icon={<Coins size={16} />} color="#6FD298" title="默认记账币种" detail="保存后记住最近使用的币种。" /><CurrencyToggle value={settings.inputCurrency} onChange={change('inputCurrency')} label="默认记账币种" compact disabled={busy} /></div>
      <div className="setting-row"><DimeSettingsLabel icon={<ChartColumn size={16} />} color="#6E7BF1" title="默认报表币种" detail="明细与统计按每日汇率统一折算。" /><CurrencyToggle value={settings.reportCurrency} onChange={change('reportCurrency')} label="默认报表币种" compact disabled={busy} /></div>
      <button className="setting-row fx-setting-button" onClick={() => onRates()}><DimeSettingsLabel icon={<ArrowLeftRight size={16} />} color="#E8AA50" title="每日汇率" detail="ECB 参考价 · 本地缓存与手动补录" /><span className="setting-value">{latestRates(rates).size} 天<ChevronRight size={15} /></span></button>
      <div className="setting-row"><DimeSettingsLabel icon={<CalendarDays size={16} />} color="#EC7A58" title="记账时区" /><span className="setting-value">香港 · UTC+08:00</span></div>
    </section>
    <section className="settings-section"><div className="section-title"><h2>分类</h2><span className="subtle-badge">{categories.length}</span></div>
      {(['expense', 'income'] as const).map((type) => <div className="settings-categories" key={type}><h3>{type === 'expense' ? '支出' : '收入'}</h3><div>{categories.filter((category) => category.type === type).map((category) => <span key={category.id} className="settings-category"><CategoryIcon category={category} size={14} />{category.name}</span>)}</div></div>)}
    </section>
    <section className="settings-section"><div className="section-title"><h2>数据</h2></div>
      <div className="setting-row"><DimeSettingsLabel icon={<Database size={16} />} color="#6E7BF1" title="本地记录" /><span className="setting-value">{transactions.filter((transaction) => !transaction.deletedAt).length} 笔</span></div>
      <button className="setting-row fx-setting-button" onClick={()=>onData('sync')}><DimeSettingsLabel icon={<Github size={16} />} color="#638095" title="GitHub 同步" detail={sync.profile?.lastSyncAt?`最近同步 ${new Date(sync.profile.lastSyncAt).toLocaleString('zh-CN',{timeZone:'Asia/Hong_Kong'})}`:undefined}/><span className="setting-value">{syncLabel}<ChevronRight size={15}/></span></button>
      <button className="setting-row fx-setting-button" onClick={()=>onData('import')}><DimeSettingsLabel icon={<Import size={16} />} color="#77937D" title="导入账目" detail="Cent 文件、Cent 仓库与 DailySum 备份"/><ChevronRight size={15}/></button>
      <button className="setting-row fx-setting-button" onClick={()=>onData('export')}><DimeSettingsLabel icon={<Archive size={16} />} color="#A6678A" title="导出备份" detail="完整账目、汇率、过滤器与来源归档"/><span className="setting-value">JSON<ChevronRight size={15}/></span></button>
      <button className="setting-row fx-setting-button" onClick={()=>onData('restore')}><DimeSettingsLabel icon={<History size={16} />} color="#A88960" title="本地恢复点"/><ChevronRight size={15}/></button>
      <p className="storage-note">本地账目保存在此浏览器。GitHub 同步需连接私有仓库；清除站点数据前请导出备份。</p>
    </section>
    <footer className="settings-version">DailySum <span>0.1.0</span></footer>
    <p className="dime-attribution">基于 <a href="https://github.com/rafsoh/dimeApp" target="_blank" rel="noreferrer">Dime · Rafael Soh 及贡献者</a> 的界面源码移植 · <a href="./dime/LICENSE.txt" target="_blank" rel="noreferrer">GPL-3.0</a>{import.meta.env.PROD && <> · <a href="./dailysum-source.zip" download>源代码</a></>}</p>
  </div>;
}

