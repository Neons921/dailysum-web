import { useLayoutEffect, useMemo, useRef, useState, type KeyboardEvent } from 'react';
import { ArrowDownRight, ArrowUpRight, LocateFixed, Plus, ReceiptText } from 'lucide-react';
import { AndroidLedgerRow } from '../android/AndroidLedgerRow';
import { AndroidRecordActions } from '../android/AndroidRecordActions';
import { isAndroid } from '../app/android';
import { MonthNavigator } from '../components/DatePicker';
import { FxStatus, type FxStatusData } from '../components/FxStatus';
import { Money } from '../components/Money';
import { DimeTransactionRow } from '../dime/DimeTransactionRow';
import { formatMonth, offsetDay } from '../domain/dates';
import { convertedMinor, latestRates, roundMinor } from '../domain/fx';
import type { Category, Currency, FxRate, Transaction } from '../domain/models';
import { CURRENCY_META, formatMoney } from '../domain/money';
import type { ReportTotal } from '../domain/reports';
import { calendarWeeks, spendingCalendar } from '../domain/spendingCalendar';

const fullDate = new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' });
const weekday = new Intl.DateTimeFormat('zh-CN', { weekday: 'long', timeZone: 'UTC' });
const weekdays = ['一', '二', '三', '四', '五', '六', '日'];
const arrowDays: Record<string, number | undefined> = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 };

function CalendarAmount({ total, currency }: { total?: ReportTotal; currency: Currency }) {
  return total?.missing ? <span className="calendar-pending">待折算</span> : <Money minor={total?.amount ?? 0n} currency={currency} />;
}

export function CalendarPage({ date, today, onDate, onMonth, transactions, categories, currency, rates, fxStatus, onRates, demo, onNew, onEdit, onDelete }: {
  date: string;
  today: string;
  onDate: (date: string) => void;
  onMonth: (month: string) => void;
  transactions: Transaction[];
  categories: Category[];
  currency: Currency;
  rates: FxRate[];
  fxStatus: FxStatusData;
  onRates: (date?: string) => void;
  demo: boolean;
  onNew: (date: string) => void;
  onEdit: (transaction: Transaction) => void;
  onDelete: (transaction: Transaction) => void;
}) {
  const month = date.slice(0, 7);
  const weeks = useMemo(() => calendarWeeks(month), [month]);
  const calendar = useMemo(() => spendingCalendar(month, transactions, currency, rates), [month, transactions, currency, rates]);
  const rateMap = useMemo(() => latestRates(calendar.monthlyRates), [calendar.monthlyRates]);
  const selected = calendar.days.get(date);
  const selectedDate = new Date(`${date}T12:00:00Z`);
  const records = [...(selected?.records ?? [])].sort((a, b) => b.createdAt.localeCompare(a.createdAt) || a.id.localeCompare(b.id));
  const categoryMap = new Map(categories.map((category) => [category.id, category]));
  const [actionId, setActionId] = useState<string | null>(null);
  const actionTarget = !demo && actionId ? records.find((row) => row.id === actionId) : undefined;
  const grid = useRef<HTMLTableElement>(null);
  const pendingFocus = useRef<string | null>(null);

  useLayoutEffect(() => {
    if (pendingFocus.current !== date) return;
    pendingFocus.current = null;
    grid.current?.querySelector<HTMLButtonElement>(`button[data-date="${date}"]`)?.focus();
  }, [date]);

  const moveDate = (event: KeyboardEvent<HTMLButtonElement>, from: string) => {
    const offset = arrowDays[event.key];
    if (offset === undefined) return;
    event.preventDefault();
    const nextDate = offsetDay(from, offset);
    pendingFocus.current = nextDate;
    onDate(nextDate);
  };

  return <div className="spending-calendar">
    <section className="calendar-heatmap" aria-labelledby="calendar-month-total">
      <div className="calendar-toolbar">
        <MonthNavigator label="日历月份" value={month} onChange={onMonth} />
        <button className="calendar-today" type="button" aria-label="回到今天" onClick={() => onDate(today)}><LocateFixed size={15} aria-hidden="true" />今天</button>
      </div>
      <div className="calendar-overview">
        <div>
          <h2 id="calendar-month-total">{month === today.slice(0, 7) ? '本月支出' : '月度支出'}</h2>
          <strong className="calendar-month-amount"><CalendarAmount total={calendar.expense} currency={currency} /></strong>
        </div>
        <span className="calendar-active-days"><strong>{calendar.spendingDays}</strong> 天有支出</span>
      </div>
      <table className="calendar-days" role="grid" aria-label={`${formatMonth(month)}消费日历`} ref={grid}>
        <thead><tr>{weekdays.map((name) => <th key={name} scope="col" aria-label={`星期${name}`}>{name}</th>)}</tr></thead>
        <tbody>{weeks.map((week, index) => <tr key={index}>{week.map((day, column) => {
          if (!day) return <td key={column} className="calendar-blank" aria-hidden="true" />;
          const activity = calendar.days.get(day);
          const expense = activity?.report.expense;
          const pending = Boolean(expense?.missing);
          const amount = expense?.count && !pending ? formatMoney(expense.amount, currency) : '';
          const description = pending ? '支出待折算' : amount ? `支出 ${amount}` : '无支出';
          const name = `${fullDate.format(new Date(`${day}T12:00:00Z`))}，${description}，${activity?.records.length ?? 0} 笔记录`;
          return <td key={column} aria-selected={day === date}>
            <button className="calendar-day" type="button" data-date={day} data-heat={activity?.heat ?? 0} data-pending={pending}
              tabIndex={day === date ? 0 : -1} aria-current={day === today ? 'date' : undefined} aria-label={name} title={name}
              onClick={() => onDate(day)} onKeyDown={(event) => moveDate(event, day)}>
              <span className="calendar-day-number" aria-hidden="true">{Number(day.slice(8))}</span>
              {Boolean(activity?.report.income.count) && <i className="calendar-income-dot" aria-hidden="true" />}
              {pending ? <span className="calendar-day-amount" aria-hidden="true">待折算</span> : amount && <span className="calendar-day-amount" aria-hidden="true">{amount.slice(CURRENCY_META[currency].symbol.length + 1)}</span>}
              <span className="calendar-day-mark" aria-hidden="true" />
            </button>
          </td>;
        })}</tr>)}</tbody>
      </table>
      <div className="calendar-key" aria-hidden="true">
        <span>支出少</span><div className="calendar-scale">{[0, 1, 2, 3, 4].map((heat) => <i key={heat} data-heat={heat} />)}</div><span>多</span>
        {[...calendar.days.values()].some(({ report }) => report.income.count) && <span className="calendar-income-key"><i />有收入</span>}
      </div>
      {fxStatus.missing.length > 0 && <FxStatus status={fxStatus} onManage={onRates} />}
    </section>

    <section className="calendar-detail" aria-labelledby="calendar-detail-title">
      <header className="calendar-detail-header">
        <div>
          <h2 id="calendar-detail-title" aria-live="polite"><time dateTime={date}>{Number(date.slice(5, 7))}月{Number(date.slice(8))}日</time></h2>
          <p>{weekday.format(selectedDate)}{date === today && <span className="calendar-today-label">今天</span>}</p>
        </div>
        {!demo && <button type="button" className="calendar-add" aria-label="在所选日期记一笔" onClick={() => onNew(date)}><Plus size={17} aria-hidden="true" />记一笔</button>}
      </header>
      <dl className="calendar-day-totals">
        <div><dt><ArrowDownRight size={14} aria-hidden="true" />支出</dt><dd><CalendarAmount total={selected?.report.expense} currency={currency} /></dd></div>
        <div><dt><ArrowUpRight size={14} aria-hidden="true" />收入</dt><dd><CalendarAmount total={selected?.report.income} currency={currency} /></dd></div>
      </dl>
      {records.length ? <ul className="calendar-records" aria-label="当天记录">{records.map((transaction) => {
        const category = categoryMap.get(transaction.categoryId);
        const amount = convertedMinor(transaction, currency, rateMap);
        const converted = amount === null ? null : roundMinor(amount);
        return <li key={transaction.id}>{isAndroid ? <AndroidLedgerRow transaction={transaction} category={category} converted={converted} preferred={currency}
          readOnly={demo} onActions={(row) => setActionId(row.id)} /> : <DimeTransactionRow transaction={transaction} category={category} converted={converted} reportCurrency={currency}
          readOnly={demo} onEdit={onEdit} onDelete={onDelete} />}</li>;
      })}</ul> : <div className="calendar-empty"><span><ReceiptText size={19} aria-hidden="true" /></span><p>当天暂无记录</p></div>}
    </section>
    {actionTarget && <AndroidRecordActions transaction={actionTarget} category={categoryMap.get(actionTarget.categoryId)}
      onClose={() => setActionId(null)} onEdit={() => { setActionId(null); onEdit(actionTarget); }} onDelete={() => { setActionId(null); onDelete(actionTarget); }} />}
  </div>;
}
