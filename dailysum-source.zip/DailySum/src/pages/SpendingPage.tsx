import { useState } from 'react';
import { ArrowDownRight, ArrowLeftRight, ArrowUpRight, ChevronDown, Minus } from 'lucide-react';
import { CategoryIcon } from '../components/CategoryIcon';
import { FxStatus, type FxStatusData } from '../components/FxStatus';
import { Money } from '../components/Money';
import type { DateRange } from '../domain/dates';
import type { Category, Currency, FxRate, Transaction, TransactionType } from '../domain/models';
import { changePercent, type ReportTotal } from '../domain/reports';
import { RANKING_LIMITS, spendingAnalysis, TOP_EXPENSE_COUNT, type RankingLimit, type spendingPeriods } from '../domain/spendingAnalysis';

type Comparison = { current: ReportTotal; previous: ReportTotal };
const shortDay = (date: string) => `${Number(date.slice(5, 7))}/${Number(date.slice(8, 10))}`;

function Dates({ range, year = false }: { range: DateRange; year?: boolean }) {
  return <><time dateTime={range.from}>{year ? `${range.from.slice(0, 4)}/` : ''}{shortDay(range.from)}</time>{range.from !== range.to && <> – <time dateTime={range.to}>{shortDay(range.to)}</time></>}</>;
}

function Total({ value, currency }: { value: ReportTotal; currency: Currency }) {
  return value.missing ? <span className="analysis-pending">待折算</span> : <Money minor={value.amount} currency={currency} />;
}

function Difference({ current, previous, currency, type = 'expense' }: Comparison & { currency: Currency; type?: TransactionType }) {
  if (current.missing || previous.missing) return <span className="analysis-delta" data-change="even">补齐汇率后可比较</span>;
  const income = type === 'income';
  const delta = current.amount - previous.amount;
  if (!delta) return <span className="analysis-delta" data-change="even"><Minus size={14} aria-hidden="true" />{current.count || previous.count ? '持平' : `两期均无${income ? '收入' : '支出'}`}</span>;
  const increased = delta > 0n;
  const Icon = increased ? ArrowUpRight : ArrowDownRight;
  const percent = changePercent(current, previous);
  const label = income ? (increased ? '多收' : '少收') : (increased ? '多花' : '少花');
  return <span className="analysis-delta" data-change={increased ? 'up' : 'down'} data-type={type}><Icon size={14} aria-hidden="true" />{label} <Money minor={increased ? delta : -delta} currency={currency} />{percent && <span className="analysis-percent">({percent})</span>}</span>;
}

export function SpendingPage({ periods, current, previous, categories, preferred, rates, fxStatus, onRates, ranking }: {
  periods: ReturnType<typeof spendingPeriods>;
  current: Transaction[];
  previous: Transaction[];
  categories: Category[];
  preferred: Currency;
  rates: FxRate[];
  fxStatus: FxStatusData;
  onRates: (date?: string) => void;
  ranking: { type: TransactionType; onTypeChange: (type: TransactionType) => void };
}) {
  const [limits, setLimits] = useState<Record<TransactionType, RankingLimit>>({ expense: TOP_EXPENSE_COUNT, income: TOP_EXPENSE_COUNT });
  const { type, onTypeChange } = ranking;
  const limit = limits[type];
  const nextLimit = RANKING_LIMITS[(RANKING_LIMITS.indexOf(limit) + 1) % RANKING_LIMITS.length];
  const income = type === 'income';
  const rankingTitle = income ? '大额收入' : '大额消费';
  const typeLabel = income ? '收入' : '支出';
  const { total, largest, large, routine, categories: comparisons } = spendingAnalysis(current, previous, preferred, rates, { type, limit });
  const selectedLabel = periods.monthToDate ? '本月' : `${Number(periods.current.from.slice(5, 7))} 月`;
  const previousLabel = periods.monthToDate ? '上月同期' : `${Number(periods.previous.from.slice(5, 7))} 月`;
  const categoryMap = new Map(categories.map((category) => [category.id, category]));
  const comparable = comparisons.filter(({ current, previous }) => !current.missing && !previous.missing);
  const peak = Math.max(0, ...comparable.flatMap(({ current, previous }) => [current.raw.toNumber(), previous.raw.toNumber()]));

  return <div className="spending-analysis">
    <section className="analysis-overview" aria-labelledby="analysis-overview-title">
      <div className="analysis-heading"><h2 id="analysis-overview-title">{selectedLabel}支出</h2><span className="analysis-currency">{preferred}</span></div>
      <div>
        <strong className="analysis-main-total"><Total value={total.current} currency={preferred} /></strong>
        <p className="analysis-period"><Dates range={periods.current} year /> · {total.current.count} 笔</p>
      </div>
      <div className="analysis-compare">
        <div><span>{previousLabel}</span><small><Dates range={periods.previous} year={periods.current.from.slice(0, 4) !== periods.previous.from.slice(0, 4)} /></small></div>
        <strong><Total value={total.previous} currency={preferred} /></strong>
      </div>
      <Difference {...total} currency={preferred} />
    </section>
    <FxStatus status={fxStatus} onManage={onRates} />

    <section className="analysis-card" aria-labelledby="analysis-largest-title">
      <header className="analysis-heading analysis-ranking-controls">
        <h2 id="analysis-largest-title">
          <button className="analysis-rank-type" type="button" aria-description={income ? '切换至大额消费' : '切换至大额收入'}
            onClick={() => onTypeChange(income ? 'expense' : 'income')}>{rankingTitle}<ArrowLeftRight size={14} aria-hidden="true" /></button>
        </h2>
        <button className="analysis-rank-limit" type="button" aria-description={`切换至 ${nextLimit} 笔`}
          onClick={() => setLimits({ ...limits, [type]: nextLimit })}>金额最高 {limit} 笔<ChevronDown size={13} aria-hidden="true" /></button>
      </header>
      {(large.current.count > 0 || large.previous.count > 0) && <>
        <div className="analysis-card-total"><strong><Total value={large.current} currency={preferred} /></strong><Difference {...large} currency={preferred} type={type} /></div>
        <p className="analysis-period">前 {limit} 笔合计 · {previousLabel} <Total value={large.previous} currency={preferred} /></p>
      </>}
      {large.current.missing ? <p className="analysis-empty">有 {large.current.missing} 笔{typeLabel}待折算，补齐汇率后显示排名。</p>
        : largest.length === 0 ? <p className="analysis-empty">{selectedLabel}暂无{typeLabel}</p>
        : <ol className="analysis-expenses">{largest.map(({ transaction, amount }) => {
          const category = categoryMap.get(transaction.categoryId);
          return <li className="mobile-report-row" key={transaction.id}>
            <CategoryIcon category={category} size={17} />
            <span className="mobile-row-title"><strong>{transaction.note || category?.name || '其他'}</strong>
              <small><time dateTime={transaction.occurredOn}>{shortDay(transaction.occurredOn)}</time>{transaction.note && category && <> · {category.name}</>}</small></span>
            <span className="mobile-row-amount"><strong><Money minor={amount} currency={preferred} /></strong>
              {transaction.currency !== preferred && <small><Money minor={transaction.amountMinor} currency={transaction.currency} /></small>}</span>
          </li>;
        })}</ol>}
    </section>

    <section className="analysis-card" aria-labelledby="analysis-routine-title">
      <header className="analysis-heading"><h2 id="analysis-routine-title">日常花费</h2><small>餐饮与交通</small></header>
      <div className="analysis-card-total"><strong><Total value={routine.current} currency={preferred} /></strong><Difference {...routine} currency={preferred} /></div>
      <ul className="analysis-routine-list">{comparisons.map(({ id, current, previous }) => {
        const category = categoryMap.get(id);
        return <li key={id}>
          <div className="analysis-category-title"><CategoryIcon category={category} size={15} /><h3>{category?.name ?? (id === 'food' ? '餐饮' : '交通')}</h3><Difference current={current} previous={previous} currency={preferred} /></div>
          <div className="analysis-category-periods">{([[current, selectedLabel], [previous, previousLabel]] as const).map(([value, label]) => <div key={label}>
            <span>{label}</span><strong><Total value={value} currency={preferred} /></strong>
            {peak > 0 && !current.missing && !previous.missing && <span className="analysis-bar" aria-hidden="true"><i style={{ width: `${value.raw.toNumber() / peak * 100}%` }} /></span>}
          </div>)}</div>
        </li>;
      })}</ul>
    </section>
  </div>;
}
