import { useEffect, useState } from 'react';
import { ArrowDownUp, ArrowLeft, ArrowRight, BarChart3, Bookmark, Check, ChevronDown, CircleMinus, ListFilter, Pencil, Plus, RotateCcw, Search, SlidersHorizontal, Trash2, X } from 'lucide-react';
import type { Category, Currency, FxRate, Transaction, TransactionType } from '../domain/models';
import { isValidDate } from '../domain/models';
import { hongKongToday, offsetDay, previousRange, rangeDays, reportPeriodPresets, type DateRange } from '../domain/dates';
import { Money } from '../components/Money';
import { convertedMinor, latestRates, roundMinor } from '../domain/fx';
import { categoryTotals, changePercent, defaultGrain, selectReportTransactions, summarizeSelection, trendPoints, type Grain, type ReportFilters } from '../domain/reports';
import { emptyReportRules, hasReportRules, ruleDescriptions, type FilterPreferences, type ReportRules, type SavedReportFilter } from '../domain/reportFilters';
import { summarizeOriginal } from '../domain/summary';
import { describeError } from '../services/errors';
import { SummaryCards } from '../components/SummaryCards';
import { FxStatus, type FxStatusData } from '../components/FxStatus';
import { TrendChart, CategoryChart } from '../dime/DimeCharts';
import { CategoryIcon } from '../components/CategoryIcon';
import { Select } from '../components/Select';
import { DateRangePicker } from '../components/DatePicker';
import { ReportFilterDialog } from '../components/ReportFilterDialog';
import { ConfirmDialog, Modal } from '../components/Modal';
import { isAndroid } from '../app/android';
import { AndroidSummary } from '../android/AndroidSummary';
import { AndroidCategoryBreakdown } from '../android/AndroidCategoryBreakdown';

export function ReportsPage({ transactions, categories, preferred, rates, filters, onFilters, fxStatus, onRates, preferences, onApplyRules, onSaveRules, onRemoveFilter }: {
  transactions: Transaction[]; categories: Category[]; preferred: Currency; rates: FxRate[];
  filters: ReportFilters; onFilters: (filters: ReportFilters) => void;
  fxStatus: FxStatusData; onRates: (date?: string) => void; preferences: FilterPreferences;
  onApplyRules: (rules: ReportRules | undefined, viewId?: string | null) => Promise<void>;
  onSaveRules: (name: string, rules: ReportRules, previous?: SavedReportFilter) => Promise<void>;
  onRemoveFilter: (record: SavedReportFilter) => Promise<void>;
}) {
  const [mode, setMode] = useState<'bar' | 'line'>('bar');
  const [grain, setGrain] = useState<Grain | ''>('');
  const [chartType, setChartType] = useState<TransactionType | ''>('expense');
  const [categoryType, setCategoryType] = useState<TransactionType>('expense');
  const [detailRange, setDetailRange] = useState<DateRange | null>(null);
  const [limit, setLimit] = useState(10);
  const [editing, setEditing] = useState<{ rules?: ReportRules; previous?: SavedReportFilter } | null>(null);
  const [deleteView, setDeleteView] = useState<SavedReportFilter | null>(null);
  const [pageError, setPageError] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [periodPresetId, setPeriodPresetId] = useState<string>();
  const [detailMode, setDetailMode] = useState<'matched' | 'excluded' | 'pending'>('matched');
  const [sort, setSort] = useState<'date' | 'amount'>('date');
  const [ascending, setAscending] = useState(false);
  const [filterSheet, setFilterSheet] = useState(false);
  const patch = (value: Partial<ReportFilters>) => onFilters({ ...filters, ...value });
  const today = hongKongToday();
  const rangeError = !isValidDate(filters.from) || !isValidDate(filters.to) || filters.from > filters.to ? '开始日期须早于或等于结束日期' : rangeDays(filters) > 3660 ? '单次统计最多支持 10 年，请缩小日期范围' : '';
  const days = rangeError ? 0 : rangeDays(filters);
  const selection = rangeError ? { matched: [], excluded: [], pending: [] } : selectReportTransactions(transactions, filters, categories, rates);
  const filtered = selection.matched;
  const report = summarizeSelection(selection, preferred, rates);
  const previous = rangeError ? null : summarizeSelection(selectReportTransactions(transactions, { ...filters, ...previousRange(filters) }, categories, rates), preferred, rates);
  const resolvedGrain = grain && !(grain === 'day' && days > 120) && !(grain === 'week' && days > 730) ? grain : defaultGrain(filters);
  const resolvedType = filters.type || filters.rules?.type || chartType;
  const resolvedCategoryType = filters.type || filters.rules?.type || categoryType;
  const points = rangeError ? [] : trendPoints(filtered, filters, resolvedGrain, preferred, rates);
  const breakdown = categoryTotals(filtered, categories, resolvedCategoryType, preferred, rates);
  const totals = summarizeOriginal(filtered);
  const categoryMap = new Map(categories.map((category) => [category.id, category]));
  const rateMap = latestRates(rates);
  const hasFilters = Boolean(filters.type || filters.currency || filters.categoryId || filters.query || hasReportRules(filters.rules));
  const activeView = preferences.views.find((view) => view.id === preferences.activeId);
  const modified = Boolean(activeView && JSON.stringify(activeView.rules) !== JSON.stringify(filters.rules));
  const descriptions = ruleDescriptions(filters.rules, categories);
  const detailSource = detailMode === 'excluded' ? selection.excluded : (detailMode === 'pending' ? selection.pending : filtered).map((transaction) => ({ transaction, reason: detailMode === 'pending' ? '金额条件待汇率校验' : '' }));
  const detailRows = detailSource.filter(({ transaction: row }) => !detailRange || row.occurredOn >= detailRange.from && row.occurredOn <= detailRange.to).sort((a, b) => {
    let result = a.transaction.occurredOn.localeCompare(b.transaction.occurredOn) || a.transaction.createdAt.localeCompare(b.transaction.createdAt);
    if (sort === 'amount') {
      const left = convertedMinor(a.transaction, preferred, rateMap), right = convertedMinor(b.transaction, preferred, rateMap);
      if (left === null && right !== null) return 1;
      if (left !== null && right === null) return -1;
      result = left && right ? left.comparedTo(right) : result;
    }
    return (ascending ? result : -result) || a.transaction.id.localeCompare(b.transaction.id);
  });
  const filterKey = JSON.stringify(filters);
  useEffect(() => { setDetailRange(null); setLimit(10); setDetailMode('matched'); }, [filterKey]);
  const run = (operation: Promise<void>) => { setPageError(''); void operation.catch((cause) => setPageError(describeError(cause))); };
  const presets = reportPeriodPresets(today);
  const matchingPeriods = presets.filter(({ range }) => range.from === filters.from && range.to === filters.to).map(({ id }) => id);
  const activePeriod = matchingPeriods.includes(periodPresetId ?? '') ? periodPresetId : matchingPeriods[0];
  const shiftRange = (direction: number) => { if (days) patch({ from: offsetDay(filters.from, days * direction), to: offsetDay(filters.to, days * direction) }); };
  const toggleSort = (key: 'date' | 'amount') => { setSort(key); setAscending(sort === key ? !ascending : false); };
  const excludeRow = (id: string, restore: boolean) => {
    const rules = structuredClone(filters.rules ?? emptyReportRules(preferred));
    rules.excludedTransactionIds = restore ? rules.excludedTransactionIds.filter((value) => value !== id) : [...new Set([...rules.excludedTransactionIds, id])];
    patch({ rules });
  };
  const presetControls = <div className="segment-control period-presets" role="group" aria-label="统计时间快捷选择">{presets.map(({ id, label, range }) => <button key={id} title={`${range.from} — ${range.to}`} aria-pressed={id === activePeriod} onClick={() => { setPeriodPresetId(id); patch(range); }}>{label}</button>)}</div>;
  const dateControls = <div className="report-date-range"><button className="icon-button" aria-label="上个统计期间" onClick={() => shiftRange(-1)}><ArrowLeft size={16} /></button><DateRangePicker value={filters} onChange={patch} calendarFocus={isAndroid} /><button className="icon-button" aria-label="下个统计期间" onClick={() => shiftRange(1)}><ArrowRight size={16} /></button></div>;
  const filterControls = <>
      <div className="saved-filter-views" aria-label="已保存过滤器"><button className={!activeView && !hasReportRules(filters.rules) ? 'active' : ''} onClick={() => run(onApplyRules(undefined))}>全部记录</button>{preferences.views.map((view) => <button key={view.id} className={activeView?.id === view.id ? 'active' : ''} aria-pressed={activeView?.id === view.id} onClick={() => run(onApplyRules(view.rules, view.id))}><Bookmark size={14} aria-hidden="true" />{view.name}{activeView?.id === view.id && modified && <small>未保存</small>}</button>)}<button className="create-filter-view" onClick={() => setEditing({})}><Plus size={14} />新建过滤器</button></div>
      <div className="report-secondary-filters">
        <Select label="统计收支筛选" value={filters.type} onChange={(value) => { const type = value as TransactionType | ''; patch({ type, ...(type && filters.categoryId && categoryMap.get(filters.categoryId)?.type !== type ? { categoryId: '' } : {}) }); }} options={[{ value: '', label: '全部收支' }, { value: 'expense', label: '仅支出' }, { value: 'income', label: '仅收入' }]} />
        <Select label="统计分类筛选" value={filters.categoryId} onChange={(id) => patch({ categoryId: id, ...(id ? { type: categoryMap.get(id)!.type } : {}) })} options={[{ value: '', label: '全部分类' }, ...categories.filter((category) => !category.mergedIntoId&&(!filters.type || filters.type === category.type)).map((category) => ({ value: category.id, label: category.name + (category.name === '其他' ? ` · ${category.type === 'income' ? '收入' : '支出'}` : '') }))]} />
        <Select label="统计原币筛选" value={filters.currency} onChange={(value) => patch({ currency: value as Currency | '' })} options={[{ value: '', label: '全部原币' }, { value: 'HKD', label: '港币 HKD' }, { value: 'CNY', label: '人民币 CNY' }]} />
        <button className={`filter-builder-button ${hasReportRules(filters.rules) ? 'has-rules' : ''}`} onClick={() => setEditing({ rules: filters.rules, previous: activeView })}><ListFilter size={16} />过滤器{descriptions.length > 0 && <span>{descriptions.length}</span>}</button>
        {activeView && <button className="icon-button" aria-label="删除当前过滤器" onClick={() => setDeleteView(activeView)}><Trash2 size={15} /></button>}
        <label className="dime-search report-search"><Search size={16} aria-hidden="true" /><input type="search" aria-label="搜索统计记录" placeholder="搜索备注、分类" value={filters.query} onChange={(event) => patch({ query: event.target.value })} /></label>
        {hasFilters && <button className="icon-button" aria-label="清除统计筛选" onClick={() => run(onApplyRules(undefined))}><X size={17} /></button>}
      </div>
      {descriptions.length > 0 && <div className="active-rule-chips" role="group" aria-label="当前过滤条件">{descriptions.map((text) => <button key={text} onClick={() => setEditing({ rules: filters.rules, previous: activeView })}>{text}<Pencil size={11} /></button>)}</div>}
  </>;
  const comparison = { expense: previous ? changePercent(report.expense, previous.expense) : null, income: previous ? changePercent(report.income, previous.income) : null };
  const metrics = <section className="report-metrics" aria-label="统计指标"><div><span>纳入统计</span><strong>{filtered.length}<small>笔</small></strong></div><div><span>日均支出</span><strong className="money">{report.expense.missing ? '待折算' : <Money minor={roundMinor(report.expense.raw.div(days || 1))} currency={preferred} />}</strong></div><div><span>最大单笔支出</span><strong className="money">{report.expense.missing ? '待折算' : <Money minor={report.maxExpense?.amount ?? 0n} currency={preferred} />}</strong>{report.maxExpense && <small className="metric-note">{report.maxExpense.transaction.occurredOn.slice(5).replace('-', '/')} {categoryMap.get(report.maxExpense.transaction.categoryId)?.name}</small>}</div><div><span>有记录天数</span><strong>{report.activeDays}<small>/ {days} 天</small></strong></div></section>;
  const filterByType = (type: TransactionType) => patch({ type: filters.type === type ? '' : type, categoryId: '' });
  const filterByCategory = (id: string) => patch({ categoryId: filters.categoryId === id ? '' : id, type: resolvedCategoryType });
  const detailAction = (row: Transaction, name?: string) => {
    if (detailMode === 'matched') return <button className="icon-button" aria-label={`从统计中排除${name}记录`} title="从统计中排除此笔" onClick={() => excludeRow(row.id, false)}><CircleMinus size={16} /></button>;
    if (filters.rules?.excludedTransactionIds.includes(row.id)) return <button className="icon-button" aria-label={`恢复纳入${name}记录`} title="恢复纳入统计" onClick={() => excludeRow(row.id, true)}><RotateCcw size={16} /></button>;
    return null;
  };
  const detailItems = detailRows.slice(0, limit).map(({ transaction: row, reason }) => {
    const category = categoryMap.get(row.categoryId);
    const amount = convertedMinor(row, preferred, rateMap);
    const sign = row.type === 'income' ? '+' : '−';
    const original = <Money minor={row.amountMinor} currency={row.currency} sign={sign} />;
    const converted = amount === null ? '待补汇率' : <Money minor={roundMinor(amount)} currency={preferred} sign={sign} />;
    const action = detailAction(row, row.note || category?.name);
    if (isAndroid) return <li className="mobile-report-row" key={row.id}>
      <CategoryIcon category={category} size={17} />
      <span className="mobile-row-title"><strong>{row.note || category?.name || '其他'}</strong>
        <small><time dateTime={row.occurredOn}>{row.occurredOn.slice(5).replace('-', '/')}</time>{row.note && category && <>　{category.name}</>}</small>
        {reason && <small>{reason}</small>}</span>
      <span className="mobile-row-amount"><strong className={`money ${row.type}`}>{original}</strong>
        {row.currency !== preferred && <small className="money">{amount === null ? converted : <>≈ {converted}</>}</small>}</span>
      {action}
    </li>;
    return <tr key={row.id}><td><time dateTime={row.occurredOn}>{row.occurredOn}</time></td><td><span className="report-row-category"><CategoryIcon category={category} size={17} /><span>{category?.name}<small title={row.note}>{row.note}</small></span></span></td><td className="money">{original}</td><td className={`money ${row.type === 'income' ? 'positive' : ''}`}>{converted}</td>{detailMode !== 'matched' && <td className="report-excluded-reason">{reason}</td>}<td className="report-row-action">{action}</td></tr>;
  });
  return <div className="reports-page">
    {isAndroid ? <>
      <div className="mobile-report-controls">
        {presetControls}
        <div className="mobile-report-date-row">
          {dateControls}
          <button type="button" className="mobile-report-filter-status" data-active={hasFilters} aria-label={hasFilters ? '筛选统计，已开启' : '筛选统计，未开启'} aria-haspopup="dialog" aria-expanded={filterSheet} onClick={() => setFilterSheet(true)}>
            <SlidersHorizontal size={19} aria-hidden="true" />{hasFilters && <span className="filter-status-check" aria-hidden="true"><Check size={9} strokeWidth={3} /></span>}
          </button>
        </div>
      </div>
      {filterSheet && <Modal title="筛选统计" className="mobile-sheet" onClose={() => setFilterSheet(false)}>
        <div className="mobile-sheet-content mobile-report-filters">{filterControls}{pageError && <p className="form-error" role="alert">{pageError}</p>}</div>
        <footer className="modal-footer"><button type="button" className="button primary" onClick={() => setFilterSheet(false)}>查看统计</button></footer>
      </Modal>}
    </> : <section className="report-filter-panel" aria-label="统计筛选"><div className="report-period-row">{presetControls}{dateControls}</div>{filterControls}</section>}
    {pageError && <p className="form-error" role="alert">{pageError}</p>}
    {rangeError ? <p className="form-error report-range-error" role="alert">{rangeError}</p> : <>
      {isAndroid ? <AndroidSummary report={report} preferred={preferred} comparisons={comparison} selected={filters.type} onFilter={filterByType} />
        : <SummaryCards report={report} preferred={preferred} comparisons={comparison} onFilter={filterByType} />}
      <FxStatus status={fxStatus} onManage={onRates} />
      {selection.pending.length > 0 && <div className="filter-pending-notice" role="status">{selection.pending.length} 笔记录的金额条件待汇率校验，统计结果暂不完整。<button className="text-button" onClick={() => onRates(selection.pending[0].occurredOn)}>补齐汇率</button></div>}
      {!isAndroid && metrics}
      <section className="chart-panel trend-panel" aria-label="收支趋势"><header className="chart-panel-heading"><div><h2>收支趋势</h2><span>{filters.from} — {filters.to}</span></div><div className="trend-tools">{!filters.type && !filters.rules?.type && <div className="segment-control chart-types" aria-label="趋势收支类型">{([['expense','支出'],['income','收入'],['','收支']] as const).map(([value,label]) => <button key={value} aria-pressed={chartType === value} onClick={() => setChartType(value)}>{label}</button>)}</div>}<div className="segment-control grain-control" aria-label="趋势时间粒度">{([['day','日'],['week','周'],['month','月']] as const).map(([value,label]) => <button key={value} aria-pressed={resolvedGrain === value} disabled={value === 'day' && days > 120 || value === 'week' && days > 730} onClick={() => setGrain(value)}>{label}</button>)}</div><button className={`chart-mode-button ${mode === 'bar' ? 'selected' : ''}`} aria-label="切换柱状图" aria-pressed={mode === 'bar'} onClick={() => setMode('bar')}><BarChart3 size={17} /></button><button className={`chart-mode-button ${mode === 'line' ? 'selected' : ''}`} aria-label="切换折线图" aria-pressed={mode === 'line'} onClick={() => setMode('line')}><svg width="17" height="17" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M2 15L7 8L11 11L18 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg></button></div></header>
        {(resolvedType ? report[resolvedType].missing : report.missing) ? <div className="chart-empty">缺少汇率，补齐后显示趋势图<button className="text-button" onClick={() => onRates(fxStatus.missing[0])}>查看与补录</button></div> : (resolvedType ? report[resolvedType].count : report.count) ? <TrendChart points={points} currency={preferred} mode={mode} type={resolvedType} onSelect={(point) => { setDetailRange({ from: point.from, to: point.to }); setDetailMode('matched'); setLimit(10); document.getElementById('report-details')?.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'start' }); }} /> : <div className="chart-empty"><BarChart3 size={30} /><span>这段时间暂无记录</span></div>}
      </section>
      <section className="chart-panel category-panel" aria-label="分类分析"><header className="chart-panel-heading"><div><h2>分类分析</h2><span>{resolvedCategoryType === 'expense' ? '支出' : '收入'}占比</span></div>{!filters.type && !filters.rules?.type && <div className="segment-control" aria-label="分类分析类型"><button aria-pressed={categoryType === 'expense'} onClick={() => setCategoryType('expense')}>支出</button><button aria-pressed={categoryType === 'income'} onClick={() => setCategoryType('income')}>收入</button></div>}{filters.categoryId && <button className="text-button" onClick={() => patch({ categoryId: '' })}>全部分类<X size={12} /></button>}</header>{report[resolvedCategoryType].missing ? <div className="chart-empty">补齐汇率后显示分类金额与占比</div> : breakdown.length ? isAndroid ? <AndroidCategoryBreakdown rows={breakdown} currency={preferred} onSelect={filterByCategory} /> : <CategoryChart rows={breakdown} currency={preferred} total={report[resolvedCategoryType].amount} onSelect={filterByCategory} /> : <div className="chart-empty">暂无{resolvedCategoryType === 'expense' ? '支出' : '收入'}记录</div>}</section>
      {isAndroid && metrics}
      <section className="chart-panel report-details" id="report-details" aria-label="统计明细"><header className="chart-panel-heading"><div><h2>统计明细<span className="detail-count">{detailRows.length} 笔</span></h2>{detailRange && <button className="text-button" onClick={() => setDetailRange(null)}>{detailRange.from === detailRange.to ? detailRange.from : `${detailRange.from} — ${detailRange.to}`}<X size={12} /></button>}</div><span className="detail-unit">折算币种 {preferred}</span></header>
        <div className="report-detail-tabs" aria-label="统计记录状态">{([['matched','已纳入',filtered.length],['excluded','已排除',selection.excluded.length],['pending','待校验',selection.pending.length]] as const).filter(([state,,count]) => state !== 'pending' || count > 0).map(([state,label,count]) => <button key={state} aria-pressed={detailMode === state} onClick={() => { setDetailMode(state); setDetailRange(null); setLimit(10); }}>{label}<span>{count}</span></button>)}{detailMode === 'excluded' && <small>仅从本次统计中排除，原始记录保留。</small>}</div>
        {detailRows.length ? <>{isAndroid ? <>
          <div className="mobile-report-sort" role="group" aria-label="排序">
            <button aria-pressed={sort === 'date'} onClick={() => toggleSort('date')}>日期 {sort === 'date' && (ascending ? '↑' : '↓')}</button>
            <button aria-pressed={sort === 'amount'} onClick={() => toggleSort('amount')}>折算金额 {sort === 'amount' && (ascending ? '↑' : '↓')}</button>
          </div>
          <ul className="mobile-report-list">{detailItems}</ul>
        </> : <><div className="report-table-wrap"><table className="report-table"><thead><tr><th aria-sort={sort === 'date' ? ascending ? 'ascending' : 'descending' : 'none'}><button onClick={() => toggleSort('date')}>日期<ArrowDownUp size={12} /></button></th><th>分类 / 备注</th><th>原币金额</th><th aria-sort={sort === 'amount' ? ascending ? 'ascending' : 'descending' : 'none'}><button onClick={() => toggleSort('amount')}>折算金额<ArrowDownUp size={12} /></button></th>{detailMode !== 'matched' && <th>原因</th>}<th><span className="sr-only">统计操作</span></th></tr></thead><tbody>{detailItems}</tbody></table></div><p className="table-scroll-hint">左右滑动查看金额</p></>}
        {detailRows.length > limit && <button className="report-load-more text-button" onClick={() => setLimit((value) => value + 20)}>显示更多（剩余 {detailRows.length - limit} 笔）<ChevronDown size={14} /></button>}</> : <div className="chart-empty">没有符合条件的记录</div>}
      </section>
      <details className="original-totals"><summary>原币小计<span>{filtered.length} 笔</span></summary><div className="original-totals-grid">{(['HKD','CNY'] as const).map((currency) => <div key={currency}><h3>{currency}<span>{totals[currency].count} 笔</span></h3><p><span>支出</span><strong className="money"><Money minor={totals[currency].expense} currency={currency} /></strong></p><p><span>收入</span><strong className="money"><Money minor={totals[currency].income} currency={currency} /></strong></p><p><span>结余</span><strong className="money"><Money minor={totals[currency].income-totals[currency].expense} currency={currency} /></strong></p></div>)}</div></details>
    </>}
    {editing && <ReportFilterDialog categories={categories} currency={preferred} rules={editing.rules} previous={editing.previous} onApply={(rules) => onApplyRules(rules,editing.previous?.id)} onSave={onSaveRules} onClose={() => setEditing(null)} />}
    {deleteView && <ConfirmDialog title={`删除“${deleteView.name}”？`} confirmLabel="删除过滤器" onClose={() => { if (!deleting) setDeleteView(null); }} busy={deleting} danger error={pageError} onConfirm={() => { setDeleting(true); setPageError(''); void onRemoveFilter(deleteView).then(() => setDeleteView(null)).catch((cause) => setPageError(describeError(cause))).finally(() => setDeleting(false)); }}><p>仅删除过滤条件，账目和汇率都会保留。</p></ConfirmDialog>}
  </div>;
}


