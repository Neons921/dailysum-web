import { useState } from 'react';
import { ArrowUpRight, ChevronRight, History, RefreshCw } from 'lucide-react';
import type { FxRate, Transaction } from '../domain/models';
import { hongKongToday } from '../domain/dates';
import { latestRates, MoneyDecimal, rateInputSchema } from '../domain/fx';
import { fxService, FX_SOURCE_URL } from '../services/fxService';
import { describeError } from '../services/errors';
import { Modal } from './Modal';
import { DatePicker } from './DatePicker';

type Pending = { candidate?: FxRate; manual?: string; expectedRevision: number };
export function FxManager({ records, transactions, initialDate, onChange, onClose, readOnly = false }: {
  records: FxRate[]; transactions: Transaction[]; initialDate?: string;
  onChange: (records: FxRate[]) => void; onClose: () => void; readOnly?: boolean;
}) {
  const [date, setDate] = useState(initialDate ?? hongKongToday());
  const [input, setInput] = useState('');
  const [candidate, setCandidate] = useState<FxRate | null>(null);
  const [pending, setPending] = useState<Pending | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const rates = latestRates(records);
  const current = rates.get(date);
  const history = records.filter((record) => record.rateDate === date).sort((a, b) => b.revision - a.revision);
  const affected = transactions.filter((row) => !row.deletedAt && row.occurredOn === date).length;
  const valid = rateInputSchema.safeParse(input.trim());
  const selectDate = (value: string) => { setDate(value); setCandidate(null); setPending(null); setInput(''); setError(''); setSuccess(''); };
  const lookup = async () => {
    setBusy(true); setError(''); setSuccess(''); setCandidate(null);
    try { setCandidate(await fxService.candidate(date)); }
    catch (cause) { setError(describeError(cause)); }
    finally { setBusy(false); }
  };
  const commit = async (change: Pending) => {
    setBusy(true); setError('');
    try {
      const result = change.candidate ? await fxService.saveCandidate(change.candidate, change.expectedRevision)
        : await fxService.saveManual(date, change.manual!, change.expectedRevision);
      onChange(result); setPending(null); setCandidate(null); setInput(''); setSuccess('汇率已保存，报表已重新计算');
    } catch (cause) { setError(describeError(cause)); }
    finally { setBusy(false); }
  };
  const propose = (change: Omit<Pending, 'expectedRevision'>) => {
    const revision = { ...change, expectedRevision: current?.revision ?? 0 };
    setSuccess(''); setError('');
    if (current) setPending(revision);
    else void commit(revision);
  };
  return <Modal title="每日汇率" subtitle="1 CNY 兑换 HKD" className="fx-modal" onClose={onClose} busy={busy}>
    <div className="fx-manager-body">
      {readOnly && <p className="fx-readonly">示例账本 · 汇率只读</p>}
      <div className="fx-date-row"><div><label htmlFor="fx-date">适用日期</label><DatePicker id="fx-date" label="汇率日期" value={date} onChange={selectDate} disabled={busy} /></div>
        <button className="button secondary" onClick={() => { void lookup(); }} disabled={busy || !date || date > hongKongToday()}><RefreshCw size={14} className={busy ? 'spin' : ''} />查询参考价</button></div>
      <section className="fx-current" aria-label="已保存汇率">
        <span className="fx-small-title">{current ? '已保存汇率' : '尚无本地汇率'}</span>
        <div className="fx-big-rate">1 <small>CNY</small><span>=</span>{current ? new MoneyDecimal(current.rate).toFixed(8) : '—'} <small>HKD</small></div>
        {current && <dl className="fx-metadata"><div><dt>来源</dt><dd>{current.source}</dd></div><div><dt>报价日期</dt><dd>{current.sourceDate}{current.sourceDate !== date && ' · 最近发布日'}</dd></div><div><dt>版本</dt><dd>v{current.revision}</dd></div><div><dt>获取时间</dt><dd>{new Intl.DateTimeFormat('zh-CN', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(current.fetchedAt))}</dd></div></dl>}
        {current?.sourceRates && <p className="fx-raw-quotes">ECB 原始报价：EUR/CNY {current.sourceRates.EUR_CNY}，EUR/HKD {current.sourceRates.EUR_HKD}</p>}
        {current && <details className="fx-exact-rate"><summary>完整比率</summary><code>{current.rate}</code></details>}
      </section>
      {candidate && <section className="fx-candidate" aria-label="查询结果"><div><span className="fx-small-title">参考价 · {candidate.sourceDate}</span><strong>1 CNY = {new MoneyDecimal(candidate.rate).toFixed(8)} HKD</strong><small>{candidate.source}</small></div>
        <button className="button secondary" disabled={readOnly || busy} onClick={() => propose({ candidate })}>{current ? '应用新版本' : '保存参考价'}</button></section>}
      {!readOnly && <form className="fx-manual" onSubmit={(event) => { event.preventDefault(); if (valid.success && !busy) propose({ manual: valid.data }); }}>
        <label htmlFor="manual-fx">手动汇率</label><div><span>1 CNY =</span><input id="manual-fx" aria-label="1 人民币兑换港币" inputMode="decimal" autoComplete="off" placeholder="输入汇率" maxLength={45} value={input} onChange={(event) => { setInput(event.target.value); setPending(null); }} disabled={busy} /><span>HKD</span><button className="button primary" disabled={!valid.success || busy} type="submit">保存</button></div>
        {input && !valid.success && <p className="error-text" role="alert">{valid.error.issues[0].message}</p>}
      </form>}
      {pending && <section className="fx-revision-confirm" aria-label="确认汇率修订">
        <strong>更新 {date} 的汇率？</strong><p>该日 {affected} 笔记录的折算结果将重新计算。原币金额不变，旧汇率 v{current?.revision} 会保留。</p>
        <div><button className="button secondary" onClick={() => setPending(null)} disabled={busy}>取消修订</button><button className="button primary" onClick={() => { void commit(pending); }} disabled={busy}>确认更新汇率</button></div>
      </section>}
      {error && <p className="form-error" role="alert">{error}</p>}{success && <p className="fx-success" role="status">{success}</p>}
      {history.length > 1 && <details className="fx-history"><summary><History size={14} />修订记录（{history.length}）</summary>{history.map((record) => <div key={record.id}><span>v{record.revision} · {record.source}</span><span className="money">{new MoneyDecimal(record.rate).toFixed(8)}</span></div>)}</details>}
      <details className="fx-date-list"><summary>已缓存日期（{rates.size}）</summary><div>{[...rates.values()].sort((a, b) => b.rateDate.localeCompare(a.rateDate)).map((record) => <button key={record.id} onClick={() => selectDate(record.rateDate)} disabled={busy} aria-label={`查看 ${record.rateDate} 汇率`}><span>{record.rateDate}</span><span>{new MoneyDecimal(record.rate).toFixed(6)}</span><small>{record.isManual ? '手动' : 'ECB'}</small><ChevronRight size={13} /></button>)}</div></details>
      <p className="fx-source-note">非发布日采用此前最近参考价。首次取得的汇率固定保存；更新需确认。<a href={FX_SOURCE_URL} target="_blank" rel="noreferrer">数据来源<ArrowUpRight size={12} /></a></p>
    </div>
  </Modal>;
}
