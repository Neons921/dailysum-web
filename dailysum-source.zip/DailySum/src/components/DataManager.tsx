import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import { ArrowDownToLine, ArrowUpFromLine, Check, FileJson, GitBranch as Github, History, LoaderCircle, RefreshCw, ShieldCheck } from 'lucide-react';
import { Modal } from './Modal';
import { Money } from './Money';
import { CurrencyToggle } from './CurrencyToggle';
import { readImportFile } from '../domain/cent';
import { changeSummary, conflictDescription, mergeLedger, type Choices, type DataConflict } from '../domain/merge';
import type { Currency, Transaction } from '../domain/models';
import { CENT_SOURCE_REPOSITORY, DEFAULT_SYNC_REPOSITORY } from '../domain/sync';
import { dataRepository, dataService, type DataPlan } from '../services/dataService';
import { syncService, type SyncPlan } from '../services/syncService';
import { GitHubClient } from '../services/githubClient';
import { describeError } from '../services/errors';
import type { Checkpoint } from '../storage/dataRepository';
import { saveFile } from '../services/saveFile';
import { isAndroid } from '../app/android';

export type DataMode='import'|'sync'|'restore';
const localStorageLabel = isAndroid ? '此应用' : '此浏览器';
const sessionLabel = isAndroid ? '本次打开应用期间' : '本次页面';
const dateTime=(value:string)=>new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Hong_Kong',dateStyle:'medium',timeStyle:'short'}).format(new Date(value));
export function DataManager({mode,onClose,onChanged}:{mode:DataMode;onClose:()=>void;onChanged:(latest?:boolean)=>Promise<void>}) {
  const sync=useSyncExternalStore(syncService.subscribe,syncService.getState);
  const [importPlan,setImportPlan]=useState<DataPlan|null>(null);
  const plan=mode==='sync'?sync.plan:importPlan;
  const [choices,setChoices]=useState<Choices>({});const [acceptSkipped,setAcceptSkipped]=useState(false);
  const [error,setError]=useState('');const [busy,setBusy]=useState(false);const busyRef=useRef(false);
  const errorRef=useRef<HTMLParagraphElement>(null);
  const [repository,setRepository]=useState(sync.profile?.repository??DEFAULT_SYNC_REPOSITORY);const [token,setToken]=useState('');
  const [remember,setRemember]=useState(true);
  const [auto,setAuto]=useState(sync.profile?.auto??false);
  const [sourceRepository,setSourceRepository]=useState(CENT_SOURCE_REPOSITORY);const [importTab,setImportTab]=useState<'file'|'github'>('file');
  const [fallbackBase,setFallbackBase]=useState<Currency>('CNY');
  const [points,setPoints]=useState<Checkpoint[]>([]);const [restore,setRestore]=useState<Checkpoint|null>(null);
  const run=async(action:()=>Promise<void>)=>{if(busyRef.current)return;busyRef.current=true;setBusy(true);setError('');try{await action();}catch(cause){setError(describeError(cause));}finally{busyRef.current=false;setBusy(false);}};
  useEffect(()=>{if(mode==='restore')void dataRepository.checkpoints().then(setPoints).catch((cause)=>setError(describeError(cause)));},[mode]);
  const displayedError=error||(mode==='sync'&&!sync.connected&&sync.status==='error'?sync.message:'');
  useEffect(()=>{if(displayedError)errorRef.current?.focus();},[displayedError]);
  useEffect(()=>{if(!busy)setAuto(sync.profile?.auto??false);},[sync.profile?.auto,busy]);
  useEffect(()=>{setChoices({});},[plan]);
  const syncing=mode==='sync'&&(sync.status==='checking'||sync.status==='syncing');
  const close=()=>{if(busyRef.current)return;setToken('');onClose();};
  const preview=async(payload:Parameters<typeof dataService.importPlan>[0])=>{const result=await dataService.importPlan(payload,fallbackBase);setImportPlan(result);setAcceptSkipped(false);};
  const syncNow=async()=>{await syncService.syncNow();};
  const submit=()=>run(async()=>{
    if(!plan)return;
    if(plan.kind==='sync'){await syncService.commit(plan as SyncPlan,choices);return;}
    await dataService.commit(plan,choices,acceptSkipped);await onChanged(true);onClose();
  });
  const title=plan?'核对账目':mode==='sync'?'GitHub 同步':mode==='restore'?'本地恢复点':'导入账目';
  return <Modal title={title} subtitle={plan?(plan.kind==='sync'?'选择有分歧的版本，其余变更会自动合并。':'确认后导入，现有账本会自动保留恢复点。'):undefined} onClose={close} busy={busy} className="data-modal">
    <fieldset className="data-content" disabled={busy||syncing}>
      {plan?<PlanPreview plan={plan} choices={choices} onChoices={setChoices} acceptSkipped={acceptSkipped} onAcceptSkipped={setAcceptSkipped}
        onExportIssues={() => void run(() => saveFile(JSON.stringify(plan.issues, null, 2), 'cent-import-issues.json'))} />:mode==='sync'?<>
        <div className="data-heading"><span className="data-icon"><Github size={24}/></span><div><h3>{sync.connected?'已连接 GitHub':'连接私有仓库'}</h3><p>{sync.connected?sync.profile?.repository:'使用独立的 DailySum 仓库保存账本。'}</p></div>{sync.connected&&<span className="connection-check"><Check size={15}/>已连接</span>}</div>
        {!sync.connected?<form id="github-connection" className="data-form" onSubmit={(event)=>{event.preventDefault();void run(async()=>{await syncService.connect(repository,token,{remember});setToken('');await syncNow();});}}>
          <label>DailySum 私有仓库<input autoComplete="off" value={repository} onChange={(event)=>setRepository(event.target.value)} placeholder="用户名/仓库名" required disabled={busy}/></label>
          <label>GitHub Token<input type="password" autoComplete="off" value={token} onChange={(event)=>setToken(event.target.value)} placeholder="粘贴仓库专用 Token" required disabled={busy}/></label>
          <label className="data-checkbox"><input type="checkbox" checked={remember} onChange={(event)=>setRemember(event.currentTarget.checked)}/><span>记住 GitHub 连接<small>下次打开自动连接，并保留自动同步设置。</small></span></label>
          <div className="data-help"><ShieldCheck size={17}/><p>{remember?`Token 将保存在${localStorageLabel}，不进入账目备份或同步文件。`:`Token 仅用于${sessionLabel}，关闭后需重新连接。`}为所选私有仓库授予 Contents 读写权限；请勿在聊天中发送。</p></div>
          <div className="data-links"><a href="https://github.com/new" target="_blank" rel="noreferrer">新建私有仓库</a><a href="https://github.com/settings/personal-access-tokens/new" target="_blank" rel="noreferrer">创建仓库专用 Token</a></div>
        </form>:<>
          <div className="sync-details"><p><span>最近同步</span><strong>{sync.profile?.lastSyncAt?dateTime(sync.profile.lastSyncAt):'尚未同步'}</strong></p><p role="status"><span>当前状态</span><strong>{sync.message}</strong></p></div>
          <p className="data-hint">{sync.remembered?`${localStorageLabel}已记住 GitHub 连接。`:`当前连接仅用于${sessionLabel}。`}</p>
          <label className="data-checkbox"><input type="checkbox" checked={auto} onChange={(event)=>{const wanted=event.currentTarget.checked;setAuto(wanted);void run(()=>syncService.setAuto(wanted));}}/><span>自动同步<small>记账后、恢复联网及使用应用期间自动同步。</small></span></label>
          <button className="text-button data-disconnect" disabled={busy} onClick={()=>void run(()=>syncService.disconnect())}>忘记连接</button>
        </>}
      </>:mode==='import'?<>
        <div className="segment-control data-import-tabs" aria-label="导入来源"><button aria-pressed={importTab==='file'} onClick={()=>setImportTab('file')} disabled={busy}><FileJson size={15}/>备份文件</button><button aria-pressed={importTab==='github'} onClick={()=>setImportTab('github')} disabled={busy}><Github size={15}/>Cent 仓库</button></div>
        {importTab==='file'?<><label className={`data-dropzone ${busy?'disabled':''}`}><ArrowUpFromLine size={29}/><strong>{busy?'正在读取…':'选择备份文件'}</strong><span>DailySum JSON、Cent JSON 或 .cent.zip</span><input type="file" aria-label="选择备份文件" accept=".json,.zip" disabled={busy} onChange={(event)=>{const file=event.target.files?.[0];if(file)void run(async()=>preview(await readImportFile(file)));event.target.value='';}}/></label><p className="data-hint">单个文件最多 40 MB；Cent 附件随原始记录保留。</p></>:<form id="cent-import" className="data-form" onSubmit={(event)=>{event.preventDefault();void run(async()=>{const client=new GitHubClient();try{client.connect(token);await preview(await client.readCent(sourceRepository));setToken('');}finally{client.disconnect();}});}}>
          <label>Cent 仓库<input value={sourceRepository} onChange={(event)=>setSourceRepository(event.target.value)} required disabled={busy} autoComplete="off"/></label>
          <label>GitHub Token<input type="password" value={token} onChange={(event)=>setToken(event.target.value)} required disabled={busy} autoComplete="off" placeholder="源仓库的 Contents 读取权限"/></label>
          <p className="data-hint">只读取 Cent 数据与附件，原仓库保持不变。Token 不保存。</p>
        </form>}
        <div className="data-base-currency"><div><strong>缺少基础币种时</strong><p>旧版 Cent 未标记外币的记录使用此币种。</p></div><CurrencyToggle value={fallbackBase} onChange={setFallbackBase} label="Cent 基础币种" compact disabled={busy}/></div>
      </>:<>
        <p className="data-hint">导入或拉取账目前自动保留最近 3 个恢复点，存放于{localStorageLabel}。</p>
        {points.length?<div className="checkpoint-list">{points.map((point)=><button key={point.id} className={restore?.id===point.id?'selected':''} onClick={()=>setRestore(point)} disabled={busy}><History size={20}/><span><strong>{dateTime(point.createdAt)}</strong><small>{point.label}</small></span><b>{point.data.transactions.filter((row)=>!row.deletedAt).length} 笔</b>{restore?.id===point.id&&<Check size={16}/>}</button>)}</div>:<div className="data-empty"><History size={30}/><p>尚无恢复点</p></div>}
        {restore&&<div className="data-notice">将恢复选中时刻的账目、分类和统计条件。本次状态也会保存为恢复点。</div>}
      </>}
      {displayedError&&<p ref={errorRef} tabIndex={-1} className="form-error" role="alert">{displayedError}</p>}
    </fieldset>
    <footer className="modal-footer data-footer">{plan&&<button className="text-button data-recheck" disabled={busy||syncing} onClick={()=>{if(plan.kind==='sync')void run(syncNow);else{setImportPlan(null);setError('');}}}>{plan.kind==='sync'?'重新检查':'重新选择'}</button>}<button className="button secondary" type="button" onClick={close} disabled={busy}>{mode==='sync'?'关闭':'取消'}</button>
      {plan?<button className="button primary" disabled={busy||syncing||mergeLedger(plan.base,plan.before,plan.remote,choices).unresolved.length>0||plan.issues.length>0&&!acceptSkipped} onClick={()=>void submit()}>{busy?<><LoaderCircle size={16} className="spin"/>处理中…</>:plan.kind==='sync'?<><RefreshCw size={16}/>确认同步</>:<><ArrowDownToLine size={16}/>确认导入</>}</button>:mode==='sync'?sync.connected?<button className="button primary" disabled={busy||syncing} onClick={()=>void run(syncNow)}><RefreshCw size={16} className={syncing?'spin':undefined}/>{syncing?'同步中…':'立即同步'}</button>:<button className="button primary" type="submit" form="github-connection" disabled={busy||syncing||!token.trim()||!repository.trim()}>{busy?'连接中…':'连接并同步'}</button>:mode==='import'&&importTab==='github'?<button className="button primary" type="submit" form="cent-import" disabled={busy||!token.trim()}>{busy?'读取中…':'读取 Cent 数据'}</button>:mode==='restore'&&restore?<button className="button primary" disabled={busy} onClick={()=>void run(async()=>{await dataRepository.restore(restore);await onChanged(true);onClose();})}>{busy?'恢复中…':'恢复此版本'}</button>:null}
    </footer>
  </Modal>;
}

function PlanPreview({plan,choices,onChoices,acceptSkipped,onAcceptSkipped,onExportIssues}:{plan:DataPlan;choices:Choices;onChoices:(choices:Choices)=>void;acceptSkipped:boolean;onAcceptSkipped:(value:boolean)=>void;onExportIssues:()=>void}) {
  const merged=useMemo(()=>mergeLedger(plan.base,plan.before,plan.remote,choices),[plan,choices]);
  const changes=changeSummary(plan.before,merged.data),outgoing=changeSummary(plan.remote,merged.data);
  const [limit,setLimit]=useState(15);const isSync=plan.kind==='sync';
  const summary=(counts:typeof changes)=>`${counts.added} 笔新增，${counts.updated} 笔更新，${counts.deleted} 笔删除`;
  const incoming=plan.remote.transactions.filter((row)=>!row.deletedAt),dates=incoming.map((row)=>row.occurredOn).sort();
  const describe=(conflict:DataConflict,value:unknown)=>{
    if(conflict.kind!=='transaction')return conflictDescription(value,conflict.kind);
    const row=value as Transaction|undefined;const category=row&&merged.data.categories.find((item)=>item.id===row.categoryId);
    return `${conflictDescription(value,conflict.kind)}${category?`\n${category.name}`:''}`;
  };
  return <>
    <div className="import-source"><span className="data-icon">{isSync?<Github size={23}/>:<FileJson size={23}/>}</span><div><strong>{isSync?'GitHub 同步计划':plan.kind==='cent'?'Cent 导入预览':'DailySum 备份预览'}</strong><p title={plan.label}>{plan.label}</p></div></div>
    <div className="import-counts"><div><strong>{changes.added}</strong><span>新增记录</span></div><div><strong>{changes.updated}</strong><span>更新记录</span></div><div><strong>{merged.conflicts.length}</strong><span>需选择的分歧</span></div></div>
    {isSync?<div className="sync-directions"><p><ArrowDownToLine size={15}/><span>合并到此设备</span><strong>{summary(changes)}</strong></p><p><ArrowUpFromLine size={15}/><span>保存到 GitHub</span><strong>{summary(outgoing)}</strong></p></div>:<p className="data-hint">读取 {plan.total} 笔，{plan.duplicates} 笔已存在。新增 {changes.categories} 个分类、{changes.filters} 个过滤器{changes.deleted?`，${changes.deleted} 笔标记删除`:''}。</p>}
    {!isSync&&dates.length>0&&<div className="import-period"><span>{dates[0]} — {dates.at(-1)}</span><span>{(['HKD','CNY'] as const).map((currency)=>`${currency} ${incoming.filter((row)=>row.currency===currency).length} 笔`).join(' · ')}</span></div>}
    {plan.warnings.map((warning)=><p className="data-notice" key={warning}>{warning}</p>)}
    {plan.issues.length>0&&<section className="import-issues"><h3>{plan.issues.length} 笔无法导入</h3><ul>{plan.issues.slice(0,30).map((issue,index)=><li key={index}><span>{issue.id}</span>{issue.reason}</li>)}</ul><button className="text-button" onClick={onExportIssues}>下载完整问题清单</button><label className="data-checkbox"><input type="checkbox" checked={acceptSkipped} onChange={(event)=>onAcceptSkipped(event.target.checked)}/><span>导入其余有效记录<small>无法导入的原始记录仍会归档，可随 DailySum 备份导出。</small></span></label></section>}
    {merged.conflicts.length>0&&<section className="merge-conflicts"><header><h3>选择保留的内容</h3><span>{merged.unresolved.length} 项待处理</span></header><p>同一条记录出现不同修改，请逐项核对。</p><div className="conflict-bulk"><button className="text-button" onClick={()=>onChoices(Object.fromEntries(merged.conflicts.map((conflict)=>[conflict.key,'local'])))}>全部保留此设备</button><button className="text-button" onClick={()=>onChoices(Object.fromEntries(merged.conflicts.map((conflict)=>[conflict.key,'remote'])))}>全部采用{isSync?' GitHub':'导入内容'}</button></div>{merged.conflicts.slice(0,limit).map((conflict,index)=><fieldset className="merge-conflict" key={conflict.key}><legend>{({transaction:'账目',category:'分类',filter:'过滤器',fx:'汇率'})[conflict.kind]} {index+1}</legend><div>{(['local','remote'] as const).map((side)=><label key={side} className={choices[conflict.key]===side?'selected':''}><span><input type="radio" name={conflict.key} value={side} checked={choices[conflict.key]===side} onChange={()=>onChoices({...choices,[conflict.key]:side})}/>{side==='local'?'此设备':isSync?'GitHub':'导入内容'}</span><p>{describe(conflict,conflict[side])}</p></label>)}</div></fieldset>)}{merged.conflicts.length>limit&&<button className="text-button" onClick={()=>setLimit((value)=>value+20)}>显示更多分歧</button>}</section>}
    <details className="import-records"><summary>查看记录示例<span>前 8 笔</span></summary>{plan.remote.transactions.filter((row)=>!row.deletedAt).slice(0,8).map((row)=><div key={row.id}><time>{row.occurredOn}</time><span title={row.note}>{row.note||plan.remote.categories.find((category)=>category.id===row.categoryId)?.name}</span><strong className="money"><Money minor={row.amountMinor} currency={row.currency} sign={row.type==='expense'?'−':'+'}/></strong></div>)}</details>
    <p className="data-hint">确认前不会改动账本。完成后可在“本地恢复点”中恢复。</p>
  </>;
}
