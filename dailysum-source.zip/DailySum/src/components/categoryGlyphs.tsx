import {
  Apple, Armchair, ArrowLeftRight, Baby, Banknote, Bath, BatteryCharging, BedDouble, Beef, Bike,
  BookOpen, BriefcaseBusiness, Bus, CalendarCheck, Camera, Candy, CarFront, CarTaxiFront, Carrot, Cat,
  Coffee, CreditCard, Croissant, CupSoda, Dog, Droplets, Dumbbell, Egg, Eye, Fish, Flame, Footprints,
  Fuel, Gamepad2, Gift, Glasses, GraduationCap, Guitar, Hammer, HandHeart, Headphones, HeartPulse,
  House, IceCreamCone, KeyRound, Landmark, Laptop, Luggage, MapPin, MoreHorizontal, Music, Package,
  ParkingMeter, PawPrint, Pencil, Pill, Pizza, Plane, Popcorn, ReceiptText, Sandwich, ShieldCheck,
  Shirt, ShoppingBag, ShoppingBasket, ShoppingCart, Signpost, Smartphone, Soup, Sparkles, SprayCan,
  Sprout, Stethoscope, TentTree, Ticket, Toothbrush, TrainFront, TrainTrack, TrendingUp, Utensils,
  Volleyball, Wallet, WashingMachine, Watch, WavesLadder, Wifi, Wine, Wrench, Zap, type LucideIcon,
} from 'lucide-react';
import type { ReactNode } from 'react';
import type { Category } from '../domain/models';

const Badminton = () => <><path d="m7 14-2 2a2.8 2.8 0 0 0 4 4l2-2m-4-4 4 4 9-4 1-3-2-2-3 1 1-3-2-2-3 1-5 8Zm2 2 7-6" /></>;
const Mahjong = () => <><rect x="5" y="3" width="14" height="18" rx="2" /><circle cx="10" cy="8" r="1" /><circle cx="14" cy="12" r="1" /><circle cx="10" cy="16" r="1" /></>;
const BubbleTea = () => <><path d="M13 8l2-5h3M5 8h14M6 8l1.6 11.3a2 2 0 0 0 2 1.7h4.8a2 2 0 0 0 2-1.7L18 8" /><circle cx="10" cy="15" r=".65" /><circle cx="13.5" cy="14" r=".65" /><circle cx="12" cy="18" r=".65" /></>;

type Glyph = {
  id: string;
  label: string;
  keywords?: string;
  color?: string;
} & ({ Icon: LucideIcon; art?: never } | { art: () => ReactNode; Icon?: never });

const palette = {
  blue: '#527D94', teal: '#4F8A80', sage: '#6F8E75', olive: '#808A5D', amber: '#A38553',
  clay: '#A47962', rose: '#A9747E', mauve: '#927299', violet: '#7D75A4', slate: '#6B8198',
};

export const categoryGlyphGroups: { id: string; label: string; tab: string; icons: Glyph[] }[] = [
  { id: 'meals', label: '餐饮生鲜', tab: '餐饮', icons: [
    { id: 'food', label: '餐饮', Icon: Utensils, keywords: '吃饭 午餐 晚餐 聚餐 餐厅' },
    { id: 'drink', label: '饮料', Icon: CupSoda, color: '#5E8998', keywords: '汽水 果汁 可乐 矿泉水' },
    { id: 'bubble-tea', label: '奶茶', art: BubbleTea, color: '#A47762', keywords: '珍珠茶 手摇饮' },
    { id: 'coffee', label: '咖啡', Icon: Coffee, color: '#91745F' },
    { id: 'fruit', label: '水果', Icon: Apple, color: palette.rose, keywords: '苹果 香蕉 橙子 生鲜 买菜' },
    { id: 'vegetables', label: '蔬菜', Icon: Carrot, color: palette.olive, keywords: '青菜 生鲜 买菜 菜市场' },
    { id: 'groceries', label: '超市', Icon: ShoppingCart, color: palette.sage, keywords: '杂货 买菜 生鲜 食材' },
    { id: 'bakery', label: '烘焙', Icon: Croissant, color: palette.amber, keywords: '面包 蛋糕 点心 甜品' },
    { id: 'breakfast', label: '早餐', Icon: Sandwich, color: palette.clay, keywords: '三明治 早饭' },
    { id: 'noodles', label: '粉面', Icon: Soup, color: palette.teal, keywords: '面条 拉面 汤粉' },
    { id: 'fast-food', label: '快餐', Icon: Pizza, color: palette.rose, keywords: '外卖 披萨 汉堡' },
    { id: 'meat', label: '肉类', Icon: Beef, color: palette.clay, keywords: '猪肉 牛肉 鸡肉' },
    { id: 'seafood', label: '海鲜', Icon: Fish, color: palette.blue, keywords: '鱼虾 水产' },
    { id: 'eggs', label: '蛋类', Icon: Egg, color: palette.amber, keywords: '鸡蛋 鸭蛋' },
    { id: 'ice-cream', label: '冰淇淋', Icon: IceCreamCone, color: palette.mauve, keywords: '雪糕 甜品' },
    { id: 'snacks', label: '零食', Icon: Candy, color: palette.violet, keywords: '糖果 小吃' },
    { id: 'alcohol', label: '酒水', Icon: Wine, color: palette.mauve, keywords: '啤酒 红酒 酒吧' },
  ] },
  { id: 'travel', label: '交通出行', tab: '出行', icons: [
    { id: 'transport', label: '地铁', Icon: TrainFront, keywords: '交通 轨道 通勤' },
    { id: 'bus', label: '公交', Icon: Bus, color: '#6B8996', keywords: '巴士 公共汽车' },
    { id: 'bike', label: '单车', Icon: Bike, color: '#658B78', keywords: '自行车 共享单车 骑行' },
    { id: 'taxi', label: '打车', Icon: CarTaxiFront, color: palette.amber, keywords: '出租车 网约车 滴滴' },
    { id: 'fuel', label: '加油', Icon: Fuel, color: palette.clay, keywords: '油费 汽油 柴油 燃油 加油站' },
    { id: 'parking', label: '停车', Icon: ParkingMeter, color: palette.slate, keywords: '停车费 车位' },
    { id: 'toll', label: '过路费', Icon: Signpost, color: palette.olive, keywords: '高速 路桥 ETC' },
    { id: 'car', label: '汽车', Icon: CarFront, color: palette.blue, keywords: '买车 租车 自驾' },
    { id: 'car-service', label: '养车', Icon: Wrench, color: palette.slate, keywords: '保养 修车 洗车' },
    { id: 'charging', label: '充电', Icon: BatteryCharging, color: palette.teal, keywords: '充电桩 电动车 新能源' },
    { id: 'rail', label: '火车', Icon: TrainTrack, color: palette.rose, keywords: '铁路 高铁 动车' },
    { id: 'plane', label: '旅行', Icon: Plane, color: '#6A83A4', keywords: '机票 航班 飞机' },
    { id: 'luggage', label: '行李', Icon: Luggage, color: palette.mauve, keywords: '托运 行李箱' },
    { id: 'hotel', label: '住宿', Icon: BedDouble, color: palette.violet, keywords: '酒店 民宿 旅馆' },
    { id: 'attractions', label: '景点', Icon: MapPin, color: palette.sage, keywords: '旅游 门票 游玩' },
  ] },
  { id: 'goods', label: '购物日用', tab: '购物', icons: [
    { id: 'shopping', label: '购物', Icon: ShoppingBag },
    { id: 'living', label: '日用', Icon: ShoppingBasket, keywords: '杂货 日用品' },
    { id: 'clothes', label: '服饰', Icon: Shirt, color: '#AA7488', keywords: '衣服 裤子' },
    { id: 'shoes', label: '鞋履', Icon: Footprints, color: palette.clay, keywords: '鞋子 运动鞋' },
    { id: 'toiletries', label: '洗护', Icon: Bath, color: palette.blue, keywords: '洗发水 沐浴露' },
    { id: 'cosmetics', label: '美妆', Icon: Sparkles, color: palette.rose, keywords: '化妆 护肤 美容' },
    { id: 'cleaning', label: '清洁', Icon: SprayCan, color: palette.teal, keywords: '清洁剂 洗涤 家务' },
    { id: 'appliances', label: '家电', Icon: WashingMachine, color: palette.slate, keywords: '洗衣机 冰箱' },
    { id: 'furniture', label: '家具', Icon: Armchair, color: palette.clay, keywords: '沙发 椅子 床' },
    { id: 'shipping', label: '快递', Icon: Package, color: palette.amber, keywords: '邮费 运费 寄件' },
    { id: 'electronics', label: '数码', Icon: Headphones, color: palette.violet, keywords: '耳机 配件 电子' },
    { id: 'accessories', label: '配饰', Icon: Watch, color: palette.mauve, keywords: '手表 首饰' },
    { id: 'glasses', label: '眼镜', Icon: Glasses, color: palette.olive, keywords: '镜架 镜片 配镜' },
  ] },
  { id: 'home', label: '居家账单', tab: '居家', icons: [
    { id: 'house', label: '居住', Icon: House, color: '#8B8961', keywords: '物业 家庭' },
    { id: 'rent', label: '房租', Icon: KeyRound, color: palette.amber, keywords: '租金 租房 押金' },
    { id: 'electricity', label: '电费', Icon: Zap, color: palette.amber, keywords: '电力 水电' },
    { id: 'water-bill', label: '水费', Icon: Droplets, color: palette.blue, keywords: '自来水 水电' },
    { id: 'gas-bill', label: '燃气', Icon: Flame, color: palette.clay, keywords: '煤气 天然气 燃气费' },
    { id: 'internet', label: '宽带', Icon: Wifi, color: palette.violet, keywords: '网费 网络' },
    { id: 'phone', label: '通讯', Icon: Smartphone, color: '#617E89', keywords: '话费 手机 流量' },
    { id: 'home-repair', label: '家装', Icon: Hammer, color: palette.slate, keywords: '装修 家居维修' },
    { id: 'gardening', label: '园艺', Icon: Sprout, color: palette.sage, keywords: '绿植 花卉 花盆' },
    { id: 'refund', label: '账单', Icon: ReceiptText, keywords: '收据 退款 单据' },
  ] },
  { id: 'leisure', label: '运动娱乐', tab: '娱乐', icons: [
    { id: 'fun', label: '电影', Icon: Popcorn, keywords: '影院 娱乐 观影' },
    { id: 'badminton', label: '羽毛球', art: Badminton, color: '#4F8A80', keywords: '球馆 球拍' },
    { id: 'mahjong', label: '麻将', art: Mahjong, color: '#7A8E61', keywords: '棋牌 桌游' },
    { id: 'fitness', label: '健身', Icon: Dumbbell, color: '#72829F', keywords: '运动 健身房 私教' },
    { id: 'ball-sports', label: '球类', Icon: Volleyball, color: palette.amber, keywords: '排球 足球 篮球 网球' },
    { id: 'swimming', label: '游泳', Icon: WavesLadder, color: palette.blue, keywords: '泳池' },
    { id: 'camping', label: '露营', Icon: TentTree, color: palette.sage, keywords: '帐篷 户外' },
    { id: 'games', label: '游戏', Icon: Gamepad2, color: '#8274A3', keywords: '主机 手游' },
    { id: 'music', label: '音乐', Icon: Music, color: '#A77491', keywords: '演唱会 音乐会' },
    { id: 'instruments', label: '乐器', Icon: Guitar, color: palette.clay, keywords: '吉他 钢琴' },
    { id: 'ticket', label: '票券', Icon: Ticket, color: '#A18352', keywords: '门票 演出 电影票' },
    { id: 'books', label: '书籍', Icon: BookOpen, color: '#697C9E', keywords: '阅读 买书' },
    { id: 'photography', label: '摄影', Icon: Camera, color: palette.slate, keywords: '相机 拍照 洗照片' },
    { id: 'subscription', label: '订阅', Icon: CalendarCheck, color: palette.mauve, keywords: '会员 月费 年费' },
  ] },
  { id: 'family', label: '健康家庭', tab: '健康', icons: [
    { id: 'health', label: '医疗', Icon: HeartPulse, keywords: '健康 医院 体检' },
    { id: 'doctor', label: '看诊', Icon: Stethoscope, color: palette.teal, keywords: '门诊 挂号 医生' },
    { id: 'medicine', label: '药品', Icon: Pill, color: palette.violet, keywords: '买药 药房' },
    { id: 'dental', label: '牙科', Icon: Toothbrush, color: palette.blue, keywords: '牙医 洗牙 牙刷' },
    { id: 'eye-care', label: '眼科', Icon: Eye, color: palette.slate, keywords: '验光 视力' },
    { id: 'childcare', label: '母婴', Icon: Baby, color: palette.rose, keywords: '儿童 奶粉 尿布 育儿' },
    { id: 'pet', label: '宠物', Icon: Dog, color: '#9B826A', keywords: '狗粮 兽医' },
    { id: 'cat-care', label: '猫咪', Icon: Cat, color: palette.mauve, keywords: '猫粮 猫砂' },
    { id: 'pet-care', label: '宠物护理', Icon: PawPrint, color: palette.amber, keywords: '洗澡 驱虫 宠物用品' },
  ] },
  { id: 'finance', label: '学习理财', tab: '理财', icons: [
    { id: 'briefcase', label: '工作', Icon: BriefcaseBusiness, color: '#548A77', keywords: '工资 上班 办公' },
    { id: 'laptop', label: '电脑', Icon: Laptop, color: '#657DA0', keywords: '兼职 计算机 笔记本' },
    { id: 'tuition', label: '学费', Icon: GraduationCap, color: palette.violet, keywords: '学习 教育 课程 培训' },
    { id: 'stationery', label: '文具', Icon: Pencil, color: palette.amber, keywords: '笔纸 办公用品' },
    { id: 'bonus', label: '钱包', Icon: Wallet, keywords: '奖金 零用钱' },
    { id: 'cash', label: '现金', Icon: Banknote, color: palette.sage, keywords: '取现 工资 收入' },
    { id: 'credit-card', label: '信用卡', Icon: CreditCard, color: palette.blue, keywords: '还款 刷卡' },
    { id: 'investment', label: '投资', Icon: TrendingUp, color: palette.teal, keywords: '股票 基金 利息 理财' },
    { id: 'insurance', label: '保险', Icon: ShieldCheck, color: palette.slate, keywords: '保费 商业险' },
    { id: 'bank-fees', label: '手续费', Icon: Landmark, color: palette.olive, keywords: '银行 服务费 年费' },
    { id: 'exchange', label: '换汇', Icon: ArrowLeftRight, color: palette.clay, keywords: '汇款 外汇 转账' },
    { id: 'gift', label: '礼物', Icon: Gift, keywords: '红包 人情 送礼' },
    { id: 'donation', label: '捐赠', Icon: HandHeart, color: palette.rose, keywords: '公益 慈善' },
    { id: 'other', label: '其他', Icon: MoreHorizontal, keywords: '杂项 未分类' },
  ] },
];

const glyphsById = new Map(categoryGlyphGroups.flatMap((group) => group.icons).map((glyph) => [glyph.id, glyph]));

export function findCategoryGlyph(id: string) {
  return glyphsById.get(id);
}

export function categoryGlyphId(category?: Pick<Category, 'id' | 'icon'>): string {
  if (category?.icon === 'work') return category.id === 'parttime' ? 'laptop' : 'briefcase';
  return category?.icon ?? 'other';
}

export function CategoryGlyph({ id, size }: { id: string; size: number }) {
  const glyph = findCategoryGlyph(id);
  if (glyph?.art) {
    const Art = glyph.art;
    return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><Art /></svg>;
  }
  const Icon = glyph?.Icon ?? MoreHorizontal;
  return <Icon size={size} strokeWidth={1.7} aria-hidden="true" />;
}
