import {
  Bike, BookOpen, BriefcaseBusiness, Bus, Coffee, CupSoda, Dog, Dumbbell, Gamepad2, Gift,
  HeartPulse, House, Laptop, MoreHorizontal, Music, Plane, Popcorn, ReceiptText, Shirt,
  ShoppingBag, ShoppingBasket, Smartphone, Ticket, TrainFront, Utensils, Wallet,
} from 'lucide-react';
import type { Category } from '../domain/models';

const Badminton = () => <><path d="m7 14-2 2a2.8 2.8 0 0 0 4 4l2-2m-4-4 4 4 9-4 1-3-2-2-3 1 1-3-2-2-3 1-5 8Zm2 2 7-6" /></>;
const Mahjong = () => <><rect x="5" y="3" width="14" height="18" rx="2" /><circle cx="10" cy="8" r="1" /><circle cx="14" cy="12" r="1" /><circle cx="10" cy="16" r="1" /></>;
const BubbleTea = () => <><path d="M13 8l2-5h3M5 8h14M6 8l1.6 11.3a2 2 0 0 0 2 1.7h4.8a2 2 0 0 0 2-1.7L18 8" /><circle cx="10" cy="15" r=".65" /><circle cx="13.5" cy="14" r=".65" /><circle cx="12" cy="18" r=".65" /></>;

export const categoryGlyphs = [
  { id: 'food', label: '餐饮', Icon: Utensils },
  { id: 'drink', label: '饮料', Icon: CupSoda },
  { id: 'bubble-tea', label: '奶茶', art: BubbleTea },
  { id: 'coffee', label: '咖啡', Icon: Coffee },
  { id: 'transport', label: '地铁', Icon: TrainFront },
  { id: 'bus', label: '公交', Icon: Bus },
  { id: 'bike', label: '单车', Icon: Bike },
  { id: 'plane', label: '旅行', Icon: Plane },
  { id: 'shopping', label: '购物', Icon: ShoppingBag },
  { id: 'living', label: '日用', Icon: ShoppingBasket },
  { id: 'house', label: '居住', Icon: House },
  { id: 'clothes', label: '服饰', Icon: Shirt },
  { id: 'fun', label: '电影', Icon: Popcorn },
  { id: 'badminton', label: '羽毛球', art: Badminton },
  { id: 'mahjong', label: '麻将', art: Mahjong },
  { id: 'fitness', label: '健身', Icon: Dumbbell },
  { id: 'games', label: '游戏', Icon: Gamepad2 },
  { id: 'music', label: '音乐', Icon: Music },
  { id: 'ticket', label: '票券', Icon: Ticket },
  { id: 'books', label: '书籍', Icon: BookOpen },
  { id: 'pet', label: '宠物', Icon: Dog },
  { id: 'health', label: '医疗', Icon: HeartPulse },
  { id: 'phone', label: '通讯', Icon: Smartphone },
  { id: 'briefcase', label: '工作', Icon: BriefcaseBusiness },
  { id: 'laptop', label: '电脑', Icon: Laptop },
  { id: 'bonus', label: '钱包', Icon: Wallet },
  { id: 'gift', label: '礼物', Icon: Gift },
  { id: 'refund', label: '账单', Icon: ReceiptText },
  { id: 'other', label: '其他', Icon: MoreHorizontal },
];

export function categoryGlyphId(category?: Pick<Category, 'id' | 'icon'>): string {
  if (category?.icon === 'work') return category.id === 'parttime' ? 'laptop' : 'briefcase';
  return category?.icon ?? 'other';
}

export function CategoryGlyph({ id, size }: { id: string; size: number }) {
  const glyph = categoryGlyphs.find((item) => item.id === id);
  if (glyph?.art) {
    const Art = glyph.art;
    return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><Art /></svg>;
  }
  const Icon = glyph?.Icon ?? MoreHorizontal;
  return <Icon size={size} strokeWidth={1.7} aria-hidden="true" />;
}
