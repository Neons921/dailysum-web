import { useState } from 'react';
import type { Transaction } from '../domain/models';
import type { SourceArchive } from '../domain/portable';
import { base64ToBytes } from '../domain/portable';
import { dataRepository } from '../services/dataService';
import { describeError } from '../services/errors';
import { saveFile } from '../services/saveFile';

export function CentSourceDetails({transaction}:{transaction:Transaction}) {
  const [source,setSource]=useState<{archive:SourceArchive;record:Record<string,unknown>}|null>(null);
  const [error,setError]=useState('');const [loading,setLoading]=useState(false);
  const [originalCategory,setOriginalCategory]=useState('');
  if(!transaction.origin)return null;
  const origin=transaction.origin;
  const images=Array.isArray(source?.record.images)?source.record.images.filter((image):image is string=>typeof image==='string'):[];
  const attachments=source?.archive.attachments.filter((file)=>images.some((image)=>image===file.path||image.endsWith(`/${file.path}`)))??[];
  const inline=images.filter((image)=>/^data:(image\/(png|jpeg|webp|gif)|application\/pdf);base64,[a-z0-9+/=\s]+$/i.test(image));
  const rawMeta=source?.archive.data as {meta?:{tags?:{id:string;name:string}[]}}|undefined;
  const tags=Array.isArray(rawMeta?.meta?.tags)?rawMeta.meta.tags.filter((tag)=>Array.isArray(source?.record.tagIds)&&source.record.tagIds.includes(tag.id)).map((tag)=>tag.name):[];
  const download = async (content: string, mime: string, name: string) => {
    setError('');
    try {
      await saveFile(new Uint8Array(base64ToBytes(content)), name, mime);
    } catch (cause) {
      setError(describeError(cause));
    }
  };
  return <details className="cent-source" onToggle={(event)=>{if(event.currentTarget.open&&!source&&!loading){setLoading(true);void Promise.all([dataRepository.rawCentRecord(origin.archiveId,origin.sourceId),transaction.categoryHistory?.[0]?dataRepository.db.categories.get(transaction.categoryHistory[0]):Promise.resolve(undefined)]).then(([value,category])=>{if(!value)throw new Error('找不到原始归档');setSource(value);setOriginalCategory(category?.name??'');}).catch((cause)=>setError(describeError(cause))).finally(()=>setLoading(false));}}}>
    <summary>Cent 原始记录</summary>
    <p>原始 ID：{origin.sourceId}<br/>记账时间：{new Date(origin.originalTime).toLocaleString('zh-CN',{timeZone:'Asia/Hong_Kong'})}<br/>原始金额：{origin.currency} {String(Number(origin.amount10000)/10000)}</p>
    {loading&&<p>正在读取…</p>}
    {tags.length>0&&<p>标签：{tags.join('、')}</p>}
    {originalCategory&&<p>合并前分类：{originalCategory}</p>}
    {source&&<><p>原分类：{String(source.record.categoryId)}<br/>来源：{source.archive.source}</p><button className="text-button" type="button" onClick={() => {
      setError('');
      const content = JSON.stringify({ item: source.record, meta: rawMeta?.meta }, null, 2);
      void saveFile(content, `Cent-${origin.sourceId}.json`).catch((cause) => setError(describeError(cause)));
    }}>导出原始记录</button>{attachments.map((file,index)=><button key={file.path} type="button" className="text-button" onClick={()=>void download(file.content,file.mime,file.path.split('/').at(-1)??`附件${index+1}`)}>下载附件 {index+1}</button>)}{inline.map((value,index)=><button key={index} type="button" className="text-button" onClick={()=>void download(value.split(',')[1],value.slice(5,value.indexOf(';')),`Cent-${origin.sourceId}-${index+1}`)}>下载内嵌附件 {index+1}</button>)}{images.length>attachments.length+inline.length&&<p>部分附件仅含原始外链，链接保留在原始记录中。</p>}</>}
    {error&&<p role="alert">{error}</p>}
  </details>;
}
