import { useEffect, type RefObject } from 'react';
import type { HeatmapMode } from '../domain/spendingCalendar';

const HOLD_MS = 400;
const MOVE_THRESHOLD = 8;

function tileAt(scroller: HTMLDivElement, target: EventTarget | null) {
  const tile = target instanceof Element ? target.closest<HTMLButtonElement>('button[data-date]') : null;
  return tile && scroller.contains(tile) ? tile : null;
}

export function useHeatmapTouch(scrollRef: RefObject<HTMLDivElement | null>, mode: HeatmapMode, preview: (tile: HTMLButtonElement | null) => void) {
  useEffect(() => {
    const scroller = scrollRef.current;
    if (!scroller) return;
    let press: { id: number; x: number; y: number; timer: number; reading: boolean } | null = null;
    let suppressTap = false;

    const clearPress = () => {
      if (!press) return;
      const { timer, reading } = press;
      press = null;
      window.clearTimeout(timer);
      if (reading) preview(null);
    };
    const cancel = () => {
      if (press) suppressTap = true;
      clearPress();
    };
    const start = (event: TouchEvent) => {
      if (event.touches.length !== 1) { cancel(); return; }
      clearPress();
      suppressTap = false;
      preview(null);
      const tile = tileAt(scroller, event.target);
      if (!tile) return;
      const finger = event.touches[0];
      const next = { id: finger.identifier, x: finger.clientX, y: finger.clientY, timer: 0, reading: false };
      press = next;
      next.timer = window.setTimeout(() => {
        if (press !== next || !tile.isConnected) return;
        next.reading = true;
        suppressTap = true;
        preview(tile);
      }, HOLD_MS);
    };
    const move = (event: TouchEvent) => {
      if (!press) return;
      const finger = event.touches[0];
      if (event.touches.length !== 1 || finger.identifier !== press.id) { cancel(); return; }
      if (!press.reading) {
        if (Math.hypot(finger.clientX - press.x, finger.clientY - press.y) >= MOVE_THRESHOLD) cancel();
        return;
      }
      if (!event.cancelable) { cancel(); return; }
      event.preventDefault();
      const tile = tileAt(scroller, document.elementFromPoint(finger.clientX, finger.clientY));
      if (tile) preview(tile);
    };
    const end = (event: TouchEvent) => {
      if (!press || !Array.from(event.changedTouches).some((finger) => finger.identifier === press?.id)) return;
      if (press.reading && event.cancelable) event.preventDefault();
      clearPress();
    };
    const click = (event: MouseEvent) => {
      if (!suppressTap || !event.detail) return;
      suppressTap = false;
      event.preventDefault();
      event.stopPropagation();
    };
    const pointerDown = (event: PointerEvent) => {
      if (event.pointerType !== 'touch') suppressTap = false;
    };
    const contextMenu = (event: MouseEvent) => { if (press) event.preventDefault(); };

    scroller.addEventListener('touchstart', start, { passive: true });
    // Preserve native scrolling until the hold wins the gesture.
    scroller.addEventListener('touchmove', move, { passive: false });
    scroller.addEventListener('touchend', end, { passive: false });
    scroller.addEventListener('touchcancel', cancel);
    scroller.addEventListener('click', click, true);
    scroller.addEventListener('pointerdown', pointerDown);
    scroller.addEventListener('contextmenu', contextMenu);
    window.addEventListener('scroll', cancel, { capture: true, passive: true });
    window.addEventListener('blur', cancel);
    document.addEventListener('visibilitychange', cancel);
    return () => {
      clearPress();
      scroller.removeEventListener('touchstart', start);
      scroller.removeEventListener('touchmove', move);
      scroller.removeEventListener('touchend', end);
      scroller.removeEventListener('touchcancel', cancel);
      scroller.removeEventListener('click', click, true);
      scroller.removeEventListener('pointerdown', pointerDown);
      scroller.removeEventListener('contextmenu', contextMenu);
      window.removeEventListener('scroll', cancel, true);
      window.removeEventListener('blur', cancel);
      document.removeEventListener('visibilitychange', cancel);
    };
  }, [scrollRef, mode, preview]);
}
