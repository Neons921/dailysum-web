import { useLayoutEffect, useMemo, useRef, useState, type CSSProperties, type KeyboardEvent } from 'react';
import { Plus, ReceiptText } from 'lucide-react';
import { AndroidLedgerRow } from '../android/AndroidLedgerRow';
import { AndroidRecordActions } from '../android/AndroidRecordActions';
import { isAndroid } from '../app/android';
import { DimeTransactionRow } from '../dime/DimeTransactionRow';
import { offsetDay, type DateRange } from '../domain/dates';
import { convertedMinor, roundMinor } from '../domain/fx';
import type { Category, Currency, FxRate, Transaction } from '../domain/models';
import { formatMoney } from '../domain/money';
import type { ReportTotal } from '../domain/reports';
import { calendarWeeks, spendingCalendar } from '../domain/spendingCalendar';
import { Modal } from './Modal';
import { Money } from './Money';

const fullDate = new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' });
const weekday = new Intl.DateTimeFormat('zh-CN', { weekday: 'long', timeZone: 'UTC' });
const arrowDays: Record<string, number | undefined> = { ArrowLeft: -7, ArrowRight: 7, ArrowUp: -1, ArrowDown: 1 };
const heatLevels = [0, 1, 2, 3, 4];
const dateValue = (date: string) => new Date(`${date}T12:00:00Z`);

function DayAmount({ total, currency }: { total?: ReportTotal; currency: Currency }) {
  return total?.missing ? <span className="heatmap-pending">待折算</span> : <Money minor={total?.amount ?? 0n} currency={currency} />;
}

export function SpendingHeatmap({ range, today, transactions, categories, currency, rates, demo, onNew, onEdit, onDelete }: {
  range: DateRange;
  today: string;
  transactions: Transaction[];
  categories: Category[];
  currency: Currency;
  rates: FxRate[];
  demo: boolean;
  onNew: (date: string) => void;
  onEdit: (transaction: Transaction) => void;
  onDelete: (transaction: Transaction) => void;
}) {
  const weeks = useMemo(() => calendarWeeks(range), [range]);
  const months = weeks.flatMap((week, column) => {
    const first = week.find((date) => date?.endsWith('-01'));
    return first ? [{ label: `${Number(first.slice(5, 7))}月`, column: column + 1 }] : [];
  });
  const { days, rateMap } = useMemo(() => spendingCalendar(range, transactions, currency, rates), [range, transactions, currency, rates]);
  const labels = useMemo(() => {
    const zero = formatMoney(0n, currency);
    return new Map(weeks.flat().flatMap((date) => {
      if (!date) return [];
      const day = days.get(date);
      const expense = day?.report.expense;
      const amount = expense ? formatMoney(expense.amount, currency) : zero;
      const label = expense?.missing ? '支出待折算' : `支出 ${amount}`;
      return [[date, `${fullDate.format(dateValue(date))}，${label}，${day?.records.length ?? 0} 笔记录`]];
    }));
  }, [weeks, days, currency]);
  const [focusedDate, setFocusedDate] = useState(range.to);
  const [hoveredDate, setHoveredDate] = useState<string | null>(null);
  const [detailDate, setDetailDate] = useState<string | null>(null);
  const [actionId, setActionId] = useState<string | null>(null);
  const readingDate = hoveredDate ?? focusedDate;
  const reading = days.get(readingDate)?.report.expense;
  const detail = detailDate ? days.get(detailDate) : undefined;
  const records = [...(detail?.records ?? [])].sort((a, b) => b.createdAt.localeCompare(a.createdAt) || a.id.localeCompare(b.id));
  const categoryMap = new Map(categories.map((category) => [category.id, category]));
  const actionTarget = !demo && actionId ? records.find((row) => row.id === actionId) : undefined;
  const scrollRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const closeDay = () => { setDetailDate(null); setActionId(null); };

  useLayoutEffect(() => {
    const scroller = scrollRef.current!;
    let followEnd = true;
    const trackPosition = () => {
      followEnd = scroller.scrollWidth - scroller.clientWidth - scroller.scrollLeft < 2;
      scroller.toggleAttribute('data-earlier', scroller.scrollLeft > 2);
      scroller.toggleAttribute('data-later', !followEnd);
    };
    const scrollToEnd = () => {
      if (followEnd) scroller.scrollLeft = scroller.scrollWidth;
      trackPosition();
    };
    scrollToEnd();
    scroller.addEventListener('scroll', trackPosition, { passive: true });
    const observer = new ResizeObserver(scrollToEnd);
    observer.observe(scroller);
    return () => { observer.disconnect(); scroller.removeEventListener('scroll', trackPosition); };
  }, []);

  const move = (event: KeyboardEvent<HTMLButtonElement>, date: string) => {
    const offset = arrowDays[event.key];
    if (offset === undefined) return;
    event.preventDefault();
    const next = offsetDay(date, offset);
    if (next < range.from || next > range.to) return;
    gridRef.current?.querySelector<HTMLButtonElement>(`button[data-date="${next}"]`)?.focus();
  };

  return <>
    <section className="analysis-heatmap" aria-labelledby="analysis-heatmap-title">
      <header className="heatmap-heading">
        <h2 id="analysis-heatmap-title">消费热图</h2>
        <p><time dateTime={range.from.slice(0, 7)}>{range.from.slice(0, 7).replace('-', '.')}</time><span> – </span><time dateTime={range.to.slice(0, 7)}>{range.to.slice(0, 7).replace('-', '.')}</time></p>
      </header>
      <div className="heatmap-scroll" ref={scrollRef}>
        <div className="heatmap-stage" style={{ '--heatmap-columns': weeks.length } as CSSProperties}>
          <div className="heatmap-grid" role="grid" aria-label="每日支出热图，方向键切换日期，回车查看明细" ref={gridRef} onPointerLeave={() => setHoveredDate(null)}>
            {Array.from({ length: 7 }, (_, row) => <div className="heatmap-row" role="row" key={row}>
              {weeks.map((week, column) => {
                const date = week[row];
                if (!date) return <span key={column} aria-hidden="true" />;
                const day = days.get(date);
                return <span role="gridcell" key={column}>
                  <button type="button" className="heatmap-day" data-date={date} data-heat={day?.heat ?? 0}
                    data-pending={Boolean(day?.report.expense.missing) || undefined} data-reading={date === readingDate || undefined} aria-current={date === today ? 'date' : undefined}
                    aria-label={labels.get(date)} aria-haspopup="dialog"
                    tabIndex={date === focusedDate ? 0 : -1} onFocus={() => { setFocusedDate(date); setHoveredDate(null); }}
                    onPointerEnter={(event) => { if (event.pointerType === 'mouse') setHoveredDate(date); }}
                    onKeyDown={(event) => move(event, date)} onClick={() => { setFocusedDate(date); setDetailDate(date); }} />
                </span>;
              })}
            </div>)}
          </div>
          <div className="heatmap-months" aria-hidden="true">{months.map(({ label, column }, index) =>
            <span key={column} style={{ gridColumn: `${column} / ${months[index + 1]?.column ?? -1}` }}>{label}</span>)}</div>
        </div>
      </div>
      <footer className="heatmap-footer">
        <p className="heatmap-reading"><time dateTime={readingDate}>{Number(readingDate.slice(5, 7))}月{Number(readingDate.slice(8))}日</time><strong><DayAmount total={reading} currency={currency} /></strong></p>
        <div className="heatmap-legend" aria-label="支出从少到多"><span>少</span>{heatLevels.map((level) => <i key={level} data-heat={level} aria-hidden="true" />)}<span>多</span></div>
      </footer>
    </section>
    {detailDate && <Modal title={fullDate.format(dateValue(detailDate))} subtitle={weekday.format(dateValue(detailDate))}
      className={isAndroid ? 'mobile-sheet heatmap-detail' : 'heatmap-detail'} onClose={closeDay}>
      <div className="heatmap-detail-body">
        <dl className="heatmap-day-totals">
          <div><dt>支出</dt><dd><DayAmount total={detail?.report.expense} currency={currency} /></dd></div>
          <div><dt>收入</dt><dd><DayAmount total={detail?.report.income} currency={currency} /></dd></div>
        </dl>
        {records.length ? <ul className="heatmap-records" aria-label="当天记录">{records.map((transaction) => {
          const category = categoryMap.get(transaction.categoryId);
          const amount = convertedMinor(transaction, currency, rateMap);
          const converted = amount === null ? null : roundMinor(amount);
          return <li key={transaction.id}>{isAndroid ? <AndroidLedgerRow transaction={transaction} category={category} converted={converted} preferred={currency}
            readOnly={demo} onActions={(row) => setActionId(row.id)} /> : <DimeTransactionRow transaction={transaction} category={category} converted={converted} reportCurrency={currency}
            readOnly={demo} onEdit={onEdit} onDelete={onDelete} />}</li>;
        })}</ul> : <p className="heatmap-empty"><ReceiptText size={18} aria-hidden="true" />当天暂无记录</p>}
      </div>
      <footer className="modal-footer">
        <button className="button secondary" type="button" onClick={closeDay}>关闭</button>
        {!demo && <button className="button primary" type="button" aria-label="在所选日期记一笔" onClick={() => onNew(detailDate)}><Plus size={17} aria-hidden="true" />记一笔</button>}
      </footer>
    </Modal>}
    {actionTarget && <AndroidRecordActions transaction={actionTarget} category={categoryMap.get(actionTarget.categoryId)}
      onClose={() => setActionId(null)} onEdit={() => { setActionId(null); onEdit(actionTarget); }} onDelete={() => { setActionId(null); onDelete(actionTarget); }} />}
  </>;
}
