import { useLayoutEffect, useMemo, useRef, useState, type CSSProperties, type KeyboardEvent, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Plus, ReceiptText } from 'lucide-react';
import { AndroidLedgerRow } from '../android/AndroidLedgerRow';
import { AndroidRecordActions } from '../android/AndroidRecordActions';
import { isAndroid } from '../app/android';
import { DimeTransactionRow } from '../dime/DimeTransactionRow';
import { offsetDay, type DateRange } from '../domain/dates';
import { convertedMinor, roundMinor } from '../domain/fx';
import type { Category, Currency, FxRate, Transaction } from '../domain/models';
import { formatMoney } from '../domain/money';
import { summarizeConverted, type ReportTotal } from '../domain/reports';
import { calendarWeeks, heatmapBuckets, spendingCalendar, type HeatmapBucket, type HeatmapMode } from '../domain/spendingCalendar';
import { Modal } from './Modal';
import { Money } from './Money';

const fullDate = new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' });
const shortDate = new Intl.DateTimeFormat('zh-CN', { month: 'long', day: 'numeric', timeZone: 'UTC' });
const weekday = new Intl.DateTimeFormat('zh-CN', { weekday: 'long', timeZone: 'UTC' });
const arrowDays: Record<string, number | undefined> = { ArrowLeft: -7, ArrowRight: 7, ArrowUp: -1, ArrowDown: 1 };
const modes = [{ id: 'day', label: '每天' }, { id: 'week', label: '每周' }, { id: 'cumulative', label: '累计总量' }] as const;
const metricLabels: Record<HeatmapMode, string> = { day: '支出', week: '周支出', cumulative: '累计支出' };
const heatLevels = [0, 1, 2, 3, 4];
const dateValue = (date: string) => new Date(`${date}T12:00:00Z`);

function DayAmount({ total, currency }: { total?: ReportTotal; currency: Currency }) {
  return total?.missing ? <span className="heatmap-pending">待折算</span> : <Money minor={total?.amount ?? 0n} currency={currency} />;
}

function pointDate(point: HeatmapBucket, mode: HeatmapMode) {
  const formatter = point.from.slice(0, 4) === point.to.slice(0, 4) ? shortDate : fullDate;
  const last = formatter.format(dateValue(point.to));
  if (mode === 'cumulative') return `截至 ${last}`;
  return point.from === point.to ? last : `${formatter.format(dateValue(point.from))} – ${last}`;
}

type TooltipAnchor = { date: string; button: HTMLButtonElement; trigger: 'pointer' | 'focus' };

function HeatmapTooltip({ anchor, scrollArea, point, mode, currency }: {
  anchor: TooltipAnchor;
  scrollArea: HTMLDivElement | null;
  point: HeatmapBucket;
  mode: HeatmapMode;
  currency: Currency;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const tooltip = ref.current!;
    const position = () => {
      const cell = anchor.button.getBoundingClientRect();
      const scrollBounds = scrollArea?.getBoundingClientRect();
      const viewport = document.documentElement;
      const start = Math.max(0, cell.left, scrollBounds?.left ?? 0);
      const end = Math.min(viewport.clientWidth, cell.right, scrollBounds?.right ?? viewport.clientWidth);
      if (!anchor.button.isConnected || start >= end || cell.bottom <= 0 || cell.top >= viewport.clientHeight) {
        tooltip.style.visibility = 'hidden';
        return;
      }
      const { width, height } = tooltip.getBoundingClientRect();
      const gap = 8;
      const verticalAnchor = mode === 'week' ? cell.top + cell.height / 2 : cell.top;
      const above = verticalAnchor - height - gap;
      const below = (mode === 'week' ? verticalAnchor : cell.bottom) + gap;
      const bottomLimit = viewport.clientHeight - height - gap;
      const top = above >= Math.max(gap, scrollBounds?.top ?? gap) || below > bottomLimit ? above : below;
      const left = (start + end - width) / 2;
      tooltip.style.left = `${Math.max(gap, Math.min(left, viewport.clientWidth - width - gap))}px`;
      tooltip.style.top = `${Math.max(gap, Math.min(top, bottomLimit))}px`;
      tooltip.style.visibility = 'visible';
    };
    position();
    window.addEventListener('scroll', position, { capture: true, passive: true });
    window.addEventListener('resize', position);
    return () => { window.removeEventListener('scroll', position, true); window.removeEventListener('resize', position); };
  }, [anchor, scrollArea, point, mode, currency]);

  return createPortal(<div className="heatmap-tooltip" role="tooltip" ref={ref}>
    <span>{pointDate(point, mode)}</span>
    <strong>{mode !== 'day' && <small>{metricLabels[mode]} </small>}<DayAmount total={point.total} currency={currency} /></strong>
  </div>, document.body);
}

type HeatmapProps = {
  range: DateRange;
  today: string;
  transactions: Transaction[];
  categories: Category[];
  currency: Currency;
  rates: FxRate[];
  demo: boolean;
  onNew: (date: string) => void;
  onEdit: (transaction: Transaction) => void;
  onDelete: (transaction: Transaction) => void;
};

export function SpendingHeatmap(props: HeatmapProps) {
  const [mode, setMode] = useState<HeatmapMode>('day');
  return <HeatmapPlot key={props.range.to} {...props} mode={mode} onMode={setMode} />;
}

function HeatmapPlot({ range, today, transactions, categories, currency, rates, demo, onNew, onEdit, onDelete, mode, onMode }: HeatmapProps & {
  mode: HeatmapMode;
  onMode: (mode: HeatmapMode) => void;
}) {
  const weeks = useMemo(() => calendarWeeks(range), [range]);
  const months = weeks.flatMap((week, column) => {
    const first = week.find((date) => date?.endsWith('-01'));
    return first ? [{ label: `${Number(first.slice(5, 7))}月`, column: column + 1 }] : [];
  });
  const { days, rateMap } = useMemo(() => spendingCalendar(range, transactions, currency, rates), [range, transactions, currency, rates]);
  const points = useMemo(() => heatmapBuckets(weeks, days, mode), [weeks, days, mode]);
  const weekly = mode === 'week';
  const weekPoints = weekly ? [...points.values()] : [];
  const labels = useMemo(() => {
    return new Map([...points.values()].map((point) => [point.to,
      `${mode === 'day' ? fullDate.format(dateValue(point.to)) : pointDate(point, mode)}，${metricLabels[mode]}${point.total.missing ? '待折算' : ` ${formatMoney(point.total.amount, currency)}`}`,
    ]));
  }, [points, mode, currency]);
  const [focusedDate, setFocusedDate] = useState(range.to);
  const [anchor, setAnchor] = useState<TooltipAnchor | null>(null);
  const [detailDate, setDetailDate] = useState<string | null>(null);
  const [actionId, setActionId] = useState<string | null>(null);
  const focusKey = weekly ? (weekPoints.find(({ from, to }) => focusedDate >= from && focusedDate <= to)?.to ?? range.to) : focusedDate;
  const tooltipPoint = anchor ? points.get(anchor.date) : undefined;
  const detail = detailDate ? points.get(detailDate) : undefined;
  const records = detail
    ? (weekly ? [...days].flatMap(([date, day]) => date >= detail.from && date <= detail.to ? day.records : []) : [...(days.get(detail.to)?.records ?? [])])
      .sort((a, b) => b.occurredOn.localeCompare(a.occurredOn) || b.createdAt.localeCompare(a.createdAt) || a.id.localeCompare(b.id))
    : [];
  const detailReport = detail && (weekly ? summarizeConverted(records, currency, rateMap) : days.get(detail.to)?.report);
  const categoryMap = new Map(categories.map((category) => [category.id, category]));
  const actionTarget = !demo && actionId ? records.find((row) => row.id === actionId) : undefined;
  const scrollRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const closeDay = () => { setDetailDate(null); setActionId(null); };
  const dismiss = (button: HTMLButtonElement, trigger: TooltipAnchor['trigger']) => {
    setAnchor((current) => current?.button === button && current.trigger === trigger ? null : current);
  };

  useLayoutEffect(() => {
    const scroller = scrollRef.current!;
    let followEnd = true;
    const trackPosition = () => {
      followEnd = scroller.scrollWidth - scroller.clientWidth - scroller.scrollLeft < 2;
      scroller.toggleAttribute('data-earlier', scroller.scrollLeft > 2);
      scroller.toggleAttribute('data-later', !followEnd);
    };
    const scrollToEnd = () => {
      if (followEnd) scroller.scrollLeft = scroller.scrollWidth;
      trackPosition();
    };
    scrollToEnd();
    scroller.addEventListener('scroll', trackPosition, { passive: true });
    const observer = new ResizeObserver(scrollToEnd);
    observer.observe(scroller);
    return () => { observer.disconnect(); scroller.removeEventListener('scroll', trackPosition); };
  }, []);

  const move = (event: KeyboardEvent<HTMLButtonElement>, date: string) => {
    if (event.key === 'Escape') { setAnchor(null); return; }
    const offset = arrowDays[event.key];
    if (offset === undefined || (weekly && Math.abs(offset) !== 7)) return;
    event.preventDefault();
    const next = weekly ? weekPoints[weekPoints.findIndex((point) => point.to === date) + offset / 7]?.to : offsetDay(date, offset);
    if (!next || next < range.from || next > range.to) return;
    gridRef.current?.querySelector<HTMLButtonElement>(`button[data-date="${next}"]`)?.focus();
  };

  const tile = (point: HeatmapBucket, marks?: ReactNode) => <button type="button" className={weekly ? 'heatmap-week' : 'heatmap-day'}
    data-date={point.to} data-heat={point.heat} data-pending={Boolean(point.total.missing) || undefined}
    data-reading={point.to === (anchor?.date ?? focusKey) || undefined} aria-current={point.to === today ? 'date' : undefined}
    aria-label={labels.get(point.to)} aria-haspopup="dialog" tabIndex={point.to === focusKey ? 0 : -1}
    onFocus={(event) => {
      setFocusedDate(point.to);
      if (event.currentTarget.matches(':focus-visible')) setAnchor({ date: point.to, button: event.currentTarget, trigger: 'focus' });
    }}
    onBlur={(event) => dismiss(event.currentTarget, 'focus')}
    onPointerEnter={(event) => { if (event.pointerType === 'mouse') setAnchor({ date: point.to, button: event.currentTarget, trigger: 'pointer' }); }}
    onPointerLeave={(event) => dismiss(event.currentTarget, 'pointer')}
    onKeyDown={(event) => move(event, point.to)}
    onClick={() => { setAnchor(null); setFocusedDate(point.to); setDetailDate(point.to); }}>
    {marks}
  </button>;

  return <>
    <section className="analysis-heatmap" aria-labelledby="analysis-heatmap-title">
      <header className="heatmap-heading">
        <h2 id="analysis-heatmap-title">消费热图</h2>
        <div className="heatmap-modes" role="group" aria-label="热图统计口径">
          {modes.map(({ id, label }) => <button type="button" key={id} aria-pressed={mode === id} onClick={() => { setAnchor(null); onMode(id); }}>{label}</button>)}
        </div>
      </header>
      <div className="heatmap-scroll" ref={scrollRef}>
        <div className="heatmap-stage" style={{ '--heatmap-columns': weeks.length } as CSSProperties}>
          {weekly
            ? <div className="heatmap-weeks" role="group" aria-label="每周支出热图，左右键切换周，回车查看明细" ref={gridRef}>
              {weekPoints.map((point, column) => <span key={point.to}>
                {tile(point, weeks[column].map((date, row) => <i aria-hidden="true" key={row} data-empty={!date || undefined} />))}
              </span>)}
            </div>
            : <div className="heatmap-grid" role="grid" aria-label={`${mode === 'day' ? '每日支出热图' : '累计支出热图'}，方向键切换日期，回车查看明细`} ref={gridRef}>
              {Array.from({ length: 7 }, (_, row) => <div className="heatmap-row" role="row" key={row}>
                {weeks.map((week, column) => {
                  const date = week[row];
                  return date ? <span role="gridcell" key={column}>{tile(points.get(date)!)}</span> : <span key={column} aria-hidden="true" />;
                })}
              </div>)}
            </div>}
          <div className="heatmap-months" aria-hidden="true">{months.map(({ label, column }, index) =>
            <span key={column} style={{ gridColumn: `${column} / ${months[index + 1]?.column ?? -1}` }}>{label}</span>)}</div>
        </div>
      </div>
      <footer className="heatmap-footer">
        <p className="heatmap-range"><time dateTime={range.from.slice(0, 7)}>{range.from.slice(0, 7).replace('-', '.')}</time><span> – </span><time dateTime={range.to.slice(0, 7)}>{range.to.slice(0, 7).replace('-', '.')}</time></p>
        <div className="heatmap-legend" aria-label="支出从少到多"><span>少</span>{heatLevels.map((level) => <i key={level} data-heat={level} aria-hidden="true" />)}<span>多</span></div>
      </footer>
    </section>
    {anchor && tooltipPoint && !detail && <HeatmapTooltip anchor={anchor} scrollArea={scrollRef.current} point={tooltipPoint} mode={mode} currency={currency} />}
    {detail && <Modal title={weekly ? pointDate(detail, mode) : fullDate.format(dateValue(detail.to))}
      subtitle={weekly ? '每周收支' : weekday.format(dateValue(detail.to))}
      className={isAndroid ? 'mobile-sheet heatmap-detail' : 'heatmap-detail'} onClose={closeDay}>
      <div className="heatmap-detail-body">
        {mode === 'cumulative' && <div className="heatmap-aggregate"><span>累计支出</span><strong><DayAmount total={detail.total} currency={currency} /></strong></div>}
        <dl className="heatmap-day-totals">
          <div><dt>支出</dt><dd><DayAmount total={detailReport?.expense} currency={currency} /></dd></div>
          <div><dt>收入</dt><dd><DayAmount total={detailReport?.income} currency={currency} /></dd></div>
        </dl>
        {records.length ? <ul className="heatmap-records" aria-label={weekly ? '本周记录' : '当天记录'}>{records.map((transaction, index) => {
          const category = categoryMap.get(transaction.categoryId);
          const amount = convertedMinor(transaction, currency, rateMap);
          const converted = amount === null ? null : roundMinor(amount);
          return <li key={transaction.id}>
            {weekly && transaction.occurredOn !== records[index - 1]?.occurredOn && <time className="heatmap-record-date" dateTime={transaction.occurredOn}>{shortDate.format(dateValue(transaction.occurredOn))}</time>}
            {isAndroid ? <AndroidLedgerRow transaction={transaction} category={category} converted={converted} preferred={currency}
            readOnly={demo} onActions={(row) => setActionId(row.id)} /> : <DimeTransactionRow transaction={transaction} category={category} converted={converted} reportCurrency={currency}
            readOnly={demo} onEdit={onEdit} onDelete={onDelete} />}</li>;
        })}</ul> : <p className="heatmap-empty"><ReceiptText size={18} aria-hidden="true" />{weekly ? '本周暂无记录' : '当天暂无记录'}</p>}
      </div>
      <footer className="modal-footer">
        <button className="button secondary" type="button" onClick={closeDay}>关闭</button>
        {!demo && !weekly && <button className="button primary" type="button" aria-label="在所选日期记一笔" onClick={() => onNew(detail.to)}><Plus size={17} aria-hidden="true" />记一笔</button>}
      </footer>
    </Modal>}
    {actionTarget && <AndroidRecordActions transaction={actionTarget} category={categoryMap.get(actionTarget.categoryId)}
      onClose={() => setActionId(null)} onEdit={() => { setActionId(null); onEdit(actionTarget); }} onDelete={() => { setActionId(null); onDelete(actionTarget); }} />}
  </>;
}
