import { useRef, useState } from 'react';
import { Search, X } from 'lucide-react';
import type { Category } from '../domain/models';
import { CategoryIcon } from './CategoryIcon';
import { categoryGlyphGroups, categoryGlyphId } from './categoryGlyphs';

export function CategoryIconPicker({ category, disabled, onChange }: {
  category: Category;
  disabled: boolean;
  onChange: (id: string) => void;
}) {
  const [query, setQuery] = useState('');
  const [groupId, setGroupId] = useState('');
  const results = useRef<HTMLDivElement>(null);
  const search = useRef<HTMLInputElement>(null);
  const selected = categoryGlyphId(category);
  const terms = query.trim().normalize('NFKC').toLowerCase().split(/\s+/).filter(Boolean);
  const groups = categoryGlyphGroups
    .filter((group) => !groupId || group.id === groupId)
    .map((group) => ({
      ...group,
      icons: group.icons.filter((icon) => {
        const text = `${icon.label} ${icon.keywords ?? ''} ${icon.id} ${group.label}`.toLowerCase();
        return terms.every((term) => text.includes(term));
      }),
    }))
    .filter((group) => group.icons.length);
  const total = groups.reduce((count, group) => count + group.icons.length, 0);
  const changeQuery = (value: string) => {
    setQuery(value);
    setGroupId('');
    results.current?.scrollTo({ top: 0 });
  };

  return <fieldset className="category-icon-field" disabled={disabled}>
    <legend>分类图标</legend>
    <div className="category-icon-search">
      <Search size={17} aria-hidden="true" />
      <input ref={search} type="search" aria-label="搜索图标" placeholder="搜索图标，例如油费、水果"
        value={query} onChange={(event) => changeQuery(event.target.value)}
        onKeyDown={(event) => { if (event.key === 'Enter') event.preventDefault(); }} />
      {query && <button type="button" className="icon-button" aria-label="清除图标搜索"
        onClick={() => { changeQuery(''); search.current?.focus(); }}><X size={16} /></button>}
    </div>
    <div className="category-icon-groups" role="group" aria-label="图标分组">
      {[{ id: '', label: '全部', tab: '全部' }, ...categoryGlyphGroups].map((group) =>
        <button type="button" key={group.id} aria-label={group.label} aria-pressed={groupId === group.id} onClick={() => {
          setGroupId(group.id);
          results.current?.scrollTo({ top: 0 });
        }}>{group.tab}</button>,
      )}
    </div>
    <p className="category-icon-count" role="status">{total} 个图标</p>
    <div className="category-icon-results" ref={results}>
      {groups.length ? groups.map((group) => <section className="category-icon-group" key={group.id} aria-label={group.label}>
        <h3>{group.label}</h3>
        <div className="category-icon-library">{group.icons.map(({ id, label }) =>
          <label key={id} className="category-icon-option">
            <input type="radio" className="sr-only" name="category-glyph" checked={selected === id} onChange={() => onChange(id)} />
            <CategoryIcon category={{ ...category, id: '', icon: id }} size={19} />
            <span>{label}</span>
          </label>,
        )}</div>
      </section>) : <p className="category-icon-empty">没有找到图标</p>}
    </div>
  </fieldset>;
}
