import { Check, ChevronDown, type LucideIcon } from 'lucide-react';
import { Popover } from './Popover';

export type SelectOption = { value: string; label: string; description?: string; icon?: LucideIcon };
export function Select({ label, value, onChange, options, className = '', width = 225 }: {
  label: string; value: string; onChange: (value: string) => void; options: SelectOption[]; className?: string; width?: number;
}) {
  const selected = options.find((option) => option.value === value) ?? options[0];
  return <Popover label={label} role="listbox" className={`custom-select ${className}`} panelClassName="select-menu" width={width}
    trigger={<><span>{selected?.label}</span><ChevronDown size={14} aria-hidden="true" /></>}>
    {({ close }) => <div onKeyDown={(event) => {
      const buttons = [...event.currentTarget.querySelectorAll<HTMLButtonElement>('[role="option"]')];
      const index = buttons.indexOf(document.activeElement as HTMLButtonElement);
      let next: number | undefined;
      if (event.key === 'ArrowDown') next = (index + 1) % buttons.length;
      if (event.key === 'ArrowUp') next = (index - 1 + buttons.length) % buttons.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = buttons.length - 1;
      if (event.key.length === 1 && event.key !== ' ') next = options.findIndex((option) => option.label.toLocaleLowerCase().startsWith(event.key.toLocaleLowerCase()));
      if (next !== undefined && next >= 0) { event.preventDefault(); buttons[next]?.focus(); }
    }}>{options.map(({ value: key, label: text, description, icon: Icon }) => <button type="button" key={key || '__all'} role="option" aria-selected={key === value} data-selected={key === value} data-value={key} tabIndex={key === value ? 0 : -1}
      className="select-option" onClick={() => { onChange(key); close(); }}>
      {Icon && <Icon size={17} aria-hidden="true" />}<span>{text}{description && <small>{description}</small>}</span><Check size={15} aria-hidden="true" className={key === value ? 'option-check' : 'option-check hidden-check'} />
    </button>)}</div>}
  </Popover>;
}
