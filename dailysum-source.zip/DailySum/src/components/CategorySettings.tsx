import { useRef, useState } from 'react';
import { Check, Pencil, Plus, Trash2 } from 'lucide-react';
import { isAndroid } from '../app/android';
import { fallbackCategoryId } from '../domain/categories';
import type { Category, TransactionType } from '../domain/models';
import { describeError } from '../services/errors';
import { CategoryIcon } from './CategoryIcon';
import { CategoryIconPicker } from './CategoryIconPicker';
import { ConfirmDialog, Modal } from './Modal';

type CategoryDraft = Pick<Category, 'name' | 'type' | 'icon'>;
type Editor = { type: TransactionType; category?: Category };

export function CategorySettings({ categories, onSave, onDelete }: {
  categories: Category[];
  onSave: (draft: CategoryDraft, previous?: Category) => Promise<void>;
  onDelete: (category: Category, destinationId: string) => Promise<void>;
}) {
  const [editor, setEditor] = useState<Editor | null>(null);
  return <section className="settings-section">
    <div className="section-title category-settings-title">
      <h2>分类</h2><span className="subtle-badge">{categories.length}</span>
      <button type="button" className="button secondary category-settings-add" onClick={() => setEditor({ type: 'expense' })}>
        <Plus size={16} />新增分类
      </button>
    </div>
    {(['expense', 'income'] as const).map((type) => <div className="settings-categories" key={type}>
      <h3>{type === 'expense' ? '支出' : '收入'}</h3>
      <div>{categories.filter((category) => category.type === type).map((category) =>
        <button type="button" key={category.id} className="settings-category" onClick={() => setEditor({ type, category })}
          aria-label={`编辑分类 ${category.name}（${type === 'expense' ? '支出' : '收入'}）`}>
          <CategoryIcon category={category} size={16} /><span>{category.name}</span><Pencil size={12} aria-hidden="true" />
        </button>,
      )}</div>
    </div>)}
    {editor && <CategoryEditor editor={editor} destinations={categories.filter((category) => category.type === editor.type && category.id !== editor.category?.id)}
      onClose={() => setEditor(null)} onSave={onSave} onDelete={onDelete} />}
  </section>;
}

function CategoryEditor({ editor, destinations, onClose, onSave, onDelete }: {
  editor: Editor;
  destinations: Category[];
  onClose: () => void;
  onSave: (draft: CategoryDraft, previous?: Category) => Promise<void>;
  onDelete: (category: Category, destinationId: string) => Promise<void>;
}) {
  const previous = editor.category;
  const [draft, setDraft] = useState<CategoryDraft>({
    name: previous?.name ?? '', type: editor.type, icon: previous?.icon ?? 'other',
  });
  const [deleting, setDeleting] = useState(false);
  const [destinationId, setDestinationId] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const pending = useRef(false);
  const nameRef = useRef<HTMLInputElement>(null);
  const preview = { ...draft, id: previous?.id ?? '', color: previous?.color ?? 'gray', sortOrder: previous?.sortOrder ?? 0 };
  const destination = destinations.find((category) => category.id === destinationId);
  const run = async (action: () => Promise<void>) => {
    if (pending.current) return;
    pending.current = true;
    setBusy(true);
    setError('');
    try {
      await action();
      onClose();
    } catch (cause) {
      setError(describeError(cause));
    } finally {
      pending.current = false;
      setBusy(false);
    }
  };

  return <>
    <Modal title={previous ? '编辑分类' : '新增分类'} onClose={onClose} busy={busy}
      className="category-editor" initialFocus={isAndroid ? undefined : nameRef}>
      <form onSubmit={(event) => { event.preventDefault(); void run(() => onSave(draft, previous)); }}>
        <div className="category-editor-content">
          {!previous && <div className="segment-control category-editor-type" role="group" aria-label="收支类型">
            <button type="button" aria-pressed={draft.type === 'expense'} disabled={busy}
              onClick={() => setDraft({ ...draft, type: 'expense' })}>支出</button>
            <button type="button" aria-pressed={draft.type === 'income'} disabled={busy}
              onClick={() => setDraft({ ...draft, type: 'income' })}>收入</button>
          </div>}
          <div className="category-editor-name">
            <CategoryIcon category={preview} size={23} />
            <label>分类名称<input ref={nameRef} value={draft.name} maxLength={200} required
              placeholder="例如：运动" disabled={busy} onChange={(event) => setDraft({ ...draft, name: event.target.value })} /></label>
          </div>
          <CategoryIconPicker category={preview} disabled={busy} onChange={(icon) => setDraft({ ...draft, icon })} />
          {error && !deleting && <p className="form-error" role="alert">{error}</p>}
        </div>
        <footer className="modal-footer category-editor-footer">
          {previous && previous.id !== fallbackCategoryId(previous.type) &&
            <button type="button" className="text-button category-delete" disabled={busy}
              onClick={() => { setError(''); setDestinationId(''); setDeleting(true); }}><Trash2 size={16} />删除分类</button>}
          <button type="button" className="button secondary" onClick={onClose} disabled={busy}>取消</button>
          <button type="submit" className="button primary" disabled={busy || !draft.name.trim()}>{busy ? '保存中…' : '保存分类'}</button>
        </footer>
      </form>
    </Modal>
    {deleting && previous && <ConfirmDialog title={`删除「${previous.name}」？`} confirmLabel="删除并转移"
      onClose={() => { setDeleting(false); setError(''); }} onConfirm={() => destination && void run(() => onDelete(previous, destination.id))}
      busy={busy} confirmDisabled={!destination} error={error} danger>
      <fieldset className="category-destinations" disabled={busy}>
        <legend>旧账目转入</legend>
        <p>选择一个{previous.type === 'expense' ? '支出' : '收入'}分类。账目的金额和备注会保留。</p>
        <div className="category-destination-list">
          {destinations.map((category) => <label className="category-destination" key={category.id}>
            <input type="radio" className="sr-only" name="category-destination" checked={destinationId === category.id}
              onChange={() => setDestinationId(category.id)} />
            <CategoryIcon category={category} size={16} />
            <span>{category.name}</span><Check size={16} aria-hidden="true" />
          </label>)}
        </div>
      </fieldset>
    </ConfirmDialog>}
  </>;
}
