import { Check } from 'lucide-react';
import type { Currency } from '../domain/models';
import { CURRENCY_META } from '../domain/money';

export function CurrencyToggle({ value, onChange, label = '记账币种', disabled = false, compact = false }: {
  value: Currency;
  onChange: (currency: Currency) => void;
  label?: string;
  disabled?: boolean;
  compact?: boolean;
}) {
  return <div className={`currency-toggle ${compact ? 'compact' : ''}`} role="group" aria-label={label}>
    {(['HKD', 'CNY'] as const).map((currency) => <button
      type="button" key={currency} aria-pressed={value === currency}
      className={value === currency ? 'selected' : ''}
      onClick={() => onChange(currency)} disabled={disabled}
    >
      <span className="currency-symbol">{CURRENCY_META[currency].symbol}</span>
      <span>{CURRENCY_META[currency].name}</span>
      {!compact && <small>{currency}</small>}
      {value === currency && <Check size={13} aria-hidden="true" />}
    </button>)}
  </div>;
}
