import { useRef, useState } from 'react';
import { Check, ListFilter, Utensils, Wallet, Zap } from 'lucide-react';
import type { Category, Currency } from '../domain/models';
import { amountToInput } from '../domain/money';
import { emptyReportRules, parseRuleAmount, reportRulesSchema, splitKeywords, type ReportRules, type SavedReportFilter } from '../domain/reportFilters';
import { describeError } from '../services/errors';
import { CategoryIcon } from './CategoryIcon';
import { CurrencyToggle } from './CurrencyToggle';
import { Modal } from './Modal';
import { Select } from './Select';

export function ReportFilterDialog({ categories, currency, rules, previous, onApply, onSave, onClose }: {
  categories: Category[]; currency: Currency; rules?: ReportRules; previous?: SavedReportFilter;
  onApply: (rules: ReportRules) => Promise<void>; onSave: (name: string, rules: ReportRules, previous?: SavedReportFilter) => Promise<void>; onClose: () => void;
}) {
  const source = rules ?? emptyReportRules(currency);
  const [draft, setDraft] = useState(() => structuredClone(source));
  const [name, setName] = useState(previous?.name ?? '');
  const [categoryMode, setCategoryMode] = useState<'all' | 'include' | 'exclude'>(source.includeCategoryIds.length ? 'include' : source.excludeCategoryIds.length ? 'exclude' : 'all');
  const [minimum, setMinimum] = useState(source.minAmountMinor === null ? '' : amountToInput(source.minAmountMinor));
  const [maximum, setMaximum] = useState(source.maxAmountMinor === null ? '' : amountToInput(source.maxAmountMinor));
  const [includeText, setIncludeText] = useState(source.includeKeywords.join('，'));
  const [excludeText, setExcludeText] = useState(source.excludeKeywords.join('，'));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const errorRef = useRef<HTMLParagraphElement>(null);
  const patch = (value: Partial<ReportRules>) => setDraft((old) => ({ ...old, ...value }));
  const template = (kind: 'daily' | 'large' | 'utilities') => {
    const next = emptyReportRules(currency); next.type = 'expense';
    if (kind === 'daily') { next.includeCategoryIds = ['food', 'transport']; setName('日常餐饮交通'); }
    if (kind === 'large') { next.maxAmountMinor = 50000; setName('排除大额支出'); }
    if (kind === 'utilities') { next.excludeKeywords = ['水电费']; setName('排除水电费'); }
    setDraft(next); setCategoryMode(kind === 'daily' ? 'include' : 'all'); setMinimum(''); setMaximum(kind === 'large' ? '500.00' : ''); setIncludeText(''); setExcludeText(kind === 'utilities' ? '水电费' : ''); setError('');
  };
  const readRules = () => {
    if (categoryMode !== 'all' && !(categoryMode === 'include' ? draft.includeCategoryIds : draft.excludeCategoryIds).length) throw new Error('请选择至少一个分类，或切换为全部分类');
    const next = { ...draft, minAmountMinor: parseRuleAmount(minimum), maxAmountMinor: parseRuleAmount(maximum), includeKeywords: splitKeywords(includeText), excludeKeywords: splitKeywords(excludeText) };
    if (next.minAmountMinor !== null && next.maxAmountMinor !== null && next.minAmountMinor > next.maxAmountMinor) throw new Error('最低金额不能高于最高金额');
    if ([...next.includeKeywords, ...next.excludeKeywords].some((word) => word.length > 60)) throw new Error('单个关键词最多 60 字');
    return reportRulesSchema.parse(next);
  };
  const submit = async (save: boolean, asNew = false) => {
    if (busy) return;
    setError('');
    try {
      const next = readRules();
      if (save && !name.trim()) throw new Error('保存前请填写过滤器名称');
      setBusy(true);
      if (save) await onSave(name.trim(), next, asNew ? undefined : previous);
      else await onApply(next);
      onClose();
    } catch (cause) { setError(describeError(cause)); requestAnimationFrame(() => errorRef.current?.focus()); }
    finally { setBusy(false); }
  };
  return <Modal title={previous ? '编辑过滤器' : '自定义过滤器'} subtitle="条件同时满足的记录会纳入统计" onClose={onClose} busy={busy} className="filter-editor-modal">
    <fieldset className="filter-editor-body" disabled={busy}>
      {!previous && <div className="filter-templates" aria-label="过滤器模板"><button type="button" onClick={() => template('daily')}><Utensils size={17} />日常餐饮交通</button><button type="button" onClick={() => template('large')}><Wallet size={17} />排除大额</button><button type="button" onClick={() => template('utilities')}><Zap size={17} />排除水电费</button></div>}
      <section className="rule-section"><div className="rule-section-heading"><h3>收支类型</h3></div><Select label="过滤器收支类型" value={draft.type} onChange={(value) => {
        const type = value as ReportRules['type']; patch({ type, includeCategoryIds: draft.includeCategoryIds.filter((id) => !type || categories.find((category) => category.id === id)?.type === type), excludeCategoryIds: draft.excludeCategoryIds.filter((id) => !type || categories.find((category) => category.id === id)?.type === type) });
      }} options={[{ value: '', label: '全部收支' }, { value: 'expense', label: '仅支出' }, { value: 'income', label: '仅收入' }]} /></section>
      <section className="rule-section"><div className="rule-section-heading"><h3>分类</h3><div className="segment-control" aria-label="分类过滤方式">{([['all','全部分类'],['include','只包含'],['exclude','排除分类']] as const).map(([value, label]) => <button type="button" key={value} aria-pressed={categoryMode === value} onClick={() => { setCategoryMode(value); patch({ includeCategoryIds: [], excludeCategoryIds: [] }); }}>{label}</button>)}</div></div>
        {categoryMode !== 'all' && <div className="filter-category-grid" role="group" aria-label={categoryMode === 'include' ? '包含分类' : '排除分类'}>{categories.filter((category) => (!category.mergedIntoId||draft.includeCategoryIds.includes(category.id)||draft.excludeCategoryIds.includes(category.id))&&(!draft.type || category.type === draft.type)).map((category) => {
          const field = categoryMode === 'include' ? 'includeCategoryIds' : 'excludeCategoryIds', checked = draft[field].includes(category.id);
          return <button type="button" key={category.id} role="checkbox" aria-checked={checked} className={checked ? 'checked' : ''} onClick={() => patch({ [field]: checked ? draft[field].filter((id) => id !== category.id) : [...draft[field], category.id] })}><CategoryIcon category={category} size={16} /><span>{category.name}{category.name === '其他' && <small>{category.type === 'income' ? '收入' : '支出'}</small>}</span><span className="filter-check">{checked && <Check size={12} />}</span></button>;
        })}</div>}
      </section>
      <section className="rule-section"><div className="rule-section-heading"><h3>金额范围</h3><CurrencyToggle value={draft.amountCurrency} label="金额比较币种" compact onChange={(amountCurrency) => patch({ amountCurrency })} /></div><div className="amount-rule-inputs"><label>最低金额<input aria-label="过滤器最低金额" inputMode="decimal" value={minimum} onChange={(event) => setMinimum(event.target.value)} placeholder="不限" /></label><span>至</span><label>最高金额<input aria-label="过滤器最高金额" inputMode="decimal" value={maximum} onChange={(event) => setMaximum(event.target.value)} placeholder="不限" /></label></div><p className="rule-help">按交易日汇率折算为 {draft.amountCurrency} 后比较，包含边界金额。</p></section>
      <section className="rule-section"><div className="rule-section-heading"><h3>备注条件</h3><span>可选</span></div><div className="keyword-rule-inputs"><label>包含任一关键词<input aria-label="过滤器包含备注" value={includeText} onChange={(event) => setIncludeText(event.target.value)} placeholder="例如：午餐，地铁" maxLength={1800} /></label><label>排除任一关键词<input aria-label="过滤器排除备注" value={excludeText} onChange={(event) => setExcludeText(event.target.value)} placeholder="例如：水电费，报销" maxLength={1800} /></label></div><p className="rule-help">多个关键词用逗号分隔。</p></section>
      {draft.excludedTransactionIds.length > 0 && <div className="excluded-rule-note"><ListFilter size={15} /><span>另有 {draft.excludedTransactionIds.length} 笔手动排除记录</span><button className="text-button" type="button" onClick={() => patch({ excludedTransactionIds: [] })}>全部恢复纳入</button></div>}
      <section className="rule-section filter-name-section"><label htmlFor="filter-name">过滤器名称<span>保存后可重复使用</span></label><input id="filter-name" aria-label="过滤器名称" value={name} onChange={(event) => setName(event.target.value)} placeholder="例如：日常开支" maxLength={32} /></section>
      {error && <p className="form-error" role="alert" tabIndex={-1} ref={errorRef}>{error}</p>}
    </fieldset>
    <footer className="modal-footer filter-editor-footer"><button type="button" className="button secondary" disabled={busy} onClick={onClose}>取消</button>{previous && <button type="button" className="text-button save-filter-as" disabled={busy} onClick={() => { void submit(true, true); }}>另存为</button>}<button type="button" className="button secondary" disabled={busy} onClick={() => { void submit(false); }}>应用过滤器</button><button type="button" className="button primary" disabled={busy} onClick={() => { void submit(true); }}>{busy ? '处理中…' : '保存并应用'}</button></footer>
  </Modal>;
}
