/** GPL-3.0. Dime's amount hierarchy and colored income/expense summary blocks. */
import type { Currency, TransactionType } from '../domain/models';
import type { Report } from '../domain/reports';
import { Money } from './Money';
import { DimeSummaryBlock } from '../dime/DimeSummaryBlock';

export function SummaryCards({ report, preferred, onFilter, comparisons }: {
  report: Report;
  preferred: Currency;
  onFilter?: (type: TransactionType) => void;
  comparisons?: { expense: string | null; income: string | null };
}) {
  return <section className="converted-summary" aria-label="折算汇总">
    {(['expense', 'income'] as const).map((type) => <article className="converted-stat" key={type} data-testid={`summary-${type}`}>
      <DimeSummaryBlock income={type === 'income'} amount={report[type].missing ? null : report[type].amount} currency={preferred}
        onClick={onFilter ? () => onFilter(type) : undefined} />
      <div className="stat-foot"><span>{report[type].count} 笔</span>{comparisons && <span title="与上一个同长度期间比较">{comparisons[type] ? `${comparisons[type]} 较上期` : '上期无可比数据'}</span>}</div>
    </article>)}
    <article className="converted-stat stat-net" data-testid="summary-net">
      <div className="net-label"><span>结余</span><span className="report-currency">{preferred}</span></div>
      <strong className="money summary-amount">{report.net === null ? '待折算' : <Money minor={report.net} currency={preferred} positive />}</strong>
      <div className="stat-foot"><span>{report.missing ? `${report.missing} 笔缺少汇率` : '收入 − 支出'}</span></div>
    </article>
  </section>;
}
