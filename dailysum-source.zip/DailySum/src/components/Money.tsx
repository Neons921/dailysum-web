import type { Currency } from '../domain/models';
import { CURRENCY_META, formatMoney } from '../domain/money';

export function Money({minor,currency,positive=false,sign=''}:{minor:number|bigint;currency:Currency;positive?:boolean;sign?:string}) {
  const value=BigInt(minor),symbol=CURRENCY_META[currency].symbol;
  const prefix=value<0n?'−':sign||(positive&&value>0n?'+':'');
  const digits=formatMoney(value<0n?-value:value,currency).slice(symbol.length+1);
  return <span className="money-value"><span className="money-sign">{prefix}</span><span className="money-unit">{symbol}</span>{' '}<span className="money-digits">{digits}</span></span>;
}
