import { useCallback, useEffect, useId, useRef, useState, type ReactNode } from 'react';

/** Native top layer keeps custom controls usable inside modal dialogs. */
export function Popover({ label, trigger, children, className = '', panelClassName = '', width = 250, align = 'start', role = 'dialog', onOpen, initialFocus }: {
  label: string; trigger: ReactNode; children: (actions: { close: () => void }) => ReactNode;
  className?: string; panelClassName?: string; width?: number; align?: 'start' | 'end'; role?: 'dialog' | 'listbox'; onOpen?: () => void; initialFocus?: string;
}) {
  const id = useId();
  const button = useRef<HTMLButtonElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const [expanded, setExpanded] = useState(false);
  const [position, setPosition] = useState({ left: 0, top: 0, width });
  const place = useCallback(() => {
    if (!button.current) return;
    const bounds = button.current.getBoundingClientRect();
    const fitWidth = Math.min(width, window.innerWidth - 24);
    const panelHeight = panel.current?.getBoundingClientRect().height || 280;
    const below = bounds.bottom + 8, above = bounds.top - panelHeight - 8;
    const lastTop = Math.max(12, window.innerHeight - panelHeight - 12);
    setPosition({ width: fitWidth, left: Math.max(12, Math.min(window.innerWidth - fitWidth - 12, align === 'end' ? bounds.right - fitWidth : bounds.left)),
      top: below <= lastTop ? below : above >= 12 ? above : lastTop });
  }, [align, width]);
  useEffect(() => {
    if (!expanded) return;
    window.addEventListener('resize', place);
    return () => window.removeEventListener('resize', place);
  }, [expanded, place]);
  const close = () => { panel.current?.hidePopover(); button.current?.focus({ preventScroll: true }); };
  const open = () => {
    place(); onOpen?.(); panel.current?.showPopover(); setExpanded(true);
    panel.current?.querySelector<HTMLElement>(initialFocus ?? '[data-selected="true"], input:not(:disabled), button:not(:disabled)')?.focus({ preventScroll: true });
    requestAnimationFrame(place);
  };
  return <div className={`popover-anchor ${className}`}>
    <button type="button" ref={button} className="popover-trigger" aria-label={label} aria-expanded={expanded} aria-haspopup={role} aria-controls={id} popoverTarget={id}
      onClick={(event) => { event.preventDefault(); if (panel.current?.matches(':popover-open')) close(); else open(); }} onKeyDown={(event) => {
        if (event.key === 'ArrowDown' && !expanded) { event.preventDefault(); open(); }
      }}>{trigger}</button>
    <div id={id} ref={panel} popover="auto" role={role} aria-label={label} className={`custom-popover ${panelClassName}`} style={position}
      onKeyDown={(event) => { if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(); } }}
      onToggle={(event) => {
        setExpanded((event.nativeEvent as ToggleEvent).newState === 'open');
      }}>
      {children({ close })}
    </div>
  </div>;
}
