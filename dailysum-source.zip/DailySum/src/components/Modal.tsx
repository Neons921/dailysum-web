import { useEffect, useId, useRef, type ReactNode, type RefObject } from 'react';
import { X } from 'lucide-react';

export function Modal({ title, subtitle, children, onClose, initialFocus, className = '', busy = false, headerContent }: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  onClose: () => void;
  initialFocus?: RefObject<HTMLInputElement | null>;
  className?: string;
  busy?: boolean;
  headerContent?: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  useEffect(() => {
    const dialog = ref.current!;
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    dialog.showModal();
    const frame = requestAnimationFrame(() => initialFocus?.current?.focus());
    return () => {
      cancelAnimationFrame(frame);
      dialog.close();
      if (previous?.isConnected) previous.focus();
    };
  }, [initialFocus]);
  const closeButton = <button className="icon-button" type="button" aria-label="关闭弹窗" onClick={onClose} disabled={busy}><X size={19} /></button>;

  return <dialog ref={ref} aria-labelledby={titleId} className={`modal ${className}`}
    onCancel={(event) => { event.preventDefault(); if (!busy) onClose(); }}
    onKeyDown={(event) => {
      if (event.key !== 'Tab') return;
      const elements = [...event.currentTarget.querySelectorAll<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]',
      )].filter((element) => !element.matches(':disabled, [tabindex="-1"]') && element.getClientRects().length > 0);
      const first = elements[0];
      const last = elements.at(-1);
      if (!first || !last) { event.preventDefault(); return; }
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault(); last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault(); first.focus();
      }
    }}
    onClick={(event) => {
      if (event.target !== event.currentTarget || busy) return;
      const rect = event.currentTarget.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) onClose();
    }}>
    <header className={`modal-header ${headerContent ? 'dime-custom-header' : ''}`}>
      {headerContent ? <><h2 id={titleId} className="sr-only">{title}</h2>{closeButton}<div className="dime-header-content">{headerContent}</div></>
        : <div><h2 id={titleId}>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>}
      {!headerContent && closeButton}
    </header>
    {children}
  </dialog>;
}

export function ConfirmDialog({ title, children, confirmLabel, onConfirm, onClose, busy = false, confirmDisabled = false, danger = false, error }: {
  title: string;
  children: ReactNode;
  confirmLabel: string;
  onConfirm: () => void;
  onClose: () => void;
  busy?: boolean;
  confirmDisabled?: boolean;
  danger?: boolean;
  error?: string;
}) {
  return <Modal title={title} onClose={onClose} busy={busy} className="confirm-modal">
    <div className="confirm-content">{children}</div>
    {error && <p className="form-error" role="alert">{error}</p>}
    <footer className="modal-footer">
      <button className="button secondary" type="button" onClick={onClose} disabled={busy}>取消</button>
      <button className={`button ${danger ? 'danger' : 'primary'}`} type="button" onClick={onConfirm} disabled={busy || confirmDisabled}>{busy ? '处理中…' : confirmLabel}</button>
    </footer>
  </Modal>;
}
