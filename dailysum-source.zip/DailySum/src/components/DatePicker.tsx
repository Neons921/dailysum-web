import { useState } from 'react';
import { CalendarDays, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';
import { formatMonth, hongKongToday, offsetDay, shiftMonth, type DateRange } from '../domain/dates';
import { isValidDate } from '../domain/models';
import { Popover } from './Popover';

function MonthGrid({ month, onChange }: { month: string; onChange: (month: string) => void }) {
  const [year, setYear] = useState(Number(month.slice(0, 4)));
  return <div className="month-grid-panel"><header><button type="button" className="icon-button" aria-label="上一年" onClick={() => setYear((value) => value - 1)}><ChevronLeft size={17} /></button><strong>{year} 年</strong><button type="button" className="icon-button" aria-label="下一年" onClick={() => setYear((value) => value + 1)}><ChevronRight size={17} /></button></header>
    <div className="month-grid">{Array.from({ length: 12 }, (_, index) => {
      const value = `${year}-${String(index + 1).padStart(2, '0')}`;
      return <button type="button" key={value} data-selected={value === month} aria-pressed={value === month} onClick={() => onChange(value)}>{index + 1} 月</button>;
    })}</div></div>;
}
export function MonthPicker({ value, onChange }: { value: string; onChange: (month: string) => void }) {
  return <Popover label="记账月份" width={288} className="month-chooser" panelClassName="calendar-popover" trigger={<><CalendarDays size={16} aria-hidden="true" /><span>{formatMonth(value)}</span><ChevronDown size={13} aria-hidden="true" /></>}>
    {({ close }) => <MonthGrid month={value} onChange={(month) => { onChange(month); close(); }} />}
  </Popover>;
}
function Calendar({ month, onMonth, selected, from, to, onPick }: {
  month: string; onMonth: (month: string) => void; selected?: string; from?: string; to?: string; onPick: (date: string) => void;
}) {
  const [monthMode, setMonthMode] = useState(false);
  const first = `${month}-01`;
  const weekday = (new Date(`${first}T12:00:00Z`).getUTCDay() + 6) % 7;
  const start = offsetDay(first, -weekday);
  const today = hongKongToday();
  if (monthMode) return <MonthGrid month={month} onChange={(value) => { onMonth(value); setMonthMode(false); }} />;
  return <div className="calendar-view"><header className="calendar-heading"><button className="calendar-month-title" type="button" onClick={() => setMonthMode(true)}>{formatMonth(month)}<ChevronDown size={13} /></button><div><button type="button" className="icon-button" aria-label="日历上个月" onClick={() => onMonth(shiftMonth(month, -1))}><ChevronLeft size={17} /></button><button type="button" className="icon-button" aria-label="日历下个月" onClick={() => onMonth(shiftMonth(month, 1))}><ChevronRight size={17} /></button></div></header>
    <table className="calendar-grid" role="grid" aria-label={`${formatMonth(month)}日历`}><thead><tr>{['一','二','三','四','五','六','日'].map((day) => <th key={day} scope="col">{day}</th>)}</tr></thead><tbody>{Array.from({ length: 6 }, (_, week) => <tr key={week}>{Array.from({ length: 7 }, (_, day) => {
      const date = offsetDay(start, week * 7 + day), active = date === selected || date === from || date === to;
      return <td key={date} className={`${from && to && date >= from && date <= to ? 'in-range' : ''} ${date === from ? 'range-start' : ''} ${date === to ? 'range-end' : ''}`}><button type="button" className={`${date.startsWith(month) ? '' : 'outside-month'} ${active ? 'selected-day' : ''}`} aria-label={date} aria-pressed={active} aria-current={date === today ? 'date' : undefined} data-selected={active} tabIndex={date === (selected ?? from ?? today) || !selected && !from && date === first ? 0 : -1}
        onClick={() => onPick(date)} onKeyDown={(event) => {
          const deltas: Record<string, number> = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7, Home: -day, End: 6 - day };
          if (event.key in deltas) {
            event.preventDefault(); const next = offsetDay(date, deltas[event.key]);
            if (!next.startsWith(month)) onMonth(next.slice(0, 7));
            requestAnimationFrame(() => document.querySelector<HTMLButtonElement>(`.calendar-grid button[aria-label="${next}"]`)?.focus());
          }
        }}>{Number(date.slice(8))}</button></td>;
    })}</tr>)}</tbody></table>
  </div>;
}
export function DatePicker({ value, onChange, label, id, disabled = false }: { value: string; onChange: (date: string) => void; label: string; id?: string; disabled?: boolean }) {
  const [month, setMonth] = useState((isValidDate(value) ? value : hongKongToday()).slice(0, 7));
  return <div className="custom-date-control"><input type="text" id={id} aria-label={label} inputMode="numeric" autoComplete="off" placeholder="YYYY-MM-DD" value={value} onChange={(event) => onChange(event.target.value)} disabled={disabled} />
    {!disabled && <Popover label={`打开${label}日历`} className="date-icon-trigger" width={300} panelClassName="calendar-popover" onOpen={() => setMonth((isValidDate(value) ? value : hongKongToday()).slice(0, 7))}
      trigger={<CalendarDays size={17} aria-hidden="true" />} initialFocus=".selected-day, .calendar-month-title">
      {({ close }) => <><Calendar month={month} onMonth={setMonth} selected={value} onPick={(date) => { onChange(date); close(); }} /><footer className="calendar-footer"><span>{value || '选择日期'}</span><button type="button" onClick={() => { onChange(hongKongToday()); close(); }}>今天</button></footer></>}
    </Popover>}
  </div>;
}
export function DateRangePicker({ value, onChange }: { value: DateRange; onChange: (range: DateRange) => void }) {
  const [draft, setDraft] = useState(value);
  const [month, setMonth] = useState(value.from.slice(0, 7));
  const [anchor, setAnchor] = useState<string | null>(null);
  const valid = isValidDate(draft.from) && isValidDate(draft.to) && draft.from <= draft.to;
  const pick = (date: string) => {
    if (!anchor) { setAnchor(date); setDraft({ from: date, to: date }); }
    else { setDraft({ from: date < anchor ? date : anchor, to: date < anchor ? anchor : date }); setAnchor(null); }
  };
  return <Popover label="统计日期范围" width={620} align="end" className="date-range-chooser" panelClassName="date-range-popover" onOpen={() => { setDraft(value); setMonth(value.from.slice(0, 7)); setAnchor(null); }}
    initialFocus=".date-range-fields input" trigger={<><CalendarDays size={16} aria-hidden="true" /><span>{value.from.replaceAll('-', '/')}<span className="range-separator">—</span>{value.to.replaceAll('-', '/')}</span><ChevronDown size={13} aria-hidden="true" /></>}>
    {({ close }) => <><div className="date-range-title"><strong>选择统计日期</strong><span>{anchor ? '再选一天作为结束日期' : '可选日期范围，包含首尾两天'}</span></div><div className="date-range-calendars"><Calendar month={month} onMonth={setMonth} from={draft.from} to={draft.to} onPick={pick} /><Calendar month={shiftMonth(month, 1)} onMonth={(value) => setMonth(shiftMonth(value, -1))} from={draft.from} to={draft.to} onPick={pick} /></div>
      <div className="date-range-fields"><label>开始日期<input aria-label="统计开始日期" type="text" inputMode="numeric" value={draft.from} onChange={(event) => { setDraft((old) => ({ ...old, from: event.target.value })); setAnchor(null); }} /></label><span>—</span><label>结束日期<input aria-label="统计结束日期" type="text" inputMode="numeric" value={draft.to} onChange={(event) => { setDraft((old) => ({ ...old, to: event.target.value })); setAnchor(null); }} /></label></div>
      {!valid && <p className="calendar-error" role="alert">请选择有效日期，开始日期须早于或等于结束日期</p>}
      <footer className="date-range-actions"><button type="button" className="button secondary" onClick={close}>取消</button><button type="button" className="button primary" disabled={!valid} onClick={() => { onChange(draft); close(); }}>应用日期</button></footer></>}
  </Popover>;
}
