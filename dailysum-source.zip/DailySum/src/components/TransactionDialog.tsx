import { useRef, useState, type ComponentProps, type FormEvent } from 'react';
/** GPL-3.0. Desktop port of Dime TransactionView by Rafael Soh; local persistence is adapted. */
import { CalendarDays, Keyboard, MessageSquare, Plus } from 'lucide-react';
import { DatePicker } from './DatePicker';
import {
  MAX_NOTE_LENGTH, type Category, type Transaction, type TransactionDraft, type TransactionType, type UserSettings,
} from '../domain/models';
import { amountToInput, CURRENCY_META, formatMoney, parseAmount } from '../domain/money';
import { hongKongToday } from '../domain/dates';
import { isValidDate } from '../domain/models';
import { describeError } from '../services/errors';
import { DimeCategoryPicker } from '../dime/DimeCategoryPicker';
import { DimeNumberPad } from '../dime/DimeNumberPad';
import { CurrencyToggle } from './CurrencyToggle';
import { ConfirmDialog, Modal } from './Modal';
import { CentSourceDetails } from './CentSourceDetails';
import { isAndroid } from '../app/android';
import { AndroidTransactionEditor } from '../android/AndroidTransactionEditor';

export type EditorSession = { id: string; transaction: Transaction | null; restored?: TransactionDraft };

export function TransactionDialog({ session, settings, categories, onSave, onClose, onDelete }: {
  session: EditorSession;
  settings: UserSettings;
  categories: Category[];
  onSave: (id: string, draft: TransactionDraft, previous: Transaction | null) => Promise<void>;
  onClose: () => void;
  onDelete?: (transaction: Transaction) => void;
}) {
  const source = session.transaction ?? session.restored;
  const initialType = source?.type ?? settings.lastTransactionType;
  const rememberedCategory = (type: TransactionType) => type === 'expense' ? settings.lastExpenseCategoryId : settings.lastIncomeCategoryId;
  const defaultCategory = (type: TransactionType) => {
    const remembered = rememberedCategory(type);
    return categories.find((category) => category.id === remembered && category.type === type)?.id
      ?? categories.find((category) => category.type === type)!.id;
  };
  const [form, setForm] = useState(() => ({
    type: initialType,
    amount: source ? amountToInput(source.amountMinor) : '',
    currency: source?.currency ?? settings.inputCurrency,
    categoryId: source?.categoryId ?? defaultCategory(initialType),
    note: source?.note ?? '',
    occurredOn: source?.occurredOn ?? hongKongToday(),
  }));
  const initial = useRef(session.restored ? '' : JSON.stringify(form));
  const [showNote, setShowNote] = useState(Boolean(source?.note));
  const [showNumberPad, setShowNumberPad] = useState(false);
  const [discard, setDiscard] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const busy = useRef(false);
  const composing = useRef(false);
  const amountRef = useRef<HTMLInputElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const parsed = parseAmount(form.amount);
  const dateValid = isValidDate(form.occurredOn);
  const valid = parsed.ok && dateValid && form.note.length <= MAX_NOTE_LENGTH;

  const close = () => {
    if (busy.current || composing.current) return;
    if (JSON.stringify(form) !== initial.current) setDiscard(true);
    else onClose();
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (busy.current || composing.current || !parsed.ok || !valid) return;
    busy.current = true;
    setSaving(true);
    setError('');
    try {
      await onSave(session.id, {
        type: form.type, amountMinor: parsed.minor, currency: form.currency,
        categoryId: form.categoryId, note: form.note, occurredOn: form.occurredOn,
      }, session.transaction);
    } catch (cause) {
      setError(`保存未完成：${describeError(cause)}。输入内容已保留，请重试。`);
    } finally {
      busy.current = false;
      setSaving(false);
    }
  };

  const numberPad = <>
    <button type="button" className="dime-number-pad-toggle" aria-expanded={showNumberPad} onClick={() => setShowNumberPad((value) => !value)}><Keyboard size={15} />{showNumberPad ? '隐藏数字键盘' : '显示数字键盘'}</button>
    {showNumberPad && <DimeNumberPad value={form.amount} onChange={(amount) => setForm((current) => ({ ...current, amount }))} disabled={saving} canSubmit={valid}
      onSubmit={() => { if (!composing.current) formRef.current?.requestSubmit(); }} />}
  </>;
  const formEvents: Pick<ComponentProps<'form'>, 'onSubmit' | 'onCompositionStart' | 'onCompositionEnd' | 'onKeyDown'> = {
    onSubmit: submit,
    onCompositionStart: () => { composing.current = true; },
    onCompositionEnd: () => { composing.current = false; },
    onKeyDown: (event) => {
      if (event.key === 'Enter' && (event.nativeEvent.isComposing || composing.current || event.nativeEvent.keyCode === 229)) {
        event.preventDefault(); return;
      }
      if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        if (valid) event.currentTarget.requestSubmit();
      }
    },
  };
  const setType = (type: TransactionType) => setForm((current) => ({ ...current, type, categoryId: defaultCategory(type) }));
  const discardDialog = discard && <ConfirmDialog title="放弃这次修改？" confirmLabel="放弃修改" danger onConfirm={onClose} onClose={() => setDiscard(false)}>
    <p>这笔内容还没有保存到本地。放弃后需要重新输入。</p>
  </ConfirmDialog>;

  if (isAndroid) return <>
    <AndroidTransactionEditor form={form} setForm={setForm} formEvents={formEvents} categories={categories} transaction={session.transaction}
      setType={setType} onClose={close} onDelete={onDelete} saving={saving} valid={valid}
      amountError={parsed.ok ? undefined : parsed.error} dateValid={dateValid} error={error} />
    {discardDialog}
  </>;

  return <>
    <Modal title={session.transaction ? '编辑记录' : '记一笔'} onClose={close} initialFocus={amountRef} busy={saving} className="transaction-modal dime-transaction-modal"
      headerContent={<div className="type-toggle" role="group" aria-label="收支类型">
        {(['expense', 'income'] as const).map((type) => <button key={type} type="button" disabled={saving} aria-pressed={form.type === type}
          className={form.type === type ? 'selected' : ''}
          onClick={() => setType(type)}>
          {type === 'expense' ? '支出' : '收入'}
        </button>)}
      </div>}>
      <form ref={formRef} {...formEvents}>
        <fieldset disabled={saving} className="transaction-fields">
          <legend className="sr-only">交易信息</legend>
          <div className="amount-section">
            <label htmlFor="amount" className="sr-only">{form.type === 'expense' ? '支出金额' : '收入金额'}</label>
            <div className={`amount-field ${form.amount && !parsed.ok ? 'invalid' : ''}`}>
              <span className="amount-symbol" aria-hidden="true">{CURRENCY_META[form.currency].symbol}</span>
              <input ref={amountRef} id="amount" name="amount" aria-label="金额" type="text" inputMode="decimal" autoComplete="off"
                placeholder="0.00" value={form.amount} maxLength={32} style={{ width: `${Math.max(4.4, Math.min(form.amount.length + 0.4, 13))}ch` }} aria-describedby="amount-help" aria-invalid={Boolean(form.amount && !parsed.ok)}
                onChange={(event) => setForm((current) => ({ ...current, amount: event.target.value }))} />
              <button type="button" className="icon-button dime-backspace" aria-label="删除最后一位" onClick={() => setForm((current) => ({ ...current, amount: current.amount.slice(0, -1) }))}><img src="./dime/backspace.svg" width="21" height="21" alt="" /></button>
            </div>
            <CurrencyToggle value={form.currency} onChange={(currency) => setForm((current) => ({ ...current, currency }))} />
            <p id="amount-help" className={`field-hint ${form.amount && !parsed.ok ? 'error-text' : ''}`}>
              {parsed.ok ? '' : parsed.error}
            </p>
          </div>

            {showNote ? <div className="note-field">
              <label htmlFor="note"><MessageSquare size={16} aria-hidden="true" />备注<span className="optional-label">可选</span><small>{form.note.length} / {MAX_NOTE_LENGTH}</small></label>
              <input id="note" placeholder="填写备注" value={form.note} maxLength={MAX_NOTE_LENGTH}
                onChange={(event) => setForm((current) => ({ ...current, note: event.target.value }))} />
            </div> : <button className="add-note" type="button" onClick={() => setShowNote(true)}><MessageSquare size={16} />添加备注<span>可选 <Plus size={14} /></span></button>}
          <div className="category-section">
            <label>分类</label>
            <DimeCategoryPicker categories={categories.filter((category) => category.type === form.type)} value={form.categoryId}
              onChange={(categoryId) => setForm((current) => ({ ...current, categoryId }))} />
          </div>
          <div className="optional-fields">
            <div className="date-field">
              <label htmlFor="occurredOn"><CalendarDays size={16} aria-hidden="true" />日期{form.occurredOn === hongKongToday() && <span className="today-label">今天</span>}</label>
              <DatePicker id="occurredOn" label="交易日期" value={form.occurredOn} onChange={(occurredOn) => setForm((current) => ({ ...current, occurredOn }))} />
            </div>
            {!dateValid && <p className="error-text">请选择有效的交易日期</p>}
          </div>
          {session.transaction?.origin&&<CentSourceDetails transaction={session.transaction}/>}
          {numberPad}
          {error && <p className="form-error" role="alert">{error}</p>}
        </fieldset>
        <footer className="modal-footer transaction-footer">
          <span className="keyboard-hint"><kbd>Ctrl</kbd> + <kbd>Enter</kbd> 保存</span>
          <button className="button secondary" type="button" onClick={close} disabled={saving}>取消</button>
          <button className="button primary save-button" type="submit" disabled={!valid || saving}>
            {saving ? '正在保存…' : `保存${parsed.ok ? ` ${formatMoney(parsed.minor, form.currency)}` : ''}`}
          </button>
        </footer>
      </form>
    </Modal>
    {discardDialog}
  </>;
}
