/** Dime category grouping adapted to a consistent desktop SVG icon family. */
import type { Category } from '../domain/models';
import { categoryAppearance } from '../dime/categoryAppearance';
import { CategoryGlyph, categoryGlyphId } from './categoryGlyphs';
export function CategoryIcon({ category, size = 20 }: { category?: Category; size?: number }) {
  return <span className="category-icon vector-category-icon" style={categoryAppearance(category).style} aria-hidden="true"><CategoryGlyph id={categoryGlyphId(category)} size={size} /></span>;
}
