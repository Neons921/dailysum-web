/** Dime category grouping adapted to a consistent desktop SVG icon family. */
import { BriefcaseBusiness, Gift, HeartPulse, Laptop, MoreHorizontal, Popcorn, ReceiptText, ShoppingBag, ShoppingBasket, TrainFront, Utensils, Wallet, type LucideIcon } from 'lucide-react';
import type { Category } from '../domain/models';
import { categoryAppearance } from '../dime/categoryAppearance';
const glyphs: Record<string, LucideIcon> = { food: Utensils, transport: TrainFront, shopping: ShoppingBag, living: ShoppingBasket, fun: Popcorn, health: HeartPulse, work: BriefcaseBusiness, bonus: Wallet, gift: Gift, refund: ReceiptText, other: MoreHorizontal };
export function CategoryIcon({ category, size = 20 }: { category?: Category; size?: number }) {
  const Icon = category?.id === 'parttime' ? Laptop : glyphs[category?.icon ?? 'other'] ?? MoreHorizontal;
  return <span className="category-icon vector-category-icon" style={categoryAppearance(category).style} aria-hidden="true"><Icon size={size} strokeWidth={1.7} /></span>;
}
