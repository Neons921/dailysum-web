import { ArrowLeftRight, LoaderCircle, RefreshCw } from 'lucide-react';

export type FxStatusData = { missing: string[]; loading: boolean; error: string; retry: () => void };
export function FxStatus({ status, onManage }: { status: FxStatusData; onManage: (date?: string) => void }) {
  return status.missing.length ? <div className={`fx-status ${status.error ? 'has-error' : ''}`} role="status">
    {status.loading ? <LoaderCircle size={14} className="spin" /> : <ArrowLeftRight size={14} />}
    <span>{status.loading ? '正在获取每日汇率…' : `缺少 ${status.missing.length} 天汇率`}{status.error && <small>{status.error}</small>}</span>
    {!status.loading && <button className="text-button" onClick={status.retry}><RefreshCw size={12} />重试</button>}
    <button className="text-button" onClick={() => onManage(status.missing[0])}>查看与补录</button>
  </div> : <div className="fx-status complete"><button className="text-button" onClick={() => onManage()}><ArrowLeftRight size={12} />汇率依据</button></div>;
}
