import { replayCent, safeAssetPath, type CentPayload } from '../domain/cent';
import { base64ToBytes, base64ToUtf8, bytesToBase64, MAX_BACKUP_BYTES, parseEnvelope, utf8ToBase64, type LedgerEnvelope } from '../domain/portable';
import { CENT_SOURCE_REPOSITORY, repositoryName, type SyncProfile } from '../domain/sync';

type RepoInfo={full_name:string;private:boolean;default_branch:string;permissions?:{push?:boolean}};
export class GitHubError extends Error { constructor(readonly status:number,message:string){super(message);this.name='GitHubError';} }
const encodeRepo=(repository:string)=>repositoryName(repository).split('/').map(encodeURIComponent).join('/');
const encodePath=(path:string)=>path.split('/').map(encodeURIComponent).join('/');
export class GitHubClient {
  private token='';
  private session=new AbortController();
  constructor(private readonly transport:typeof fetch=(...args)=>fetch(...args)) {}
  get connected():boolean{return !!this.token;}
  connect(token:string):void {if(!token.trim()||/[\s\r\n]/.test(token.trim()))throw new Error('请输入有效的 GitHub Token');this.session.abort();this.session=new AbortController();this.token=token.trim();}
  disconnect():void {this.session.abort();this.token='';}
  private async request<T>(path:string,init:RequestInit={},allowMissing=false):Promise<T|null> {
    if(!this.token)throw new Error('请在应用内连接 GitHub');
    let response:Response;
    try {response=await this.transport(`https://api.github.com${path}`,{...init,redirect:'error',headers:{Accept:new Headers(init.headers).get('Accept')??'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28',Authorization:`Bearer ${this.token}`,...(init.body?{'Content-Type':'application/json'}:{})},signal:AbortSignal.any([this.session.signal,AbortSignal.timeout(30000)])});}
    catch(cause){if(cause instanceof Error&&cause.name==='TimeoutError')throw new Error('GitHub 请求超时，本地账目已保留');throw new Error('无法连接 GitHub，请检查网络后重试；本地账目已保留');}
    if(response.status===404&&allowMissing)return null;
    if(!response.ok){const message=response.status===401?'GitHub 凭据已失效，请重新连接':response.status===403?'GitHub 权限不足或请求额度已用完，请检查仓库权限后重试':response.status===404?'找不到仓库或尚未获得私有仓库权限':response.status===409||response.status===422?'GitHub 文件已在其他设备变更，请重新检查同步':`GitHub 请求失败（${response.status}），本地账目已保留`;throw new GitHubError(response.status,message);}
    if(Number(response.headers.get('content-length')??0)>MAX_BACKUP_BYTES*1.5)throw new Error('GitHub 数据超过支持的大小');
    const content=await response.text();if(content.length>MAX_BACKUP_BYTES*1.5)throw new Error('GitHub 数据超过支持的大小');
    try{return JSON.parse(content) as T;}catch{throw new Error('GitHub 返回的内容无法识别');}
  }
  async repository(repository:string):Promise<RepoInfo> {
    const info=await this.request<RepoInfo>(`/repos/${encodeRepo(repository)}`);
    if(!info||typeof info.full_name!=='string'||typeof info.default_branch!=='string'||typeof info.private!=='boolean')throw new Error('GitHub 仓库信息无效');return info;
  }
  async target(profile:SyncProfile):Promise<SyncProfile> {
    const repository=repositoryName(profile.repository);
    if(repository.toLowerCase()===CENT_SOURCE_REPOSITORY.toLowerCase()||repository.split('/')[1].toLowerCase().startsWith('cent-journal-'))throw new Error('请使用独立的 DailySum 私有仓库，不能向 Cent 原仓库写入');
    const info=await this.repository(repository);
    if(!info.private)throw new Error('请选择私有仓库，账本包含个人记录');
    if(info.permissions?.push===false)throw new Error('当前凭据没有此仓库的写入权限');
    return {...profile,repository:info.full_name,branch:profile.branch||info.default_branch};
  }
  private async blob(repository:string,sha:string,maximum=MAX_BACKUP_BYTES):Promise<{content:string;size:number}> {
    if(!/^[a-f0-9]{40,64}$/i.test(sha))throw new Error('GitHub 文件哈希无效');
    const blob=await this.request<{content:string;encoding:string;size:number}>(`/repos/${encodeRepo(repository)}/git/blobs/${sha}`);
    if(!blob||blob.encoding!=='base64'||typeof blob.content!=='string'||!Number.isFinite(blob.size)||blob.size>maximum)throw new Error('GitHub 文件过大或编码不受支持');return blob;
  }
  async read(profile:SyncProfile):Promise<{envelope:LedgerEnvelope;sha:string}|null> {
    const file=await this.request<{sha:string;type:string;size:number;content?:string;encoding?:string}>(`/repos/${encodeRepo(profile.repository)}/contents/${encodePath(profile.path)}?ref=${encodeURIComponent(profile.branch)}`,{headers:{Accept:'application/vnd.github.object+json'}},true);
    if(!file)return null;
    if(file.type!=='file'||file.size>MAX_BACKUP_BYTES||!/^[a-f0-9]{40,64}$/i.test(file.sha))throw new Error('远端账本不是有效文件或已超过 40 MB');
    const content=file.encoding==='base64'&&file.content?file.content:(await this.blob(profile.repository,file.sha)).content;
    let input:unknown;try{input=JSON.parse(base64ToUtf8(content));}catch{throw new Error('远端账本 JSON 无法读取，未修改任何数据');}
    return {envelope:await parseEnvelope(input),sha:file.sha};
  }
  async write(profile:SyncProfile,envelope:LedgerEnvelope,sha:string|null):Promise<string> {
    // Recheck privacy immediately before every write, including automatic sync.
    await this.target(profile);
    const text=JSON.stringify(envelope);if(new TextEncoder().encode(text).length>MAX_BACKUP_BYTES)throw new Error('账本超过 40 MB，请先导出本地备份');
    const result=await this.request<{content:{sha:string}}>(`/repos/${encodeRepo(profile.repository)}/contents/${encodePath(profile.path)}`,{method:'PUT',body:JSON.stringify({message:'Sync DailySum ledger',content:utf8ToBase64(text),branch:profile.branch,...(sha?{sha}:{})})});
    if(!result?.content?.sha)throw new Error('GitHub 未返回保存确认，请重新检查同步');return result.content.sha;
  }
  async readCent(repository:string):Promise<CentPayload> {
    const name=repositoryName(repository),info=await this.repository(name);
    const tree=await this.request<{sha:string;truncated:boolean;tree:{path:string;type:string;sha:string;size?:number}[]}>(`/repos/${encodeRepo(name)}/git/trees/${encodeURIComponent(info.default_branch)}?recursive=1`);
    if(!tree||tree.truncated||!Array.isArray(tree.tree))throw new Error('Cent 仓库目录不完整，请改用 Cent 导出文件');
    const files=tree.tree.filter((row)=>row.type==='blob'&&(row.path==='meta.json'||/^ledger-\d+\.json$/.test(row.path)||row.path.startsWith('assets/')));
    if(!files.some((row)=>row.path==='meta.json'))throw new Error('仓库没有 Cent 的 meta.json');
    if(files.length>2001||files.some((row)=>!safeAssetPath(row.path))||files.reduce((sum,row)=>sum+(row.size??0),0)>28*1024*1024)throw new Error('Cent 仓库超过单次导入限制，请使用分批导出文件');
    let bytes=0;const content=new Map<string,{content:string;size:number}>();
    for(let index=0;index<files.length;index+=4){const batch=files.slice(index,index+4);const results=await Promise.all(batch.map(async(file)=>({file,value:await this.blob(name,file.sha,28*1024*1024)})));for(const {file,value} of results){bytes+=value.size;if(bytes>28*1024*1024)throw new Error('Cent 数据超过 28 MB');content.set(file.path,value);}}
    let data:Record<string,unknown>;
    try{data=replayCent(JSON.parse(base64ToUtf8(content.get('meta.json')!.content)),files.filter((file)=>/^ledger-\d+\.json$/.test(file.path)).map((file)=>({path:file.path,actions:JSON.parse(base64ToUtf8(content.get(file.path)!.content))})));}
    catch(cause){throw new Error(`Cent 仓库读取失败：${cause instanceof Error?cause.message:'文件无效'}`);}
    const attachments=files.filter((file)=>file.path.startsWith('assets/')).map((file)=>{const blob=content.get(file.path)!;const bytes=base64ToBytes(blob.content);return {path:file.path,content:bytesToBase64(bytes),size:bytes.length,mime:'application/octet-stream'};});
    return {data,attachments,source:`https://github.com/${name}/tree/${tree.sha}`};
  }
}
