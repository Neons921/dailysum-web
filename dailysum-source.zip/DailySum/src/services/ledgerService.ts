import {
  draftSchema, transactionSchema, type Category, type LedgerChange, type Transaction,
  type TransactionDraft, type UserSettings,
} from '../domain/models';
import { LedgerDatabase } from '../storage/db';
import { LedgerRepository } from '../storage/ledgerRepository';
import { isAndroidPreview } from '../app/previewMode';

export class LedgerService {
  constructor(readonly repository: LedgerRepository) {}

  async initialize() {
    if (isAndroidPreview) {
      const { seedPreviewLedger } = await import('../android/preview/seed');
      await seedPreviewLedger(this.repository.db);
    }
    return this.repository.initialize();
  }
  snapshot() { return this.repository.snapshot(); }
  saveCategory(input: Pick<Category, 'name' | 'type' | 'icon'>, previous?: Category) { return this.repository.saveCategory(input, previous); }

  async save(id: string, input: TransactionDraft, previous: Transaction | null = null) {
    const draft = draftSchema.parse(input);
    const now = new Date().toISOString();
    const record = transactionSchema.parse({
      ...draft, id,
      createdAt: previous?.createdAt ?? now,
      updatedAt: now,
      deletedAt: null,
      schemaVersion: 1,
      origin: previous?.origin,
      categoryHistory: previous?.categoryId===draft.categoryId?previous.categoryHistory:undefined,
    });
    return this.repository.save(record, previous?.updatedAt ?? null);
  }

  remove(record: Transaction) { return this.repository.remove(record); }
  undo(change: LedgerChange) { return this.repository.undo(change); }
  updateSettings(patch: Partial<UserSettings>) { return this.repository.updateSettings(patch); }
}

export const ledgerService = new LedgerService(new LedgerRepository(new LedgerDatabase(isAndroidPreview ? 'dailysum-android-preview' : undefined)));
