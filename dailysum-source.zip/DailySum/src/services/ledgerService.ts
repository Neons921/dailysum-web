import {
  draftSchema, transactionSchema, type LedgerChange, type Transaction,
  type TransactionDraft, type UserSettings,
} from '../domain/models';
import { LedgerDatabase } from '../storage/db';
import { LedgerRepository } from '../storage/ledgerRepository';
import { normalizeCategoryTransactions } from '../domain/categories';

export class LedgerService {
  constructor(readonly repository: LedgerRepository) {}

  initialize() { return this.repository.initialize(); }
  snapshot() { return this.repository.snapshot(); }

  async save(id: string, input: TransactionDraft, previous: Transaction | null = null) {
    const draft = draftSchema.parse(input);
    const category = await this.repository.category(draft.categoryId);
    if (!category || category.type !== draft.type) throw new Error('请选择对应收支类型的分类');
    const now = new Date().toISOString();
    const record = transactionSchema.parse({
      ...draft, id,
      createdAt: previous?.createdAt ?? now,
      updatedAt: now,
      deletedAt: null,
      schemaVersion: 1,
      origin: previous?.origin,
      categoryHistory: previous?.categoryId===draft.categoryId?previous.categoryHistory:undefined,
    });
    const normalized=category.mergedIntoId?normalizeCategoryTransactions([record],(await this.repository.snapshot()).categories)[0]:record;
    return this.repository.save(normalized, previous?.updatedAt ?? null);
  }

  remove(record: Transaction) { return this.repository.remove(record); }
  undo(change: LedgerChange) { return this.repository.undo(change); }
  updateSettings(patch: Partial<UserSettings>) { return this.repository.updateSettings(patch); }
}

export const ledgerService = new LedgerService(new LedgerRepository(new LedgerDatabase()));
