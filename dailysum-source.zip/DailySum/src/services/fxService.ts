import { z } from 'zod';
import { dateSchema, type FxRate } from '../domain/models';
import { fxRateSchema, latestRates, MoneyDecimal, rateInputSchema } from '../domain/fx';
import { hongKongToday, offsetDay } from '../domain/dates';
import { FxRepository } from '../storage/fxRepository';
import { ledgerService } from './ledgerService';

export const FX_SOURCE = 'ECB · Frankfurter';
export const FX_SOURCE_URL = 'https://frankfurter.dev/providers/ecb/';
const quoteSchema = z.object({ date: dateSchema, base: z.literal('EUR'), quote: z.enum(['CNY', 'HKD']), rate: z.number().finite().positive().max(1000) });
const quotesSchema = z.array(quoteSchema).max(16000);
type Fetcher = typeof fetch;

/** Original ECB EUR quotes, same publication date. No rounded API cross rate. */
export async function fetchDailyRates(dates: string[], fetcher: Fetcher = fetch, today = hongKongToday()): Promise<FxRate[]> {
  const requested = [...new Set(dates.map((date) => dateSchema.parse(date)))].filter((date) => date <= today).sort();
  if (!requested.length) return [];
  const pairs = new Map<string, Partial<Record<'CNY' | 'HKD', string>>>();
  // Split sparse / long histories instead of requesting the entire history between two entries.
  const chunks: string[][] = [];
  for (const date of requested) {
    const chunk = chunks.at(-1);
    if (!chunk || date > offsetDay(chunk[0], 350)) chunks.push([date]);
    else chunk.push(date);
  }
  for (const chunk of chunks) {
    const from = offsetDay(chunk[0], -7), to = chunk.at(-1)!;
    const params = new URLSearchParams({ base: 'EUR', quotes: 'CNY,HKD', from, to });
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetcher(`https://api.frankfurter.dev/v2/providers/ecb/rates?${params}`, { signal: controller.signal, credentials: 'omit' });
      if (!response.ok) throw new Error(`汇率服务暂不可用（${response.status}）`);
      const parsed = quotesSchema.safeParse(await response.json());
      if (!parsed.success) throw new Error('汇率来源返回了无法验证的数据');
      for (const quote of parsed.data) {
        if (quote.date < from || quote.date > to) throw new Error('汇率来源返回了区间外的报价');
        const pair = pairs.get(quote.date) ?? {};
        const old = pair[quote.quote];
        if (old && old !== String(quote.rate)) throw new Error('汇率来源返回了冲突的报价');
        pair[quote.quote] = String(quote.rate);
        pairs.set(quote.date, pair);
      }
    } catch (cause) {
      if (controller.signal.aborted) throw new Error('获取汇率超时，请稍后重试');
      if (cause instanceof TypeError) throw new Error('暂时无法连接汇率来源，可使用缓存或手动补录');
      throw cause;
    } finally { clearTimeout(timeout); }
  }
  const publications = [...pairs.keys()].filter((date) => pairs.get(date)?.CNY && pairs.get(date)?.HKD).sort().reverse();
  const fetchedAt = new Date().toISOString();
  return requested.flatMap((date) => {
    const sourceDate = publications.find((value) => value <= date && value >= offsetDay(date, -7));
    if (!sourceDate) return [];
    const pair = pairs.get(sourceDate)!;
    return [fxRateSchema.parse({
      id: crypto.randomUUID(), rateDate: date, sourceDate, baseCurrency: 'CNY', quoteCurrency: 'HKD',
      rate: new MoneyDecimal(pair.HKD!).div(pair.CNY!).toFixed(40).replace(/0+$/, '').replace(/\.$/, ''),
      sourceRates: { EUR_CNY: pair.CNY!, EUR_HKD: pair.HKD! }, source: FX_SOURCE,
      fetchedAt, isManual: false, revision: 1,
    })];
  });
}

export class FxService {
  private pending = new Map<string, Promise<FxRate[]>>();
  constructor(readonly repository: FxRepository, private fetcher: Fetcher = fetch) {}
  list() { return this.repository.list(); }
  async ensure(dates: string[], persist = true): Promise<FxRate[]> {
    const existing = persist ? await this.list() : [];
    const known = latestRates(existing);
    const missing = [...new Set(dates)].filter((date) => !known.has(date)).sort();
    if (!missing.length) return existing;
    const key = `${persist}:${missing.join(',')}`;
    let task = this.pending.get(key);
    if (!task) {
      task = (async () => {
        const fetched = await fetchDailyRates(missing, this.fetcher);
        return persist ? this.repository.addAutomatic(fetched) : fetched;
      })();
      this.pending.set(key, task);
      task.finally(() => this.pending.delete(key)).catch(() => {});
    }
    return task;
  }
  async candidate(date: string): Promise<FxRate> {
    dateSchema.parse(date);
    if (date > hongKongToday()) throw new Error('未来日期尚无参考汇率');
    const result = await fetchDailyRates([date], this.fetcher);
    if (!result[0]) throw new Error('该日期暂无可用参考价，可手动补录');
    return result[0];
  }
  async saveManual(date: string, input: string, expectedRevision: number): Promise<FxRate[]> {
    dateSchema.parse(date);
    const rate = rateInputSchema.parse(input.trim());
    return this.repository.revise({ id: crypto.randomUUID(), rateDate: date, sourceDate: date,
      baseCurrency: 'CNY', quoteCurrency: 'HKD', rate, source: '手动录入', fetchedAt: new Date().toISOString(),
      isManual: true, revision: expectedRevision + 1 }, expectedRevision);
  }
  async saveCandidate(candidate: FxRate, expectedRevision: number) {
    return this.repository.revise({ ...candidate, id: crypto.randomUUID(), revision: expectedRevision + 1 }, expectedRevision);
  }
}
export const fxService = new FxService(new FxRepository(ledgerService.repository.db));
