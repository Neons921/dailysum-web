import { useEffect, useState } from 'react';
import type { Currency, FxRate, Transaction } from '../domain/models';
import { missingRateDates } from '../domain/fx';
import { fxService } from './fxService';
import { describeError } from './errors';

export function useExchangeRates(transactions: Transaction[], currency: Currency, stored: FxRate[], demo: boolean, onRates: (rates: FxRate[]) => void, amountCurrency?: Currency) {
  const [preview, setPreview] = useState<FxRate[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const rates = demo ? preview : stored;
  const missing = [...new Set([...missingRateDates(transactions, currency, rates), ...(amountCurrency ? missingRateDates(transactions, amountCurrency, rates) : [])])].sort();
  const key = missing.join(',');
  useEffect(() => {
    if (!key) { setLoading(false); setError(''); return; }
    let active = true;
    setLoading(true);
    setError('');
    fxService.ensure(key.split(','), !demo).then((records) => {
      // Persistent cache updates also apply after navigation; only preview state
      // and request feedback belong to the currently visible scope.
      if (demo) { if (active) setPreview((old) => [...old, ...records]); }
      else onRates(records);
    }).catch((cause) => { if (active) setError(describeError(cause)); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [key, demo, attempt, onRates]);
  return { rates, missing, loading, error, retry: () => setAttempt((value) => value + 1) };
}
