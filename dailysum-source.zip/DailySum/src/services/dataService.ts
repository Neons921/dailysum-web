import { convertCent, type CentIssue, type CentPayload } from '../domain/cent';
import { mergeLedger, type Choices } from '../domain/merge';
import { createEnvelope, dataSignature, parseEnvelope, type LedgerData } from '../domain/portable';
import type { Currency } from '../domain/models';
import { DataRepository } from '../storage/dataRepository';
import { ledgerService } from './ledgerService';

export type DataPlan={kind:'cent'|'backup'|'sync';label:string;before:LedgerData;base:LedgerData|null;remote:LedgerData;expected:string;issues:CentIssue[];warnings:string[];duplicates:number;total:number};
export class DataService {
  constructor(readonly repository:DataRepository){}
  async backup():Promise<string> {return JSON.stringify(await createEnvelope(await this.repository.read(),await this.repository.identity()),null,2);}
  async importPlan(payload:CentPayload,fallbackBase:Currency='CNY'):Promise<DataPlan> {
    const before=await this.repository.read(),expected=dataSignature(before);
    if(payload.data.format==='dailysum') {const envelope=await parseEnvelope(payload.data);const mergedCategories=envelope.data.categories.filter((category)=>category.mergedIntoId).length;return {kind:'backup',label:payload.source,before,base:null,remote:envelope.data,expected,issues:[],warnings:[...(mergedCategories?[`${mergedCategories} 个原分类已合并，旧名称保留归档；后续同步及 Cent 导入继续使用合并后的分类。`]:[]),'同时恢复备份中的记账偏好、报表币种与选中过滤器；账目按 ID 合并。'],duplicates:0,total:envelope.data.transactions.length};}
    const converted=await convertCent(payload,before,fallbackBase);
    return {kind:'cent',label:payload.source,before,base:converted.base,remote:converted.incoming,expected,issues:converted.issues,warnings:converted.warnings,duplicates:converted.duplicates,total:converted.total};
  }
  async commit(plan:DataPlan,choices:Choices,acceptSkipped=false):Promise<void> {
    if(plan.kind==='sync')throw new Error('同步计划请通过 GitHub 同步服务提交');
    if(plan.issues.length&&!acceptSkipped)throw new Error('请先确认无法导入的记录');
    const merged=mergeLedger(plan.base,plan.before,plan.remote,choices);
    if(merged.unresolved.length)throw new Error('请先处理全部冲突');
    if(plan.kind==='backup') {
      merged.data.settings={...plan.remote.settings};
      merged.data.filterPreferences.activeId=merged.data.filterPreferences.views.some((view)=>view.id===plan.remote.filterPreferences.activeId)?plan.remote.filterPreferences.activeId:null;
    }
    await this.repository.commit(merged.data,plan.expected,`导入 ${plan.label}`);
  }
}
export const dataRepository=new DataRepository(ledgerService.repository.db);
export const dataService=new DataService(dataRepository);
