import { registerPlugin } from '@capacitor/core';
import { isNativeAndroid } from '../app/android';

const nativeFile = registerPlugin<{
  save(options: { name: string; mime: string; base64: string }): Promise<void>;
}>('SaveFile');

export async function saveFile(content: BlobPart, name: string, type = 'application/json') {
  const file = new Blob([content], { type });
  if (isNativeAndroid) {
    const base64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result).split(',', 2)[1]);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
    await nativeFile.save({ name, mime: type, base64 });
    return;
  }

  const url = URL.createObjectURL(file);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
