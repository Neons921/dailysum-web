import { mergeLedger, syncSignature, toSyncData, type Choices } from '../domain/merge';
import { createEnvelope, dataSignature, same, validateData, type LedgerData, type LedgerEnvelope } from '../domain/portable';
import { emptySyncProfile, profileKey, type SyncProfile } from '../domain/sync';
import { DataRepository, StaleLedgerError } from '../storage/dataRepository';
import { dataRepository, type DataPlan } from './dataService';
import { GitHubClient, GitHubError } from './githubClient';
import { describeError } from './errors';
import { GitHubConnectionRepository } from '../storage/githubConnectionRepository';

export type SyncPlan=DataPlan&{kind:'sync';profile:SyncProfile;remoteSha:string|null;remoteEnvelope:LedgerEnvelope|null;ledgerId:string;connectionRevision:string|null;session:number};
export type SyncState={status:'disconnected'|'idle'|'pending'|'checking'|'review'|'syncing'|'error'|'offline';message:string;profile:SyncProfile|null;plan:SyncPlan|null;connected:boolean;remembered:boolean};
export function syncStatusLabel(sync:SyncState):string {
  switch(sync.status){
    case 'checking':case 'syncing':return '同步中…';
    case 'review':return '待确认';
    case 'pending':return '待同步';
    case 'offline':return '等待联网';
    case 'error':return sync.connected?'同步异常':'需重新连接';
    case 'idle':return sync.profile?.lastSyncAt?'已同步':'待同步';
    default:return '未连接';
  }
}
const maxAttempts=4;
const offline=()=>typeof navigator!=='undefined'&&navigator.onLine===false;
class ConcurrentWrite extends Error {
  constructor(readonly cause:GitHubError,readonly expectedSha:string|null){super(cause.message);}
}
export class SyncService {
  private state:SyncState={status:'disconnected',message:'未连接',profile:null,plan:null,connected:false,remembered:false};
  private listeners=new Set<()=>void>();private running=false;private paused=false;private timer:ReturnType<typeof setTimeout>|undefined;private scheduleGeneration=0;
  private initialization:Promise<void>|null=null;private restoreGeneration=0;private session=0;private connectionRevision:string|null=null;private startupPending=false;
  private acknowledged:{key:string;ledgerId:string;before:LedgerData}|null=null;
  private localChangedWhileRunning=false;
  private activeSync:Promise<boolean>|null=null;
  readonly connections:GitHubConnectionRepository;
  constructor(readonly repository:DataRepository,readonly client=new GitHubClient()){this.connections=new GitHubConnectionRepository(repository.db);}
  subscribe=(listener:()=>void)=>{this.listeners.add(listener);return()=>{this.listeners.delete(listener);};};
  getState=()=>this.state;
  private update(patch:Partial<SyncState>){this.state={...this.state,...patch,connected:this.client.connected};for(const listener of this.listeners)listener();}
  initialize():Promise<void>{return this.initialization??=this.refreshConnection();}
  private announceConnectionChange():void {if(typeof window!=='undefined')window.dispatchEvent(new Event('dailysum-connection-changed'));}
  private endSession():void {
    this.session++;this.scheduleGeneration++;this.startupPending=false;this.acknowledged=null;this.localChangedWhileRunning=false;
    if(this.timer)clearTimeout(this.timer);this.client.disconnect();this.connectionRevision=null;
  }
  private async resumeStartupSync():Promise<void>{
    if(!this.startupPending||this.running||this.paused)return;
    this.startupPending=false;await this.autoSync();
  }
  private async assertConnectionRevision():Promise<SyncProfile>{
    const {connection,profile}=await this.connections.read();
    if((connection?.revision??null)!==this.connectionRevision)throw new Error('GitHub 连接已变化，请重新检查同步');
    return profile;
  }
  async refreshConnection():Promise<void>{
    const generation=++this.restoreGeneration;
    try {
      const {profile,connection}=await this.connections.read();
      if(generation!==this.restoreGeneration)return;
      if(!connection){
        const wasConnected=this.client.connected;
        if(wasConnected)this.endSession();
        this.update({profile,remembered:false,...(wasConnected?{status:'disconnected' as const,plan:null,message:'已忘记连接，本地账目保留'}:{})});return;
      }
      if(this.client.connected&&this.connectionRevision===connection.revision){this.update({profile,remembered:true});return;}
      this.endSession();this.client.connect(connection.token);this.connectionRevision=connection.revision;
      const offline=typeof navigator!=='undefined'&&navigator.onLine===false;
      this.update({profile,remembered:true,plan:null,status:offline?'offline':'idle',message:offline?'已恢复连接，等待联网同步':'已恢复 GitHub 连接'});
      if(profile.auto){this.startupPending=true;await this.resumeStartupSync();}
    }catch(cause){
      if(generation!==this.restoreGeneration)return;
      this.endSession();this.update({status:'error',remembered:false,message:describeError(cause),plan:null});
    }
  }
  private async recordFailure(cause:unknown):Promise<void>{
    if(cause instanceof GitHubError&&cause.status===401){
      const revision=this.connectionRevision;this.endSession();const session=this.session;
      let removed=false;if(revision)try{removed=await this.connections.forget(revision);}catch{/* An invalid credential never stays active in memory. */}
      if(session===this.session)this.update({status:'error',remembered:false,message:'GitHub Token 已失效，请重新连接；本地账目已保留',plan:null});
      if(removed)this.announceConnectionChange();return;
    }
    this.update({status:offline()?'offline':'error',message:offline()?'本地已保存，等待联网同步':describeError(cause)});
  }
  async connect(repository:string,token:string,{remember=true}:{remember?:boolean}={}):Promise<void> {
    if(this.running)throw new Error('同步正在进行，请稍后重试');
    this.restoreGeneration++;this.endSession();
    this.client.connect(token);this.running=true;this.update({status:'checking',message:'检查私有仓库…',plan:null});
    try{
      const old=await this.repository.profile();
      const target=await this.client.target({...emptySyncProfile(),repository});
      const profile=profileKey(old)===profileKey(target)?{...old,repository:target.repository,branch:target.branch,auto:old.baseline?old.auto:true}:{...target,auto:true};
      const saved=await this.connections.configure(profile,remember?token:null);this.connectionRevision=saved?.revision??null;
      this.update({profile,status:'idle',remembered:!!saved,message:'已连接，等待同步'});this.announceConnectionChange();
    }catch(cause){this.endSession();this.update({status:'error',remembered:false,message:describeError(cause)});throw cause;}
    finally{this.running=false;}
  }
  async disconnect():Promise<void>{
    if(this.running)throw new Error('同步正在进行，请稍后忘记连接');
    const profile={...await this.repository.profile(),auto:false};await this.connections.configure(profile,null);
    this.restoreGeneration++;this.endSession();this.update({status:'disconnected',remembered:false,message:'已忘记连接，本地账目保留',profile,plan:null});this.announceConnectionChange();
  }
  async setAuto(auto:boolean):Promise<void>{const profile=await this.repository.profile();const next={...profile,auto};await this.repository.setProfile(next);this.update({profile:next});this.announceConnectionChange();if(auto){this.startupPending=true;await this.resumeStartupSync();}else{this.startupPending=false;if(this.timer)clearTimeout(this.timer);}}
  setPaused(paused:boolean):void{this.paused=paused;if(paused){this.scheduleGeneration++;if(this.timer)clearTimeout(this.timer);}else if(this.startupPending)void this.resumeStartupSync();else this.localChanged();}
  private assertSession(session:number):void {
    if(session!==this.session)throw new Error('GitHub 连接已变化，请重新连接');
  }
  private async buildPlan(session:number,fresh=false):Promise<SyncPlan>{
    this.assertSession(session);
    const profile=await this.client.target(await this.assertConnectionRevision());
    this.assertSession(session);
    const remote=await this.client.read(profile,{fresh}),before=await this.repository.read();
    this.assertSession(session);
    const ack=this.acknowledged?.key===profileKey(profile)?this.acknowledged:null;
    const previousId=profile.baseline?.ledgerId??ack?.ledgerId;
    if(previousId&&!remote)throw new Error('远端账本文件已移除，已停止同步；请检查 GitHub 仓库历史');
    if(previousId&&remote&&previousId!==remote.envelope.ledgerId)throw new Error('远端账本身份发生变化，已停止同步，请核对仓库与备份');
    const ledgerId=remote?.envelope.ledgerId??await this.repository.identity();
    const incoming=remote?.envelope.data??toSyncData({...before,transactions:[],fxRates:[],archives:[],filterPreferences:{...before.filterPreferences,views:[],activeId:null}});
    return {kind:'sync',label:profile.repository,before,base:ack?.before??profile.baseline?.data??null,remote:incoming,expected:dataSignature(before),issues:[],warnings:[],duplicates:0,total:incoming.transactions.length,profile,remoteSha:remote?.sha??null,remoteEnvelope:remote?.envelope??null,ledgerId,session,connectionRevision:this.connectionRevision};
  }
  private finish():void {
    this.running=false;
    if(this.localChangedWhileRunning){this.localChangedWhileRunning=false;this.localChanged();}
    if(!this.activeSync)void this.resumeStartupSync();
  }
  async prepare():Promise<SyncPlan> {
    if(this.running)throw new Error('同步正在进行，请稍后重试');
    const session=this.session;
    this.running=true;this.update({status:'checking',message:'读取 GitHub 账本…',plan:null});
    try{
      const plan=await this.buildPlan(session);
      const conflicts=mergeLedger(plan.base,plan.before,plan.remote).conflicts.length;
      this.update({status:'review',message:conflicts?'同步存在分歧，请选择保留的内容':'同步计划已准备好',plan,profile:plan.profile});return plan;
    }catch(cause){if(session===this.session)await this.recordFailure(cause);throw cause;}
    finally{this.finish();}
  }
  async commit(plan:SyncPlan,choices:Choices={}):Promise<boolean> {
    this.assertSession(plan.session);
    if(mergeLedger(plan.base,plan.before,plan.remote,choices).unresolved.length)throw new Error('请处理全部同步冲突');
    return this.startSync(plan,choices);
  }
  async syncNow():Promise<boolean>{
    if(this.activeSync)return this.activeSync;
    return this.startSync();
  }
  private startSync(plan?:SyncPlan,choices:Choices={},automatic=false):Promise<boolean>{
    const task=this.synchronize(plan,choices,automatic);
    this.activeSync=task;
    const done=()=>{if(this.activeSync===task){this.activeSync=null;void this.resumeStartupSync();}};
    void task.then(done,done);
    return task;
  }
  private async synchronize(approved?:SyncPlan,choices:Choices={},automatic=false):Promise<boolean>{
    if(this.running)throw new Error('同步正在进行，请稍后重试');
    if(!this.client.connected)throw new Error('请先连接 GitHub 私有仓库');
    if(offline()){this.networkLost();return false;}
    const session=this.session,previousConflicts=approved?mergeLedger(approved.base,approved.before,approved.remote).conflicts:[];
    if(this.timer)clearTimeout(this.timer);
    const quiet=automatic&&this.state.status==='idle';
    this.running=true;
    if(!quiet)this.update({status:'checking',message:'同步中…'});
    const run=async()=>{
      let rejected:ConcurrentWrite|undefined;
      for(let attempt=0;attempt<maxAttempts;attempt++){
        const plan=await this.buildPlan(session,!!rejected);
        if(rejected?.cause.status===422&&plan.remoteSha===rejected.expectedSha)throw rejected.cause;
        if(approved&&profileKey(approved.profile)!==profileKey(plan.profile))throw new Error('同步仓库配置已变化，请重新连接');
        if(quiet&&attempt===0&&!this.acknowledged&&plan.profile.baseline&&plan.remoteSha===plan.profile.lastRemoteSha&&syncSignature(plan.before)===syncSignature(plan.profile.baseline.data)){
          this.update({profile:plan.profile});return false;
        }
        const currentConflicts=previousConflicts.length?mergeLedger(plan.base,plan.before,plan.remote).conflicts:[];
        const validChoices=Object.fromEntries(currentConflicts.filter((current)=>choices[current.key]&&previousConflicts.some((old)=>same(old,current))).map((conflict)=>[conflict.key,choices[conflict.key]]));
        const merged=mergeLedger(plan.base,plan.before,plan.remote,validChoices);
        if(merged.unresolved.length){
          this.update({status:'review',message:'有不同版本的修改，需要确认',plan,profile:plan.profile});return false;
        }
        this.update({status:'syncing',message:'同步中…',plan:null});
        try{return await this.apply(plan,merged.data);}
        catch(cause){
          if(!(cause instanceof ConcurrentWrite||cause instanceof StaleLedgerError))throw cause;
          rejected=cause instanceof ConcurrentWrite?cause:undefined;
          if(attempt===maxAttempts-1)throw new Error('账本正在更新，本地变更已保留，请稍后再同步');
        }
      }
      return false;
    };
    try{return typeof navigator!=='undefined'&&navigator.locks?await navigator.locks.request('dailysum-github-sync',run):await run();}
    catch(cause){if(session===this.session)await this.recordFailure(cause);throw cause;}
    finally{this.finish();}
  }
  private async apply(plan:SyncPlan,merged:LedgerData):Promise<boolean>{
    const {profile,session}=plan;
    await this.repository.assertCurrent(plan.expected);
    await this.assertConnectionRevision();this.assertSession(session);
    const data=validateData(merged),unchanged=plan.remoteEnvelope&&syncSignature(plan.remoteEnvelope.data)===syncSignature(data);
    const baseline=unchanged?plan.remoteEnvelope!:await createEnvelope(toSyncData(data),plan.ledgerId);
    this.assertSession(session);
    let sha=plan.remoteSha!;
    if(!unchanged){
      try{sha=await this.client.write(profile,baseline,plan.remoteSha);}
      catch(cause){if(cause instanceof GitHubError&&(cause.status===409||cause.status===422))throw new ConcurrentWrite(cause,plan.remoteSha);throw cause;}
      this.assertSession(session);
      // The local side may have moved on while this upload was in flight.
      this.acknowledged={key:profileKey(profile),ledgerId:plan.ledgerId,before:plan.before};
    }
    this.assertSession(session);
    const changed=dataSignature(data)!==plan.expected;
    if(changed)await this.repository.commit(data,plan.expected,`同步 ${profile.repository}`,{sync:{profile,envelope:baseline,sha,connectionRevision:plan.connectionRevision}});
    else await this.repository.markSynchronized(profile,baseline,sha,plan.expected,plan.connectionRevision);
    this.assertSession(session);
    this.acknowledged=null;
    const latest=await this.repository.profile();this.assertSession(session);
    this.update({profile:latest,status:'idle',message:'已同步',plan:null});
    if(changed&&typeof window!=='undefined')window.dispatchEvent(new Event('dailysum-data-changed'));
    return changed;
  }
  networkLost():void{
    if(this.client.connected&&!this.running&&!this.state.plan)this.update({status:'offline',message:'本地已保存，等待联网同步'});
  }
  localChanged():void {
    if(this.timer)clearTimeout(this.timer);
    const generation=++this.scheduleGeneration;
    if(this.running){this.localChangedWhileRunning=true;return;}
    if(!this.client.connected||this.paused||this.state.plan)return;
    void this.repository.read().then((data)=>{
      if(generation!==this.scheduleGeneration||this.paused||this.running||this.state.plan||!this.client.connected)return;
      const profile=this.state.profile;if(!profile)return;
      if(profile.baseline&&syncSignature(data)===syncSignature(profile.baseline.data))return;
      const disconnected=offline();
      this.update({status:disconnected?'offline':'pending',message:disconnected?'本地已保存，等待联网同步':profile.auto?'本地已保存，等待自动同步':'本地已保存，等待手动同步'});
      if(profile.auto&&!disconnected)this.timer=setTimeout(()=>{void this.autoSync();},1200);
    }).catch((cause)=>this.update({status:'error',message:describeError(cause)}));
  }
  async autoSync():Promise<void>{
    if(!this.client.connected||!this.state.profile?.auto||this.paused||this.running||this.state.plan||offline())return;
    try{await this.startSync(undefined,{},true);}
    catch{/* State remains actionable; online/visibility/periodic events retry without discarding local edits. */}
  }
}
export const syncService=new SyncService(dataRepository);

