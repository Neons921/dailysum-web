import { mergeLedger, syncSignature, toSyncData, type Choices } from '../domain/merge';
import { createEnvelope, dataSignature, validateData, type LedgerEnvelope } from '../domain/portable';
import { emptySyncProfile, profileKey, type SyncProfile } from '../domain/sync';
import { DataRepository, StaleLedgerError } from '../storage/dataRepository';
import { dataRepository, type DataPlan } from './dataService';
import { GitHubClient, GitHubError } from './githubClient';
import { describeError } from './errors';
import { GitHubConnectionRepository } from '../storage/githubConnectionRepository';

export type SyncPlan=DataPlan&{kind:'sync';profile:SyncProfile;remoteSha:string|null;remoteEnvelope:LedgerEnvelope|null;ledgerId:string;connectionRevision:string|null;session:number};
export type SyncState={status:'disconnected'|'idle'|'pending'|'checking'|'review'|'syncing'|'error'|'offline';message:string;profile:SyncProfile|null;plan:SyncPlan|null;connected:boolean;remembered:boolean};
export class SyncService {
  private state:SyncState={status:'disconnected',message:'未连接',profile:null,plan:null,connected:false,remembered:false};
  private listeners=new Set<()=>void>();private running=false;private paused=false;private timer:ReturnType<typeof setTimeout>|undefined;private scheduleGeneration=0;
  private initialization:Promise<void>|null=null;private restoreGeneration=0;private session=0;private connectionRevision:string|null=null;private startupPending=false;
  readonly connections:GitHubConnectionRepository;
  constructor(readonly repository:DataRepository,readonly client=new GitHubClient()){this.connections=new GitHubConnectionRepository(repository.db);}
  subscribe=(listener:()=>void)=>{this.listeners.add(listener);return()=>{this.listeners.delete(listener);};};
  getState=()=>this.state;
  private update(patch:Partial<SyncState>){this.state={...this.state,...patch,connected:this.client.connected};for(const listener of this.listeners)listener();}
  initialize():Promise<void>{return this.initialization??=this.refreshConnection();}
  private announceConnectionChange():void {if(typeof window!=='undefined')window.dispatchEvent(new Event('dailysum-connection-changed'));}
  private endSession():void {
    this.session++;this.scheduleGeneration++;this.startupPending=false;
    if(this.timer)clearTimeout(this.timer);this.client.disconnect();this.connectionRevision=null;
  }
  private async resumeStartupSync():Promise<void>{
    if(!this.startupPending||this.running||this.paused)return;
    this.startupPending=false;await this.autoSync();
  }
  private async assertConnectionRevision():Promise<SyncProfile>{
    const {connection,profile}=await this.connections.read();
    if((connection?.revision??null)!==this.connectionRevision)throw new Error('GitHub 连接已变化，请重新检查同步');
    return profile;
  }
  async refreshConnection():Promise<void>{
    const generation=++this.restoreGeneration;
    try {
      const {profile,connection}=await this.connections.read();
      if(generation!==this.restoreGeneration)return;
      if(!connection){
        const wasConnected=this.client.connected;
        if(wasConnected)this.endSession();
        this.update({profile,remembered:false,...(wasConnected?{status:'disconnected' as const,plan:null,message:'已忘记连接，本地账目保留'}:{})});return;
      }
      if(this.client.connected&&this.connectionRevision===connection.revision){this.update({profile,remembered:true});return;}
      this.endSession();this.client.connect(connection.token);this.connectionRevision=connection.revision;
      const offline=typeof navigator!=='undefined'&&navigator.onLine===false;
      this.update({profile,remembered:true,plan:null,status:offline?'offline':'idle',message:offline?'已恢复连接，等待联网同步':'已恢复 GitHub 连接'});
      if(profile.auto&&profile.baseline){this.startupPending=true;await this.resumeStartupSync();}
    }catch(cause){
      if(generation!==this.restoreGeneration)return;
      this.endSession();this.update({status:'error',remembered:false,message:describeError(cause),plan:null});
    }
  }
  private async recordFailure(cause:unknown):Promise<void>{
    if(cause instanceof GitHubError&&cause.status===401){
      const revision=this.connectionRevision;this.endSession();const session=this.session;
      let removed=false;if(revision)try{removed=await this.connections.forget(revision);}catch{/* An invalid credential never stays active in memory. */}
      if(session===this.session)this.update({status:'error',remembered:false,message:'GitHub Token 已失效，请重新连接；本地账目已保留',plan:null});
      if(removed)this.announceConnectionChange();return;
    }
    this.update({status:typeof navigator!=='undefined'&&navigator.onLine===false?'offline':'error',message:describeError(cause),plan:null});
  }
  async connect(repository:string,token:string,{remember=true}:{remember?:boolean}={}):Promise<void> {
    if(this.running)throw new Error('同步正在进行，请稍后重试');
    this.restoreGeneration++;this.session++;this.startupPending=false;
    this.client.connect(token);this.running=true;this.update({status:'checking',message:'检查私有仓库…',plan:null});
    try{
      const old=await this.repository.profile();
      const target=await this.client.target({...emptySyncProfile(),repository});
      const profile=profileKey(old)===profileKey(target)?{...old,repository:target.repository,branch:target.branch,auto:old.baseline?old.auto:true}:{...target,auto:true};
      const saved=await this.connections.configure(profile,remember?token:null);this.connectionRevision=saved?.revision??null;
      this.update({profile,status:'idle',remembered:!!saved,message:'已连接，等待检查同步'});this.announceConnectionChange();
    }catch(cause){this.endSession();this.update({status:'error',remembered:false,message:describeError(cause)});throw cause;}
    finally{this.running=false;}
  }
  async disconnect():Promise<void>{
    if(this.running)throw new Error('同步正在进行，请稍后忘记连接');
    const profile={...await this.repository.profile(),auto:false};await this.connections.configure(profile,null);
    this.restoreGeneration++;this.endSession();this.update({status:'disconnected',remembered:false,message:'已忘记连接，本地账目保留',profile,plan:null});this.announceConnectionChange();
  }
  async setAuto(auto:boolean):Promise<void>{const profile=await this.repository.profile();if(auto&&!profile.baseline)throw new Error('请先完成一次手动同步');const next={...profile,auto};await this.repository.setProfile(next);this.update({profile:next});this.announceConnectionChange();if(auto){this.startupPending=true;await this.resumeStartupSync();}else{this.startupPending=false;if(this.timer)clearTimeout(this.timer);}}
  setPaused(paused:boolean):void{this.paused=paused;if(paused){this.scheduleGeneration++;if(this.timer)clearTimeout(this.timer);}else if(this.startupPending)void this.resumeStartupSync();else this.localChanged();}
  dismiss():void{this.update({plan:null,status:this.client.connected?'idle':'disconnected',message:'计划已取消，账目未修改'});}
  async prepare({automatic=false}:{automatic?:boolean}={}):Promise<SyncPlan> {
    if(this.running)throw new Error('同步正在进行，请稍后重试');
    const session=this.session;
    this.running=true;this.update({status:'checking',message:'读取 GitHub 账本…',plan:null});
    try{
      const profile=await this.client.target(await this.assertConnectionRevision());
      const before=await this.repository.read(),remote=await this.client.read(profile);
      if(session!==this.session)throw new Error('GitHub 连接已变化，请重新检查同步');
      if(profile.baseline&&!remote)throw new Error('远端账本文件已移除，已停止同步；请检查 GitHub 仓库历史');
      if(profile.baseline&&remote&&profile.baseline.ledgerId!==remote.envelope.ledgerId)throw new Error('远端账本身份发生变化，已停止同步，请核对仓库与备份');
      const ledgerId=remote?.envelope.ledgerId??await this.repository.identity();
      const incoming=remote?.envelope.data??toSyncData({...before,transactions:[],fxRates:[],archives:[],filterPreferences:{...before.filterPreferences,views:[],activeId:null}});
      const plan:SyncPlan={kind:'sync',label:profile.repository,before,base:profile.baseline?.data??null,remote:incoming,expected:dataSignature(before),issues:[],warnings:[],duplicates:0,total:incoming.transactions.length,profile,remoteSha:remote?.sha??null,remoteEnvelope:remote?.envelope??null,ledgerId,session,connectionRevision:this.connectionRevision};
      const conflicts=mergeLedger(plan.base,plan.before,plan.remote).conflicts.length;
      this.update({status:automatic&&!conflicts?'syncing':'review',message:conflicts?'同步存在分歧，请选择保留的内容':'同步计划已准备好',plan:automatic&&!conflicts?null:plan,profile});return plan;
    }catch(cause){if(session===this.session)await this.recordFailure(cause);throw cause;}
    finally{this.running=false;void this.resumeStartupSync();}
  }
  async commit(plan:SyncPlan,choices:Choices={}):Promise<boolean> {
    if(this.running)throw new Error('同步正在进行，请稍后重试');
    const session=this.session;if(plan.session!==session)throw new Error('GitHub 连接已变化，请重新检查同步');
    this.running=true;this.update({status:'syncing',message:'同步中…'});
    let changed=false;const run=async()=>{
      const profile=await this.assertConnectionRevision();if(profileKey(profile)!==profileKey(plan.profile))throw new Error('同步仓库配置已变化，请重新检查');
      await this.repository.assertCurrent(plan.expected);
      if(session!==this.session)throw new Error('GitHub 连接已变化，请重新检查同步');
      const merged=mergeLedger(plan.base,plan.before,plan.remote,choices);if(merged.unresolved.length)throw new Error('请处理全部同步冲突');
      const data=validateData(merged.data),envelope=await createEnvelope(toSyncData(data),plan.ledgerId);
      const unchanged=plan.remoteEnvelope&&syncSignature(plan.remoteEnvelope.data)===syncSignature(data);
      const sha=unchanged?plan.remoteSha!:await this.client.write(profile,envelope,plan.remoteSha);
      if(session!==this.session)throw new Error('GitHub 连接已变化，请重新检查同步');
      const baseline=unchanged?plan.remoteEnvelope!:envelope;
      // The post-upload signature check also catches edits made while the network was pending.
      changed=dataSignature(data)!==plan.expected;
      if(!changed)await this.repository.markSynchronized(profile,baseline,sha,plan.expected,plan.connectionRevision);
      else await this.repository.commit(data,plan.expected,`同步 ${profile.repository}`,{sync:{profile,envelope:baseline,sha,connectionRevision:plan.connectionRevision}});
      this.update({profile:await this.repository.profile(),status:'idle',message:'已同步',plan:null});
    };
    try{if(typeof navigator!=='undefined'&&navigator.locks)await navigator.locks.request('dailysum-github-sync',run);else await run();}
    catch(cause){if(session===this.session)await this.recordFailure(cause instanceof StaleLedgerError?new Error('同步期间有新记账，已保留本地变更，请重新检查同步'):cause);throw cause;}
    finally{this.running=false;void this.resumeStartupSync();}
    return changed;
  }
  localChanged():void {
    if(this.timer)clearTimeout(this.timer);
    const generation=++this.scheduleGeneration;
    if(!this.client.connected||this.paused||this.running||this.state.plan)return;
    void this.repository.read().then((data)=>{
      if(generation!==this.scheduleGeneration||this.paused||this.running||this.state.plan||!this.client.connected)return;
      const profile=this.state.profile;if(!profile)return;
      if(profile.baseline&&syncSignature(data)===syncSignature(profile.baseline.data))return;
      const offline=typeof navigator!=='undefined'&&navigator.onLine===false;
      this.update({status:offline?'offline':'pending',message:offline?'本地已保存，等待联网同步':!profile.baseline?'首次同步待确认':profile.auto?'本地已保存，等待自动同步':'本地已保存，等待手动同步'});
      if(profile.auto&&profile.baseline&&!offline)this.timer=setTimeout(()=>{void this.autoSync();},1500);
    }).catch((cause)=>this.update({status:'error',message:describeError(cause)}));
  }
  async autoSync():Promise<void>{
    if(!this.client.connected||!this.state.profile?.auto||!this.state.profile?.baseline||this.paused||this.running||this.state.plan||typeof navigator!=='undefined'&&navigator.onLine===false)return;
    try{const plan=await this.prepare({automatic:true});if(mergeLedger(plan.base,plan.before,plan.remote).conflicts.length)return;const changed=await this.commit(plan);if(changed&&typeof window!=='undefined')window.dispatchEvent(new Event('dailysum-data-changed'));}
    catch{/* State remains actionable; online/visibility/periodic events retry without discarding local edits. */}
  }
}
export const syncService=new SyncService(dataRepository);

