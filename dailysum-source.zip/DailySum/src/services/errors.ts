export function describeError(cause: unknown): string {
  if (!(cause instanceof Error)) return '发生未知错误，请重试';
  if (cause.name === 'QuotaExceededError') return '此浏览器的存储空间不足，请释放空间后重试';
  if (cause.name === 'SecurityError') return '此浏览器暂不允许本地存储，请检查浏览器设置';
  if (cause.name === 'DatabaseClosedError') return '本地账本连接已关闭，请刷新页面后重试';
  return cause.message;
}
